package i;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.Arrays;
import k.Deprecated;
import k.DeprecationLevel;
import k.Metadata;
import k.ReplaceWith;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/** @deprecated */
@Deprecated(
   message = "changed in Okio 2.x"
)
@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0007J\b\u0010\u0007\u001a\u00020\u0004H\u0007J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0004H\u0007J\u0010\u0010\b\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0007J\u0010\u0010\n\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0007J\u0010\u0010\n\u001a\u00020\u00042\u0006\u0010\u000e\u001a\u00020\u000fH\u0007J\u0010\u0010\n\u001a\u00020\u00042\u0006\u0010\u0010\u001a\u00020\u0011H\u0007J)\u0010\n\u001a\u00020\u00042\u0006\u0010\u0012\u001a\u00020\u00132\u0012\u0010\u0014\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00160\u0015\"\u00020\u0016H\u0007¢\u0006\u0002\u0010\u0017J\u0010\u0010\f\u001a\u00020\r2\u0006\u0010\u0005\u001a\u00020\u0006H\u0007J\u0010\u0010\f\u001a\u00020\r2\u0006\u0010\u0018\u001a\u00020\u0019H\u0007J\u0010\u0010\f\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\u0011H\u0007J)\u0010\f\u001a\u00020\r2\u0006\u0010\u0012\u001a\u00020\u00132\u0012\u0010\u0014\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00160\u0015\"\u00020\u0016H\u0007¢\u0006\u0002\u0010\u001a¨\u0006\u001b"},
   d2 = {"Li/-DeprecatedOkio;", "", "()V", "appendingSink", "Li/Sink;", "file", "Ljava/io/File;", "blackhole", "buffer", "Li/BufferedSink;", "sink", "Li/BufferedSource;", "source", "Li/Source;", "outputStream", "Ljava/io/OutputStream;", "socket", "Ljava/net/Socket;", "path", "Ljava/nio/file/Path;", "options", "", "Ljava/nio/file/OpenOption;", "(Ljava/nio/file/Path;[Ljava/nio/file/OpenOption;)Lokio/Sink;", "inputStream", "Ljava/io/InputStream;", "(Ljava/nio/file/Path;[Ljava/nio/file/OpenOption;)Lokio/Source;", "i"}
)
public final class -DeprecatedOkio {
   public static final -DeprecatedOkio INSTANCE;

   /** @deprecated */
   @Deprecated(
      message = "moved to extension function",
      replaceWith = @ReplaceWith(
   imports = {"i.appendingSink"},
   expression = "file.appendingSink()"
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public final Sink appendingSink(@NotNull File file) {
      Intrinsics.checkNotNullParameter(file, "file");
      return Okio.appendingSink(file);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to extension function",
      replaceWith = @ReplaceWith(
   imports = {"i.buffer"},
   expression = "sink.buffer()"
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public final BufferedSink buffer(@NotNull Sink sink) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      return Okio.buffer(sink);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to extension function",
      replaceWith = @ReplaceWith(
   imports = {"i.buffer"},
   expression = "source.buffer()"
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public final BufferedSource buffer(@NotNull Source source) {
      Intrinsics.checkNotNullParameter(source, "source");
      return Okio.buffer(source);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to extension function",
      replaceWith = @ReplaceWith(
   imports = {"i.sink"},
   expression = "file.sink()"
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public final Sink sink(@NotNull File file) {
      Intrinsics.checkNotNullParameter(file, "file");
      return Okio.sink$default(file, false, 1, (Object)null);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to extension function",
      replaceWith = @ReplaceWith(
   imports = {"i.sink"},
   expression = "outputStream.sink()"
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public final Sink sink(@NotNull OutputStream outputStream) {
      Intrinsics.checkNotNullParameter(outputStream, "outputStream");
      return Okio.sink(outputStream);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to extension function",
      replaceWith = @ReplaceWith(
   imports = {"i.sink"},
   expression = "path.sink(*options)"
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public final Sink sink(@NotNull Path path, @NotNull OpenOption... options) {
      Intrinsics.checkNotNullParameter(path, "path");
      Intrinsics.checkNotNullParameter(options, "options");
      return Okio.sink(path, (OpenOption[])Arrays.copyOf(options, options.length));
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to extension function",
      replaceWith = @ReplaceWith(
   imports = {"i.sink"},
   expression = "socket.sink()"
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public final Sink sink(@NotNull Socket socket) {
      Intrinsics.checkNotNullParameter(socket, "socket");
      return Okio.sink(socket);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to extension function",
      replaceWith = @ReplaceWith(
   imports = {"i.source"},
   expression = "file.source()"
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public final Source source(@NotNull File file) {
      Intrinsics.checkNotNullParameter(file, "file");
      return Okio.source(file);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to extension function",
      replaceWith = @ReplaceWith(
   imports = {"i.source"},
   expression = "inputStream.source()"
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public final Source source(@NotNull InputStream inputStream) {
      Intrinsics.checkNotNullParameter(inputStream, "inputStream");
      return Okio.source(inputStream);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to extension function",
      replaceWith = @ReplaceWith(
   imports = {"i.source"},
   expression = "path.source(*options)"
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public final Source source(@NotNull Path path, @NotNull OpenOption... options) {
      Intrinsics.checkNotNullParameter(path, "path");
      Intrinsics.checkNotNullParameter(options, "options");
      return Okio.source(path, (OpenOption[])Arrays.copyOf(options, options.length));
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to extension function",
      replaceWith = @ReplaceWith(
   imports = {"i.source"},
   expression = "socket.source()"
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public final Source source(@NotNull Socket socket) {
      Intrinsics.checkNotNullParameter(socket, "socket");
      return Okio.source(socket);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to extension function",
      replaceWith = @ReplaceWith(
   imports = {"i.blackholeSink"},
   expression = "blackholeSink()"
),
      level = DeprecationLevel.ERROR
   )
   @NotNull
   public final Sink blackhole() {
      return Okio.blackhole();
   }

   private _DeprecatedOkio/* $FF was: -DeprecatedOkio*/() {
   }

   static {
      -DeprecatedOkio var0 = new -DeprecatedOkio();
      INSTANCE = var0;
   }
}
