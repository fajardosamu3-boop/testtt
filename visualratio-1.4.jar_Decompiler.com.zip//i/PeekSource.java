package i;

import k.Metadata;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\b\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u000f\u001a\u00020\u0010H\u0016J\u0018\u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u000eH\u0016J\b\u0010\u0014\u001a\u00020\u0015H\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0016"},
   d2 = {"Li/PeekSource;", "Li/Source;", "upstream", "Li/BufferedSource;", "(Lokio/BufferedSource;)V", "buffer", "Li/Buffer;", "closed", "", "expectedPos", "", "expectedSegment", "Li/Segment;", "pos", "", "close", "", "read", "sink", "byteCount", "timeout", "Li/Timeout;", "i"}
)
public final class PeekSource implements Source {
   private final Buffer buffer;
   private Segment expectedSegment;
   private int expectedPos;
   private boolean closed;
   private long pos;
   private final BufferedSource upstream;

   public long read(@NotNull Buffer sink, long byteCount) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      boolean var4 = byteCount >= 0L;
      boolean var5 = false;
      boolean var6 = false;
      boolean var7;
      String var11;
      if (!var4) {
         var7 = false;
         var11 = "byteCount < 0: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var11.toString()));
      } else {
         var4 = !this.closed;
         var5 = false;
         var6 = false;
         if (!var4) {
            var7 = false;
            var11 = "closed";
            throw (Throwable)(new IllegalStateException(var11.toString()));
         } else {
            boolean var12;
            Segment var10001;
            label67: {
               if (this.expectedSegment != null) {
                  label63: {
                     if (this.expectedSegment == this.buffer.head) {
                        int var10000 = this.expectedPos;
                        var10001 = this.buffer.head;
                        Intrinsics.checkNotNull(var10001);
                        if (var10000 == var10001.pos) {
                           break label63;
                        }
                     }

                     var12 = false;
                     break label67;
                  }
               }

               var12 = true;
            }

            var4 = var12;
            var5 = false;
            var6 = false;
            if (!var4) {
               var7 = false;
               var11 = "Peek source is invalid because upstream source was used";
               throw (Throwable)(new IllegalStateException(var11.toString()));
            } else if (byteCount == 0L) {
               return 0L;
            } else if (!this.upstream.request(this.pos + 1L)) {
               return -1L;
            } else {
               if (this.expectedSegment == null && this.buffer.head != null) {
                  this.expectedSegment = this.buffer.head;
                  var10001 = this.buffer.head;
                  Intrinsics.checkNotNull(var10001);
                  this.expectedPos = var10001.pos;
               }

               long var10 = this.buffer.size() - this.pos;
               boolean var8 = false;
               long toCopy = Math.min(byteCount, var10);
               this.buffer.copyTo(sink, this.pos, toCopy);
               this.pos += toCopy;
               return toCopy;
            }
         }
      }
   }

   @NotNull
   public Timeout timeout() {
      return this.upstream.timeout();
   }

   public void close() {
      this.closed = true;
   }

   public PeekSource(@NotNull BufferedSource upstream) {
      Intrinsics.checkNotNullParameter(upstream, "upstream");
      super();
      this.upstream = upstream;
      this.buffer = this.upstream.getBuffer();
      this.expectedSegment = this.buffer.head;
      Segment var10001 = this.buffer.head;
      this.expectedPos = var10001 != null ? var10001.pos : -1;
   }
}
