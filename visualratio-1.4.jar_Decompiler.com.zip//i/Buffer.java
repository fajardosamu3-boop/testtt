package i;

import i.internal.BufferKt;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import k.Deprecated;
import k.DeprecationLevel;
import k.Metadata;
import k.ReplaceWith;
import k.collections.ArraysKt;
import k.jvm.JvmField;
import k.jvm.JvmName;
import k.jvm.JvmOverloads;
import k.jvm.internal.Intrinsics;
import k.jvm.internal.StringCompanionObject;
import k.text.Charsets;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000ª\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u001a\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0005\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\n\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0017\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u0004:\u0002\u0090\u0001B\u0005¢\u0006\u0002\u0010\u0005J\b\u0010\u0006\u001a\u00020\u0000H\u0016J\u0006\u0010\u0011\u001a\u00020\u0012J\b\u0010\u0013\u001a\u00020\u0000H\u0016J\b\u0010\u0014\u001a\u00020\u0012H\u0016J\u0006\u0010\u0015\u001a\u00020\fJ\u0006\u0010\u0016\u001a\u00020\u0000J$\u0010\u0017\u001a\u00020\u00002\u0006\u0010\u0018\u001a\u00020\u00192\b\b\u0002\u0010\u001a\u001a\u00020\f2\b\b\u0002\u0010\u001b\u001a\u00020\fH\u0007J\u0018\u0010\u0017\u001a\u00020\u00002\u0006\u0010\u0018\u001a\u00020\u00002\b\b\u0002\u0010\u001a\u001a\u00020\fJ \u0010\u0017\u001a\u00020\u00002\u0006\u0010\u0018\u001a\u00020\u00002\b\b\u0002\u0010\u001a\u001a\u00020\f2\u0006\u0010\u001b\u001a\u00020\fJ\u0010\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u001fH\u0002J\b\u0010 \u001a\u00020\u0000H\u0016J\b\u0010!\u001a\u00020\u0000H\u0016J\u0013\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010%H\u0096\u0002J\b\u0010&\u001a\u00020#H\u0016J\b\u0010'\u001a\u00020\u0012H\u0016J\u0016\u0010(\u001a\u00020)2\u0006\u0010*\u001a\u00020\fH\u0087\u0002¢\u0006\u0002\b+J\u0015\u0010+\u001a\u00020)2\u0006\u0010,\u001a\u00020\fH\u0007¢\u0006\u0002\b-J\b\u0010.\u001a\u00020/H\u0016J\u0018\u00100\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u00101\u001a\u00020\u001dH\u0002J\u000e\u00102\u001a\u00020\u001d2\u0006\u00101\u001a\u00020\u001dJ\u000e\u00103\u001a\u00020\u001d2\u0006\u00101\u001a\u00020\u001dJ\u000e\u00104\u001a\u00020\u001d2\u0006\u00101\u001a\u00020\u001dJ\u0010\u00105\u001a\u00020\f2\u0006\u00106\u001a\u00020)H\u0016J\u0018\u00105\u001a\u00020\f2\u0006\u00106\u001a\u00020)2\u0006\u00107\u001a\u00020\fH\u0016J \u00105\u001a\u00020\f2\u0006\u00106\u001a\u00020)2\u0006\u00107\u001a\u00020\f2\u0006\u00108\u001a\u00020\fH\u0016J\u0010\u00105\u001a\u00020\f2\u0006\u00109\u001a\u00020\u001dH\u0016J\u0018\u00105\u001a\u00020\f2\u0006\u00109\u001a\u00020\u001d2\u0006\u00107\u001a\u00020\fH\u0016J\u0010\u0010:\u001a\u00020\f2\u0006\u0010;\u001a\u00020\u001dH\u0016J\u0018\u0010:\u001a\u00020\f2\u0006\u0010;\u001a\u00020\u001d2\u0006\u00107\u001a\u00020\fH\u0016J\b\u0010<\u001a\u00020=H\u0016J\b\u0010>\u001a\u00020#H\u0016J\u0006\u0010?\u001a\u00020\u001dJ\b\u0010@\u001a\u00020\u0019H\u0016J\b\u0010A\u001a\u00020\u0001H\u0016J\u0018\u0010B\u001a\u00020#2\u0006\u0010\u001a\u001a\u00020\f2\u0006\u00109\u001a\u00020\u001dH\u0016J(\u0010B\u001a\u00020#2\u0006\u0010\u001a\u001a\u00020\f2\u0006\u00109\u001a\u00020\u001d2\u0006\u0010C\u001a\u00020/2\u0006\u0010\u001b\u001a\u00020/H\u0016J\u0010\u0010D\u001a\u00020/2\u0006\u0010E\u001a\u00020FH\u0016J\u0010\u0010D\u001a\u00020/2\u0006\u0010E\u001a\u00020GH\u0016J \u0010D\u001a\u00020/2\u0006\u0010E\u001a\u00020G2\u0006\u0010\u001a\u001a\u00020/2\u0006\u0010\u001b\u001a\u00020/H\u0016J\u0018\u0010D\u001a\u00020\f2\u0006\u0010E\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\fH\u0016J\u0010\u0010H\u001a\u00020\f2\u0006\u0010E\u001a\u00020IH\u0016J\u0012\u0010J\u001a\u00020K2\b\b\u0002\u0010L\u001a\u00020KH\u0007J\b\u0010M\u001a\u00020)H\u0016J\b\u0010N\u001a\u00020GH\u0016J\u0010\u0010N\u001a\u00020G2\u0006\u0010\u001b\u001a\u00020\fH\u0016J\b\u0010O\u001a\u00020\u001dH\u0016J\u0010\u0010O\u001a\u00020\u001d2\u0006\u0010\u001b\u001a\u00020\fH\u0016J\b\u0010P\u001a\u00020\fH\u0016J\u000e\u0010Q\u001a\u00020\u00002\u0006\u0010R\u001a\u00020=J\u0016\u0010Q\u001a\u00020\u00002\u0006\u0010R\u001a\u00020=2\u0006\u0010\u001b\u001a\u00020\fJ \u0010Q\u001a\u00020\u00122\u0006\u0010R\u001a\u00020=2\u0006\u0010\u001b\u001a\u00020\f2\u0006\u0010S\u001a\u00020#H\u0002J\u0010\u0010T\u001a\u00020\u00122\u0006\u0010E\u001a\u00020GH\u0016J\u0018\u0010T\u001a\u00020\u00122\u0006\u0010E\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\fH\u0016J\b\u0010U\u001a\u00020\fH\u0016J\b\u0010V\u001a\u00020/H\u0016J\b\u0010W\u001a\u00020/H\u0016J\b\u0010X\u001a\u00020\fH\u0016J\b\u0010Y\u001a\u00020\fH\u0016J\b\u0010Z\u001a\u00020[H\u0016J\b\u0010\\\u001a\u00020[H\u0016J\u0010\u0010]\u001a\u00020\u001f2\u0006\u0010^\u001a\u00020_H\u0016J\u0018\u0010]\u001a\u00020\u001f2\u0006\u0010\u001b\u001a\u00020\f2\u0006\u0010^\u001a\u00020_H\u0016J\u0012\u0010`\u001a\u00020K2\b\b\u0002\u0010L\u001a\u00020KH\u0007J\b\u0010a\u001a\u00020\u001fH\u0016J\u0010\u0010a\u001a\u00020\u001f2\u0006\u0010\u001b\u001a\u00020\fH\u0016J\b\u0010b\u001a\u00020/H\u0016J\n\u0010c\u001a\u0004\u0018\u00010\u001fH\u0016J\b\u0010d\u001a\u00020\u001fH\u0016J\u0010\u0010d\u001a\u00020\u001f2\u0006\u0010e\u001a\u00020\fH\u0016J\u0010\u0010f\u001a\u00020#2\u0006\u0010\u001b\u001a\u00020\fH\u0016J\u0010\u0010g\u001a\u00020\u00122\u0006\u0010\u001b\u001a\u00020\fH\u0016J\u0010\u0010h\u001a\u00020/2\u0006\u0010i\u001a\u00020jH\u0016J\u0006\u0010k\u001a\u00020\u001dJ\u0006\u0010l\u001a\u00020\u001dJ\u0006\u0010m\u001a\u00020\u001dJ\r\u0010\r\u001a\u00020\fH\u0007¢\u0006\u0002\bnJ\u0010\u0010o\u001a\u00020\u00122\u0006\u0010\u001b\u001a\u00020\fH\u0016J\u0006\u0010p\u001a\u00020\u001dJ\u000e\u0010p\u001a\u00020\u001d2\u0006\u0010\u001b\u001a\u00020/J\b\u0010q\u001a\u00020rH\u0016J\b\u0010s\u001a\u00020\u001fH\u0016J\u0015\u0010t\u001a\u00020\n2\u0006\u0010u\u001a\u00020/H\u0000¢\u0006\u0002\bvJ\u0010\u0010w\u001a\u00020/2\u0006\u0010x\u001a\u00020FH\u0016J\u0010\u0010w\u001a\u00020\u00002\u0006\u0010x\u001a\u00020GH\u0016J \u0010w\u001a\u00020\u00002\u0006\u0010x\u001a\u00020G2\u0006\u0010\u001a\u001a\u00020/2\u0006\u0010\u001b\u001a\u00020/H\u0016J\u0018\u0010w\u001a\u00020\u00122\u0006\u0010x\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\fH\u0016J\u0010\u0010w\u001a\u00020\u00002\u0006\u0010y\u001a\u00020\u001dH\u0016J \u0010w\u001a\u00020\u00002\u0006\u0010y\u001a\u00020\u001d2\u0006\u0010\u001a\u001a\u00020/2\u0006\u0010\u001b\u001a\u00020/H\u0016J\u0018\u0010w\u001a\u00020\u00002\u0006\u0010x\u001a\u00020z2\u0006\u0010\u001b\u001a\u00020\fH\u0016J\u0010\u0010{\u001a\u00020\f2\u0006\u0010x\u001a\u00020zH\u0016J\u0010\u0010|\u001a\u00020\u00002\u0006\u00106\u001a\u00020/H\u0016J\u0010\u0010}\u001a\u00020\u00002\u0006\u0010~\u001a\u00020\fH\u0016J\u0010\u0010\u007f\u001a\u00020\u00002\u0006\u0010~\u001a\u00020\fH\u0016J\u0012\u0010\u0080\u0001\u001a\u00020\u00002\u0007\u0010\u0081\u0001\u001a\u00020/H\u0016J\u0012\u0010\u0082\u0001\u001a\u00020\u00002\u0007\u0010\u0081\u0001\u001a\u00020/H\u0016J\u0011\u0010\u0083\u0001\u001a\u00020\u00002\u0006\u0010~\u001a\u00020\fH\u0016J\u0011\u0010\u0084\u0001\u001a\u00020\u00002\u0006\u0010~\u001a\u00020\fH\u0016J\u0012\u0010\u0085\u0001\u001a\u00020\u00002\u0007\u0010\u0086\u0001\u001a\u00020/H\u0016J\u0012\u0010\u0087\u0001\u001a\u00020\u00002\u0007\u0010\u0086\u0001\u001a\u00020/H\u0016J\u001a\u0010\u0088\u0001\u001a\u00020\u00002\u0007\u0010\u0089\u0001\u001a\u00020\u001f2\u0006\u0010^\u001a\u00020_H\u0016J,\u0010\u0088\u0001\u001a\u00020\u00002\u0007\u0010\u0089\u0001\u001a\u00020\u001f2\u0007\u0010\u008a\u0001\u001a\u00020/2\u0007\u0010\u008b\u0001\u001a\u00020/2\u0006\u0010^\u001a\u00020_H\u0016J\u001b\u0010\u008c\u0001\u001a\u00020\u00002\u0006\u0010\u0018\u001a\u00020\u00192\b\b\u0002\u0010\u001b\u001a\u00020\fH\u0007J\u0012\u0010\u008d\u0001\u001a\u00020\u00002\u0007\u0010\u0089\u0001\u001a\u00020\u001fH\u0016J$\u0010\u008d\u0001\u001a\u00020\u00002\u0007\u0010\u0089\u0001\u001a\u00020\u001f2\u0007\u0010\u008a\u0001\u001a\u00020/2\u0007\u0010\u008b\u0001\u001a\u00020/H\u0016J\u0012\u0010\u008e\u0001\u001a\u00020\u00002\u0007\u0010\u008f\u0001\u001a\u00020/H\u0016R\u0014\u0010\u0006\u001a\u00020\u00008VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u0014\u0010\t\u001a\u0004\u0018\u00010\n8\u0000@\u0000X\u0081\u000e¢\u0006\u0002\n\u0000R&\u0010\r\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\f8G@@X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010¨\u0006\u0091\u0001"},
   d2 = {"Li/Buffer;", "Li/BufferedSource;", "Li/BufferedSink;", "", "Ljava/nio/channels/ByteChannel;", "()V", "buffer", "getBuffer", "()Lokio/Buffer;", "head", "Li/Segment;", "<set-?>", "", "size", "()J", "setSize$okio", "(J)V", "clear", "", "clone", "close", "completeSegmentByteCount", "copy", "copyTo", "out", "Ljava/io/OutputStream;", "offset", "byteCount", "digest", "Li/ByteString;", "algorithm", "", "emit", "emitCompleteSegments", "equals", "", "other", "", "exhausted", "flush", "get", "", "pos", "getByte", "index", "-deprecated_getByte", "hashCode", "", "hmac", "key", "hmacSha1", "hmacSha256", "hmacSha512", "indexOf", "b", "fromIndex", "toIndex", "bytes", "indexOfElement", "targetBytes", "inputStream", "Ljava/io/InputStream;", "isOpen", "md5", "outputStream", "peek", "rangeEquals", "bytesOffset", "read", "sink", "Ljava/nio/ByteBuffer;", "", "readAll", "Li/Sink;", "readAndWriteUnsafe", "Li/Buffer$UnsafeCursor;", "unsafeCursor", "readByte", "readByteArray", "readByteString", "readDecimalLong", "readFrom", "input", "forever", "readFully", "readHexadecimalUnsignedLong", "readInt", "readIntLe", "readLong", "readLongLe", "readShort", "", "readShortLe", "readString", "charset", "Ljava/nio/charset/Charset;", "readUnsafe", "readUtf8", "readUtf8CodePoint", "readUtf8Line", "readUtf8LineStrict", "limit", "request", "require", "select", "options", "Li/Options;", "sha1", "sha256", "sha512", "-deprecated_size", "skip", "snapshot", "timeout", "Li/Timeout;", "toString", "writableSegment", "minimumCapacity", "writableSegment$okio", "write", "source", "byteString", "Li/Source;", "writeAll", "writeByte", "writeDecimalLong", "v", "writeHexadecimalUnsignedLong", "writeInt", "i", "writeIntLe", "writeLong", "writeLongLe", "writeShort", "s", "writeShortLe", "writeString", "string", "beginIndex", "endIndex", "writeTo", "writeUtf8", "writeUtf8CodePoint", "codePoint", "UnsafeCursor", "i"}
)
public final class Buffer implements BufferedSource, BufferedSink, Cloneable, ByteChannel {
   @JvmField
   @Nullable
   public Segment head;
   private long size;

   @JvmName(
      name = "size"
   )
   public final long size() {
      return this.size;
   }

   public final void setSize$okio(long var1) {
      this.size = var1;
   }

   @NotNull
   public Buffer buffer() {
      return this;
   }

   @NotNull
   public Buffer getBuffer() {
      return this;
   }

   @NotNull
   public OutputStream outputStream() {
      return (OutputStream)(new OutputStream() {
         public void write(int b) {
            Buffer.this.writeByte(b);
         }

         public void write(@NotNull byte[] data, int offset, int byteCount) {
            Intrinsics.checkNotNullParameter(data, "data");
            Buffer.this.write(data, offset, byteCount);
         }

         public void flush() {
         }

         public void close() {
         }

         @NotNull
         public String toString() {
            return Buffer.this + ".outputStream()";
         }
      });
   }

   @NotNull
   public Buffer emitCompleteSegments() {
      return this;
   }

   @NotNull
   public Buffer emit() {
      return this;
   }

   public boolean exhausted() {
      return this.size == 0L;
   }

   public void require(long byteCount) throws EOFException {
      if (this.size < byteCount) {
         throw (Throwable)(new EOFException());
      }
   }

   public boolean request(long byteCount) {
      return this.size >= byteCount;
   }

   @NotNull
   public BufferedSource peek() {
      return Okio.buffer((Source)(new PeekSource((BufferedSource)this)));
   }

   @NotNull
   public InputStream inputStream() {
      return (InputStream)(new InputStream() {
         public int read() {
            int var10000;
            if (Buffer.this.size() > 0L) {
               byte $this$and$iv = Buffer.this.readByte();
               int other$iv = 255;
               int $i$f$and = false;
               var10000 = $this$and$iv & other$iv;
            } else {
               var10000 = -1;
            }

            return var10000;
         }

         public int read(@NotNull byte[] sink, int offset, int byteCount) {
            Intrinsics.checkNotNullParameter(sink, "sink");
            return Buffer.this.read(sink, offset, byteCount);
         }

         public int available() {
            long a$iv = Buffer.this.size();
            int b$iv = Integer.MAX_VALUE;
            int $i$f$minOf = false;
            long var5 = (long)b$iv;
            boolean var7 = false;
            return (int)Math.min(a$iv, var5);
         }

         public void close() {
         }

         @NotNull
         public String toString() {
            return Buffer.this + ".inputStream()";
         }
      });
   }

   @JvmOverloads
   @NotNull
   public final Buffer copyTo(@NotNull OutputStream out, long offset, long byteCount) throws IOException {
      Intrinsics.checkNotNullParameter(out, "out");
      long offset = offset;
      long byteCount = byteCount;
      -Util.checkOffsetAndCount(this.size, offset, byteCount);
      if (byteCount == 0L) {
         return this;
      } else {
         Segment s = this.head;

         while(true) {
            Intrinsics.checkNotNull(s);
            if (offset < (long)(s.limit - s.pos)) {
               while(byteCount > 0L) {
                  Intrinsics.checkNotNull(s);
                  int pos = (int)((long)s.pos + offset);
                  int a$iv = s.limit - pos;
                  int $i$f$minOf = false;
                  long var15 = (long)a$iv;
                  boolean var17 = false;
                  int toCopy = (int)Math.min(var15, byteCount);
                  out.write(s.data, pos, toCopy);
                  byteCount -= (long)toCopy;
                  offset = 0L;
                  s = s.next;
               }

               return this;
            }

            offset -= (long)(s.limit - s.pos);
            s = s.next;
         }
      }
   }

   // $FF: synthetic method
   public static Buffer copyTo$default(Buffer var0, OutputStream var1, long var2, long var4, int var6, Object var7) throws IOException {
      if ((var6 & 2) != 0) {
         var2 = 0L;
      }

      if ((var6 & 4) != 0) {
         var4 = var0.size - var2;
      }

      return var0.copyTo(var1, var2, var4);
   }

   @JvmOverloads
   @NotNull
   public final Buffer copyTo(@NotNull OutputStream out, long offset) throws IOException {
      return copyTo$default(this, (OutputStream)out, offset, 0L, 4, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final Buffer copyTo(@NotNull OutputStream out) throws IOException {
      return copyTo$default(this, (OutputStream)out, 0L, 0L, 6, (Object)null);
   }

   @NotNull
   public final Buffer copyTo(@NotNull Buffer out, long offset, long byteCount) {
      Intrinsics.checkNotNullParameter(out, "out");
      int $i$f$commonCopyTo = false;
      long offset$iv = offset;
      long byteCount$iv = byteCount;
      -Util.checkOffsetAndCount(this.size(), offset, byteCount);
      Buffer var10000;
      if (byteCount == 0L) {
         var10000 = this;
      } else {
         out.setSize$okio(out.size() + byteCount);
         Segment s$iv = this.head;

         while(true) {
            Intrinsics.checkNotNull(s$iv);
            if (offset$iv < (long)(s$iv.limit - s$iv.pos)) {
               while(byteCount$iv > 0L) {
                  Intrinsics.checkNotNull(s$iv);
                  Segment copy$iv = s$iv.sharedCopy();
                  copy$iv.pos += (int)offset$iv;
                  int var14 = copy$iv.pos + (int)byteCount$iv;
                  int var15 = copy$iv.limit;
                  boolean var16 = false;
                  copy$iv.limit = Math.min(var14, var15);
                  if (out.head == null) {
                     copy$iv.prev = copy$iv;
                     copy$iv.next = copy$iv.prev;
                     out.head = copy$iv.next;
                  } else {
                     Segment var17 = out.head;
                     Intrinsics.checkNotNull(var17);
                     var17 = var17.prev;
                     Intrinsics.checkNotNull(var17);
                     var17.push(copy$iv);
                  }

                  byteCount$iv -= (long)(copy$iv.limit - copy$iv.pos);
                  offset$iv = 0L;
                  s$iv = s$iv.next;
               }

               var10000 = this;
               break;
            }

            offset$iv -= (long)(s$iv.limit - s$iv.pos);
            s$iv = s$iv.next;
         }
      }

      return var10000;
   }

   // $FF: synthetic method
   public static Buffer copyTo$default(Buffer var0, Buffer var1, long var2, long var4, int var6, Object var7) {
      if ((var6 & 2) != 0) {
         var2 = 0L;
      }

      return var0.copyTo(var1, var2, var4);
   }

   @NotNull
   public final Buffer copyTo(@NotNull Buffer out, long offset) {
      Intrinsics.checkNotNullParameter(out, "out");
      return this.copyTo(out, offset, this.size - offset);
   }

   // $FF: synthetic method
   public static Buffer copyTo$default(Buffer var0, Buffer var1, long var2, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0L;
      }

      return var0.copyTo(var1, var2);
   }

   @JvmOverloads
   @NotNull
   public final Buffer writeTo(@NotNull OutputStream out, long byteCount) throws IOException {
      Intrinsics.checkNotNullParameter(out, "out");
      long byteCount = byteCount;
      -Util.checkOffsetAndCount(this.size, 0L, byteCount);
      Segment s = this.head;

      while(byteCount > 0L) {
         Intrinsics.checkNotNull(s);
         int b$iv = s.limit - s.pos;
         int $i$f$minOf = false;
         long var10 = (long)b$iv;
         boolean var12 = false;
         int toCopy = (int)Math.min(byteCount, var10);
         out.write(s.data, s.pos, toCopy);
         s.pos += toCopy;
         this.size -= (long)toCopy;
         byteCount -= (long)toCopy;
         if (s.pos == s.limit) {
            Segment toRecycle = s;
            s = s.pop();
            this.head = s;
            SegmentPool.recycle(toRecycle);
         }
      }

      return this;
   }

   // $FF: synthetic method
   public static Buffer writeTo$default(Buffer var0, OutputStream var1, long var2, int var4, Object var5) throws IOException {
      if ((var4 & 2) != 0) {
         var2 = var0.size;
      }

      return var0.writeTo(var1, var2);
   }

   @JvmOverloads
   @NotNull
   public final Buffer writeTo(@NotNull OutputStream out) throws IOException {
      return writeTo$default(this, out, 0L, 2, (Object)null);
   }

   @NotNull
   public final Buffer readFrom(@NotNull InputStream input) throws IOException {
      Intrinsics.checkNotNullParameter(input, "input");
      this.readFrom(input, Long.MAX_VALUE, true);
      return this;
   }

   @NotNull
   public final Buffer readFrom(@NotNull InputStream input, long byteCount) throws IOException {
      Intrinsics.checkNotNullParameter(input, "input");
      boolean var4 = byteCount >= 0L;
      boolean var5 = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var8 = "byteCount < 0: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var8.toString()));
      } else {
         this.readFrom(input, byteCount, false);
         return this;
      }
   }

   private final void readFrom(InputStream input, long byteCount, boolean forever) throws IOException {
      int bytesRead;
      for(long byteCount = byteCount; byteCount > 0L || forever; byteCount -= (long)bytesRead) {
         Segment tail = this.writableSegment$okio(1);
         bytesRead = 8192 - tail.limit;
         int $i$f$minOf = false;
         long var11 = (long)bytesRead;
         boolean var13 = false;
         int maxToCopy = (int)Math.min(byteCount, var11);
         bytesRead = input.read(tail.data, tail.limit, maxToCopy);
         if (bytesRead == -1) {
            if (tail.pos == tail.limit) {
               this.head = tail.pop();
               SegmentPool.recycle(tail);
            }

            if (forever) {
               return;
            }

            throw (Throwable)(new EOFException());
         }

         tail.limit += bytesRead;
         this.size += (long)bytesRead;
      }

   }

   public final long completeSegmentByteCount() {
      int $i$f$commonCompleteSegmentByteCount = false;
      long result$iv = this.size();
      long var10000;
      if (result$iv == 0L) {
         var10000 = 0L;
      } else {
         Segment var6 = this.head;
         Intrinsics.checkNotNull(var6);
         var6 = var6.prev;
         Intrinsics.checkNotNull(var6);
         Segment tail$iv = var6;
         if (tail$iv.limit < 8192 && tail$iv.owner) {
            result$iv -= (long)(tail$iv.limit - tail$iv.pos);
         }

         var10000 = result$iv;
      }

      return var10000;
   }

   public byte readByte() throws EOFException {
      int $i$f$commonReadByte = false;
      if (this.size() == 0L) {
         throw (Throwable)(new EOFException());
      } else {
         Segment var10000 = this.head;
         Intrinsics.checkNotNull(var10000);
         Segment segment$iv = var10000;
         int pos$iv = segment$iv.pos;
         int limit$iv = segment$iv.limit;
         byte[] data$iv = segment$iv.data;
         byte b$iv = data$iv[pos$iv++];
         this.setSize$okio(this.size() - 1L);
         if (pos$iv == limit$iv) {
            this.head = segment$iv.pop();
            SegmentPool.recycle(segment$iv);
         } else {
            segment$iv.pos = pos$iv;
         }

         return b$iv;
      }
   }

   @JvmName(
      name = "getByte"
   )
   public final byte getByte(long pos) {
      int $i$f$commonGet = false;
      -Util.checkOffsetAndCount(this.size(), pos, 1L);
      int $i$f$seek = false;
      Segment var10000 = this.head;
      long nextOffset$iv$iv;
      byte var21;
      if (var10000 != null) {
         Segment s$iv$iv = var10000;
         long offset$iv$iv;
         if (this.size() - pos < pos) {
            for(offset$iv$iv = this.size(); offset$iv$iv > pos; offset$iv$iv -= (long)(s$iv$iv.limit - s$iv$iv.pos)) {
               var10000 = s$iv$iv.prev;
               Intrinsics.checkNotNull(var10000);
               s$iv$iv = var10000;
            }

            int var17 = false;
            Intrinsics.checkNotNull(s$iv$iv);
            var21 = s$iv$iv.data[(int)((long)s$iv$iv.pos + pos - offset$iv$iv)];
         } else {
            offset$iv$iv = 0L;

            while(true) {
               nextOffset$iv$iv = offset$iv$iv + (long)(s$iv$iv.limit - s$iv$iv.pos);
               if (nextOffset$iv$iv > pos) {
                  int var20 = false;
                  Intrinsics.checkNotNull(s$iv$iv);
                  var21 = s$iv$iv.data[(int)((long)s$iv$iv.pos + pos - offset$iv$iv)];
                  break;
               }

               var10000 = s$iv$iv.next;
               Intrinsics.checkNotNull(var10000);
               s$iv$iv = var10000;
               offset$iv$iv = nextOffset$iv$iv;
            }
         }
      } else {
         nextOffset$iv$iv = -1L;
         Segment s$iv = (Segment)null;
         int var10 = false;
         Intrinsics.checkNotNull(s$iv);
         var21 = s$iv.data[(int)((long)s$iv.pos + pos - nextOffset$iv$iv)];
      }

      return var21;
   }

   public short readShort() throws EOFException {
      int $i$f$commonReadShort = false;
      if (this.size() < 2L) {
         throw (Throwable)(new EOFException());
      } else {
         Segment var10000 = this.head;
         Intrinsics.checkNotNull(var10000);
         Segment segment$iv = var10000;
         int pos$iv = segment$iv.pos;
         int limit$iv = segment$iv.limit;
         int var15;
         short var16;
         if (limit$iv - pos$iv < 2) {
            byte $this$and$iv$iv = this.readByte();
            int other$iv$iv = 255;
            int $i$f$and = false;
            var15 = ($this$and$iv$iv & other$iv$iv) << 8;
            $this$and$iv$iv = this.readByte();
            other$iv$iv = 255;
            $i$f$and = false;
            int s$iv = var15 | $this$and$iv$iv & other$iv$iv;
            var16 = (short)s$iv;
         } else {
            byte[] data$iv = segment$iv.data;
            byte $this$and$iv$iv = data$iv[pos$iv++];
            int other$iv$iv = 255;
            int $i$f$and = false;
            var15 = ($this$and$iv$iv & other$iv$iv) << 8;
            $this$and$iv$iv = data$iv[pos$iv++];
            other$iv$iv = 255;
            $i$f$and = false;
            int s$iv = var15 | $this$and$iv$iv & other$iv$iv;
            this.setSize$okio(this.size() - 2L);
            if (pos$iv == limit$iv) {
               this.head = segment$iv.pop();
               SegmentPool.recycle(segment$iv);
            } else {
               segment$iv.pos = pos$iv;
            }

            var16 = (short)s$iv;
         }

         return var16;
      }
   }

   public int readInt() throws EOFException {
      int $i$f$commonReadInt = false;
      if (this.size() < 4L) {
         throw (Throwable)(new EOFException());
      } else {
         Segment var10000 = this.head;
         Intrinsics.checkNotNull(var10000);
         Segment segment$iv = var10000;
         int pos$iv = segment$iv.pos;
         int limit$iv = segment$iv.limit;
         int var14;
         if ((long)(limit$iv - pos$iv) < 4L) {
            byte $this$and$iv$iv = this.readByte();
            int other$iv$iv = 255;
            int $i$f$and = false;
            var14 = ($this$and$iv$iv & other$iv$iv) << 24;
            $this$and$iv$iv = this.readByte();
            other$iv$iv = 255;
            $i$f$and = false;
            var14 |= ($this$and$iv$iv & other$iv$iv) << 16;
            $this$and$iv$iv = this.readByte();
            other$iv$iv = 255;
            $i$f$and = false;
            var14 |= ($this$and$iv$iv & other$iv$iv) << 8;
            $this$and$iv$iv = this.readByte();
            other$iv$iv = 255;
            $i$f$and = false;
            var14 |= $this$and$iv$iv & other$iv$iv;
         } else {
            byte[] data$iv = segment$iv.data;
            byte $this$and$iv$iv = data$iv[pos$iv++];
            int other$iv$iv = 255;
            int $i$f$and = false;
            var14 = ($this$and$iv$iv & other$iv$iv) << 24;
            $this$and$iv$iv = data$iv[pos$iv++];
            other$iv$iv = 255;
            $i$f$and = false;
            var14 |= ($this$and$iv$iv & other$iv$iv) << 16;
            $this$and$iv$iv = data$iv[pos$iv++];
            other$iv$iv = 255;
            $i$f$and = false;
            var14 |= ($this$and$iv$iv & other$iv$iv) << 8;
            $this$and$iv$iv = data$iv[pos$iv++];
            other$iv$iv = 255;
            $i$f$and = false;
            int i$iv = var14 | $this$and$iv$iv & other$iv$iv;
            this.setSize$okio(this.size() - 4L);
            if (pos$iv == limit$iv) {
               this.head = segment$iv.pop();
               SegmentPool.recycle(segment$iv);
            } else {
               segment$iv.pos = pos$iv;
            }

            var14 = i$iv;
         }

         return var14;
      }
   }

   public long readLong() throws EOFException {
      int $i$f$commonReadLong = false;
      if (this.size() < 8L) {
         throw (Throwable)(new EOFException());
      } else {
         Segment var10000 = this.head;
         Intrinsics.checkNotNull(var10000);
         Segment segment$iv = var10000;
         int pos$iv = segment$iv.pos;
         int limit$iv = segment$iv.limit;
         long v$iv;
         long var15;
         if ((long)(limit$iv - pos$iv) < 8L) {
            int $this$and$iv$iv = this.readInt();
            v$iv = 4294967295L;
            int $i$f$and = false;
            var15 = ((long)$this$and$iv$iv & v$iv) << 32;
            $this$and$iv$iv = this.readInt();
            v$iv = 4294967295L;
            $i$f$and = false;
            var15 |= (long)$this$and$iv$iv & v$iv;
         } else {
            byte[] data$iv = segment$iv.data;
            byte $this$and$iv$iv = data$iv[pos$iv++];
            long other$iv$iv = 255L;
            int $i$f$and = false;
            var15 = ((long)$this$and$iv$iv & other$iv$iv) << 56;
            $this$and$iv$iv = data$iv[pos$iv++];
            other$iv$iv = 255L;
            $i$f$and = false;
            var15 |= ((long)$this$and$iv$iv & other$iv$iv) << 48;
            $this$and$iv$iv = data$iv[pos$iv++];
            other$iv$iv = 255L;
            $i$f$and = false;
            var15 |= ((long)$this$and$iv$iv & other$iv$iv) << 40;
            $this$and$iv$iv = data$iv[pos$iv++];
            other$iv$iv = 255L;
            $i$f$and = false;
            var15 |= ((long)$this$and$iv$iv & other$iv$iv) << 32;
            $this$and$iv$iv = data$iv[pos$iv++];
            other$iv$iv = 255L;
            $i$f$and = false;
            var15 |= ((long)$this$and$iv$iv & other$iv$iv) << 24;
            $this$and$iv$iv = data$iv[pos$iv++];
            other$iv$iv = 255L;
            $i$f$and = false;
            var15 |= ((long)$this$and$iv$iv & other$iv$iv) << 16;
            $this$and$iv$iv = data$iv[pos$iv++];
            other$iv$iv = 255L;
            $i$f$and = false;
            var15 |= ((long)$this$and$iv$iv & other$iv$iv) << 8;
            $this$and$iv$iv = data$iv[pos$iv++];
            other$iv$iv = 255L;
            $i$f$and = false;
            v$iv = var15 | (long)$this$and$iv$iv & other$iv$iv;
            this.setSize$okio(this.size() - 8L);
            if (pos$iv == limit$iv) {
               this.head = segment$iv.pop();
               SegmentPool.recycle(segment$iv);
            } else {
               segment$iv.pos = pos$iv;
            }

            var15 = v$iv;
         }

         return var15;
      }
   }

   public short readShortLe() throws EOFException {
      return -Util.reverseBytes(this.readShort());
   }

   public int readIntLe() throws EOFException {
      return -Util.reverseBytes(this.readInt());
   }

   public long readLongLe() throws EOFException {
      return -Util.reverseBytes(this.readLong());
   }

   public long readDecimalLong() throws EOFException {
      Buffer $this$commonReadDecimalLong$iv = this;
      int $i$f$commonReadDecimalLong = false;
      if (this.size() == 0L) {
         throw (Throwable)(new EOFException());
      } else {
         long value$iv = 0L;
         int seen$iv = 0;
         boolean negative$iv = false;
         boolean done$iv = false;
         long overflowDigit$iv = -7L;

         while(true) {
            Segment var10000 = $this$commonReadDecimalLong$iv.head;
            Intrinsics.checkNotNull(var10000);
            Segment segment$iv = var10000;
            byte[] data$iv = segment$iv.data;
            int pos$iv = segment$iv.pos;
            int limit$iv = segment$iv.limit;

            while(true) {
               label72: {
                  if (pos$iv < limit$iv) {
                     byte b$iv = data$iv[pos$iv];
                     if (b$iv >= (byte)48 && b$iv <= (byte)57) {
                        int digit$iv = (byte)48 - b$iv;
                        if (value$iv < -922337203685477580L || value$iv == -922337203685477580L && (long)digit$iv < overflowDigit$iv) {
                           Buffer buffer$iv = (new Buffer()).writeDecimalLong(value$iv).writeByte(b$iv);
                           if (!negative$iv) {
                              buffer$iv.readByte();
                           }

                           throw (Throwable)(new NumberFormatException("Number too large: " + buffer$iv.readUtf8()));
                        }

                        value$iv *= 10L;
                        value$iv += (long)digit$iv;
                        break label72;
                     }

                     if (b$iv == (byte)45 && seen$iv == 0) {
                        negative$iv = true;
                        --overflowDigit$iv;
                        break label72;
                     }

                     if (seen$iv == 0) {
                        throw (Throwable)(new NumberFormatException("Expected leading [0-9] or '-' character but was 0x" + -Util.toHexString(b$iv)));
                     }

                     done$iv = true;
                  }

                  if (pos$iv == limit$iv) {
                     $this$commonReadDecimalLong$iv.head = segment$iv.pop();
                     SegmentPool.recycle(segment$iv);
                  } else {
                     segment$iv.pos = pos$iv;
                  }

                  if (!done$iv && $this$commonReadDecimalLong$iv.head != null) {
                     break;
                  }

                  $this$commonReadDecimalLong$iv.setSize$okio($this$commonReadDecimalLong$iv.size() - (long)seen$iv);
                  return negative$iv ? value$iv : -value$iv;
               }

               ++pos$iv;
               ++seen$iv;
            }
         }
      }
   }

   public long readHexadecimalUnsignedLong() throws EOFException {
      Buffer $this$commonReadHexadecimalUnsignedLong$iv = this;
      int $i$f$commonReadHexadecimalUnsignedLong = false;
      if (this.size() == 0L) {
         throw (Throwable)(new EOFException());
      } else {
         long value$iv = 0L;
         int seen$iv = 0;
         boolean done$iv = false;

         do {
            Segment var10000 = $this$commonReadHexadecimalUnsignedLong$iv.head;
            Intrinsics.checkNotNull(var10000);
            Segment segment$iv = var10000;
            byte[] data$iv = segment$iv.data;
            int pos$iv = segment$iv.pos;

            int limit$iv;
            for(limit$iv = segment$iv.limit; pos$iv < limit$iv; ++seen$iv) {
               int digit$iv = false;
               byte b$iv = data$iv[pos$iv];
               int digit$iv;
               if (b$iv >= (byte)48 && b$iv <= (byte)57) {
                  digit$iv = b$iv - (byte)48;
               } else if (b$iv >= (byte)97 && b$iv <= (byte)102) {
                  digit$iv = b$iv - (byte)97 + 10;
               } else {
                  if (b$iv < (byte)65 || b$iv > (byte)70) {
                     if (seen$iv == 0) {
                        throw (Throwable)(new NumberFormatException("Expected leading [0-9a-fA-F] character but was 0x" + -Util.toHexString(b$iv)));
                     }

                     done$iv = true;
                     break;
                  }

                  digit$iv = b$iv - (byte)65 + 10;
               }

               if ((value$iv & -1152921504606846976L) != 0L) {
                  Buffer buffer$iv = (new Buffer()).writeHexadecimalUnsignedLong(value$iv).writeByte(b$iv);
                  throw (Throwable)(new NumberFormatException("Number too large: " + buffer$iv.readUtf8()));
               }

               value$iv <<= 4;
               value$iv |= (long)digit$iv;
               ++pos$iv;
            }

            if (pos$iv == limit$iv) {
               $this$commonReadHexadecimalUnsignedLong$iv.head = segment$iv.pop();
               SegmentPool.recycle(segment$iv);
            } else {
               segment$iv.pos = pos$iv;
            }
         } while(!done$iv && $this$commonReadHexadecimalUnsignedLong$iv.head != null);

         $this$commonReadHexadecimalUnsignedLong$iv.setSize$okio($this$commonReadHexadecimalUnsignedLong$iv.size() - (long)seen$iv);
         return value$iv;
      }
   }

   @NotNull
   public ByteString readByteString() {
      int $i$f$commonReadByteString = false;
      return this.readByteString(this.size());
   }

   @NotNull
   public ByteString readByteString(long byteCount) throws EOFException {
      int $i$f$commonReadByteString = false;
      boolean var5 = byteCount >= 0L && byteCount <= (long)Integer.MAX_VALUE;
      boolean var6 = false;
      boolean var7 = false;
      if (!var5) {
         int var8 = false;
         String var11 = "byteCount: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var11.toString()));
      } else if (this.size() < byteCount) {
         throw (Throwable)(new EOFException());
      } else {
         ByteString var10000;
         if (byteCount >= (long)4096) {
            ByteString var10 = this.snapshot((int)byteCount);
            var6 = false;
            var7 = false;
            int var9 = false;
            this.skip(byteCount);
            var10000 = var10;
         } else {
            var10000 = new ByteString(this.readByteArray(byteCount));
         }

         return var10000;
      }
   }

   public int select(@NotNull Options options) {
      Intrinsics.checkNotNullParameter(options, "options");
      int $i$f$commonSelect = false;
      int index$iv = BufferKt.selectPrefix$default(this, options, false, 2, (Object)null);
      int var10000;
      if (index$iv == -1) {
         var10000 = -1;
      } else {
         int selectedSize$iv = options.getByteStrings$okio()[index$iv].size();
         this.skip((long)selectedSize$iv);
         var10000 = index$iv;
      }

      return var10000;
   }

   public void readFully(@NotNull Buffer sink, long byteCount) throws EOFException {
      Intrinsics.checkNotNullParameter(sink, "sink");
      int $i$f$commonReadFully = false;
      if (this.size() < byteCount) {
         sink.write(this, this.size());
         throw (Throwable)(new EOFException());
      } else {
         sink.write(this, byteCount);
      }
   }

   public long readAll(@NotNull Sink sink) throws IOException {
      Intrinsics.checkNotNullParameter(sink, "sink");
      int $i$f$commonReadAll = false;
      long byteCount$iv = this.size();
      if (byteCount$iv > 0L) {
         sink.write(this, byteCount$iv);
      }

      return byteCount$iv;
   }

   @NotNull
   public String readUtf8() {
      return this.readString(this.size, Charsets.UTF_8);
   }

   @NotNull
   public String readUtf8(long byteCount) throws EOFException {
      return this.readString(byteCount, Charsets.UTF_8);
   }

   @NotNull
   public String readString(@NotNull Charset charset) {
      Intrinsics.checkNotNullParameter(charset, "charset");
      return this.readString(this.size, charset);
   }

   @NotNull
   public String readString(long byteCount, @NotNull Charset charset) throws EOFException {
      Intrinsics.checkNotNullParameter(charset, "charset");
      boolean var4 = byteCount >= 0L && byteCount <= (long)Integer.MAX_VALUE;
      boolean var5 = false;
      boolean var6 = false;
      if (!var4) {
         int var15 = false;
         String var14 = "byteCount: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var14.toString()));
      } else if (this.size < byteCount) {
         throw (Throwable)(new EOFException());
      } else if (byteCount == 0L) {
         return "";
      } else {
         Segment var10000 = this.head;
         Intrinsics.checkNotNull(var10000);
         Segment s = var10000;
         if ((long)s.pos + byteCount > (long)s.limit) {
            byte[] var12 = this.readByteArray(byteCount);
            var6 = false;
            return new String(var12, charset);
         } else {
            byte[] var13 = s.data;
            int var7 = s.pos;
            int var8 = (int)byteCount;
            boolean var9 = false;
            String result = new String(var13, var7, var8, charset);
            s.pos += (int)byteCount;
            this.size -= byteCount;
            if (s.pos == s.limit) {
               this.head = s.pop();
               SegmentPool.recycle(s);
            }

            return result;
         }
      }
   }

   @Nullable
   public String readUtf8Line() throws EOFException {
      int $i$f$commonReadUtf8Line = false;
      long newline$iv = this.indexOf((byte)10);
      return newline$iv != -1L ? BufferKt.readUtf8Line(this, newline$iv) : (this.size() != 0L ? this.readUtf8(this.size()) : null);
   }

   @NotNull
   public String readUtf8LineStrict() throws EOFException {
      return this.readUtf8LineStrict(Long.MAX_VALUE);
   }

   @NotNull
   public String readUtf8LineStrict(long limit) throws EOFException {
      int $i$f$commonReadUtf8LineStrict = false;
      boolean var5 = limit >= 0L;
      boolean var6 = false;
      boolean var7 = false;
      if (!var5) {
         int var8 = false;
         String var24 = "limit < 0: " + limit;
         throw (Throwable)(new IllegalArgumentException(var24.toString()));
      } else {
         long scanLength$iv = limit == Long.MAX_VALUE ? Long.MAX_VALUE : limit + 1L;
         long newline$iv = this.indexOf((byte)10, 0L, scanLength$iv);
         String var10000;
         if (newline$iv != -1L) {
            var10000 = BufferKt.readUtf8Line(this, newline$iv);
         } else {
            if (scanLength$iv >= this.size() || this.getByte(scanLength$iv - 1L) != (byte)13 || this.getByte(scanLength$iv) != (byte)10) {
               Buffer data$iv = new Buffer();
               byte a$iv$iv = 32;
               long b$iv$iv = this.size();
               int $i$f$minOf = false;
               long var18 = (long)a$iv$iv;
               boolean var20 = false;
               this.copyTo(data$iv, 0L, Math.min(var18, b$iv$iv));
               StringBuilder var10002 = (new StringBuilder()).append("\\n not found: limit=");
               long var21 = this.size();
               boolean var23 = false;
               throw (Throwable)(new EOFException(var10002.append(Math.min(var21, limit)).append(" content=").append(data$iv.readByteString().hex()).append('…').toString()));
            }

            var10000 = BufferKt.readUtf8Line(this, scanLength$iv);
         }

         return var10000;
      }
   }

   public int readUtf8CodePoint() throws EOFException {
      Buffer $this$commonReadUtf8CodePoint$iv = this;
      int $i$f$commonReadUtf8CodePoint = false;
      if (this.size() == 0L) {
         throw (Throwable)(new EOFException());
      } else {
         byte b0$iv = this.getByte(0L);
         int codePoint$iv = false;
         int byteCount$iv = false;
         int min$iv = false;
         int other$iv$iv = 128;
         int $i$f$and = false;
         int codePoint$iv;
         byte byteCount$iv;
         int min$iv;
         byte other$iv$iv;
         int var10000;
         if ((b0$iv & other$iv$iv) == 0) {
            other$iv$iv = 127;
            $i$f$and = false;
            codePoint$iv = b0$iv & other$iv$iv;
            byteCount$iv = 1;
            min$iv = 0;
         } else {
            other$iv$iv = 224;
            $i$f$and = false;
            if ((b0$iv & other$iv$iv) == 192) {
               other$iv$iv = 31;
               $i$f$and = false;
               codePoint$iv = b0$iv & other$iv$iv;
               byteCount$iv = 2;
               min$iv = 128;
            } else {
               other$iv$iv = 240;
               $i$f$and = false;
               if ((b0$iv & other$iv$iv) == 224) {
                  other$iv$iv = 15;
                  $i$f$and = false;
                  codePoint$iv = b0$iv & other$iv$iv;
                  byteCount$iv = 3;
                  min$iv = 2048;
               } else {
                  other$iv$iv = 248;
                  $i$f$and = false;
                  if ((b0$iv & other$iv$iv) != 240) {
                     this.skip(1L);
                     var10000 = 65533;
                     return var10000;
                  }

                  other$iv$iv = 7;
                  $i$f$and = false;
                  codePoint$iv = b0$iv & other$iv$iv;
                  byteCount$iv = 4;
                  min$iv = 65536;
               }
            }
         }

         if (this.size() < (long)byteCount$iv) {
            throw (Throwable)(new EOFException("size < " + byteCount$iv + ": " + this.size() + " (to read code point prefixed 0x" + -Util.toHexString(b0$iv) + ')'));
         } else {
            int i$iv = 1;
            other$iv$iv = byteCount$iv;

            while(true) {
               if (i$iv >= other$iv$iv) {
                  $this$commonReadUtf8CodePoint$iv.skip((long)byteCount$iv);
                  if (codePoint$iv > 1114111) {
                     var10000 = 65533;
                  } else {
                     if (55296 <= codePoint$iv) {
                        if (57343 >= codePoint$iv) {
                           var10000 = 65533;
                           break;
                        }
                     }

                     var10000 = codePoint$iv < min$iv ? '�' : codePoint$iv;
                  }
                  break;
               }

               byte b$iv = $this$commonReadUtf8CodePoint$iv.getByte((long)i$iv);
               int other$iv$iv = 192;
               int $i$f$and = false;
               if ((b$iv & other$iv$iv) != 128) {
                  $this$commonReadUtf8CodePoint$iv.skip((long)i$iv);
                  var10000 = 65533;
                  break;
               }

               codePoint$iv <<= 6;
               int other$iv$iv = 63;
               $i$f$and = false;
               codePoint$iv |= b$iv & other$iv$iv;
               ++i$iv;
            }

            return var10000;
         }
      }
   }

   @NotNull
   public byte[] readByteArray() {
      int $i$f$commonReadByteArray = false;
      return this.readByteArray(this.size());
   }

   @NotNull
   public byte[] readByteArray(long byteCount) throws EOFException {
      int $i$f$commonReadByteArray = false;
      boolean var5 = byteCount >= 0L && byteCount <= (long)Integer.MAX_VALUE;
      boolean var6 = false;
      boolean var7 = false;
      if (!var5) {
         int var8 = false;
         String var10 = "byteCount: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var10.toString()));
      } else if (this.size() < byteCount) {
         throw (Throwable)(new EOFException());
      } else {
         byte[] result$iv = new byte[(int)byteCount];
         this.readFully(result$iv);
         return result$iv;
      }
   }

   public int read(@NotNull byte[] sink) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      int $i$f$commonRead = false;
      return this.read(sink, 0, sink.length);
   }

   public void readFully(@NotNull byte[] sink) throws EOFException {
      Intrinsics.checkNotNullParameter(sink, "sink");
      Buffer $this$commonReadFully$iv = this;
      int $i$f$commonReadFully = false;

      int read$iv;
      for(int offset$iv = 0; offset$iv < sink.length; offset$iv += read$iv) {
         read$iv = $this$commonReadFully$iv.read(sink, offset$iv, sink.length - offset$iv);
         if (read$iv == -1) {
            throw (Throwable)(new EOFException());
         }
      }

   }

   public int read(@NotNull byte[] sink, int offset, int byteCount) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      int $i$f$commonRead = false;
      -Util.checkOffsetAndCount((long)sink.length, (long)offset, (long)byteCount);
      Segment var10000 = this.head;
      int var10;
      if (var10000 != null) {
         Segment s$iv = var10000;
         int var7 = s$iv.limit - s$iv.pos;
         boolean var8 = false;
         int toCopy$iv = Math.min(byteCount, var7);
         ArraysKt.copyInto(s$iv.data, sink, offset, s$iv.pos, s$iv.pos + toCopy$iv);
         s$iv.pos += toCopy$iv;
         this.setSize$okio(this.size() - (long)toCopy$iv);
         if (s$iv.pos == s$iv.limit) {
            this.head = s$iv.pop();
            SegmentPool.recycle(s$iv);
         }

         var10 = toCopy$iv;
      } else {
         var10 = -1;
      }

      return var10;
   }

   public int read(@NotNull ByteBuffer sink) throws IOException {
      Intrinsics.checkNotNullParameter(sink, "sink");
      Segment var10000 = this.head;
      if (var10000 != null) {
         Segment s = var10000;
         int var4 = sink.remaining();
         int var5 = s.limit - s.pos;
         boolean var6 = false;
         int toCopy = Math.min(var4, var5);
         sink.put(s.data, s.pos, toCopy);
         s.pos += toCopy;
         this.size -= (long)toCopy;
         if (s.pos == s.limit) {
            this.head = s.pop();
            SegmentPool.recycle(s);
         }

         return toCopy;
      } else {
         return -1;
      }
   }

   public final void clear() {
      int $i$f$commonClear = false;
      this.skip(this.size());
   }

   public void skip(long byteCount) throws EOFException {
      Buffer $this$commonSkip$iv = this;
      int $i$f$commonSkip = false;
      long byteCount$iv = byteCount;

      while(byteCount$iv > 0L) {
         Segment var10000 = $this$commonSkip$iv.head;
         if (var10000 == null) {
            throw (Throwable)(new EOFException());
         }

         Segment head$iv = var10000;
         int b$iv$iv = head$iv.limit - head$iv.pos;
         int $i$f$minOf = false;
         long var10 = (long)b$iv$iv;
         boolean var12 = false;
         int toSkip$iv = (int)Math.min(byteCount$iv, var10);
         $this$commonSkip$iv.setSize$okio($this$commonSkip$iv.size() - (long)toSkip$iv);
         byteCount$iv -= (long)toSkip$iv;
         head$iv.pos += toSkip$iv;
         if (head$iv.pos == head$iv.limit) {
            $this$commonSkip$iv.head = head$iv.pop();
            SegmentPool.recycle(head$iv);
         }
      }

   }

   @NotNull
   public Buffer write(@NotNull ByteString byteString) {
      Intrinsics.checkNotNullParameter(byteString, "byteString");
      int offset$iv = 0;
      int byteCount$iv = byteString.size();
      int $i$f$commonWrite = false;
      byteString.write$okio(this, offset$iv, byteCount$iv);
      return this;
   }

   @NotNull
   public Buffer write(@NotNull ByteString byteString, int offset, int byteCount) {
      Intrinsics.checkNotNullParameter(byteString, "byteString");
      int $i$f$commonWrite = false;
      byteString.write$okio(this, offset, byteCount);
      return this;
   }

   @NotNull
   public Buffer writeUtf8(@NotNull String string) {
      Intrinsics.checkNotNullParameter(string, "string");
      return this.writeUtf8(string, 0, string.length());
   }

   @NotNull
   public Buffer writeUtf8(@NotNull String string, int beginIndex, int endIndex) {
      Intrinsics.checkNotNullParameter(string, "string");
      Buffer $this$commonWriteUtf8$iv = this;
      int $i$f$commonWriteUtf8 = false;
      boolean var6 = beginIndex >= 0;
      boolean var7 = false;
      boolean var8 = false;
      boolean var19;
      String var20;
      if (!var6) {
         var19 = false;
         var20 = "beginIndex < 0: " + beginIndex;
         throw (Throwable)(new IllegalArgumentException(var20.toString()));
      } else {
         var6 = endIndex >= beginIndex;
         var7 = false;
         var8 = false;
         if (!var6) {
            var19 = false;
            var20 = "endIndex < beginIndex: " + endIndex + " < " + beginIndex;
            throw (Throwable)(new IllegalArgumentException(var20.toString()));
         } else {
            var6 = endIndex <= string.length();
            var7 = false;
            var8 = false;
            if (!var6) {
               var19 = false;
               var20 = "endIndex > string.length: " + endIndex + " > " + string.length();
               throw (Throwable)(new IllegalArgumentException(var20.toString()));
            } else {
               int i$iv = beginIndex;

               while(true) {
                  while(i$iv < endIndex) {
                     int c$iv = string.charAt(i$iv);
                     Segment tail$iv;
                     if (c$iv < 128) {
                        tail$iv = $this$commonWriteUtf8$iv.writableSegment$okio(1);
                        byte[] data$iv = tail$iv.data;
                        int segmentOffset$iv = tail$iv.limit - i$iv;
                        int runSize$iv = 8192 - segmentOffset$iv;
                        boolean var12 = false;
                        int runLimit$iv = Math.min(endIndex, runSize$iv);

                        for(data$iv[segmentOffset$iv + i$iv++] = (byte)c$iv; i$iv < runLimit$iv; data$iv[segmentOffset$iv + i$iv++] = (byte)c$iv) {
                           c$iv = string.charAt(i$iv);
                           if (c$iv >= 128) {
                              break;
                           }
                        }

                        runSize$iv = i$iv + segmentOffset$iv - tail$iv.limit;
                        tail$iv.limit += runSize$iv;
                        $this$commonWriteUtf8$iv.setSize$okio($this$commonWriteUtf8$iv.size() + (long)runSize$iv);
                     } else if (c$iv < 2048) {
                        tail$iv = $this$commonWriteUtf8$iv.writableSegment$okio(2);
                        tail$iv.data[tail$iv.limit] = (byte)(c$iv >> 6 | 192);
                        tail$iv.data[tail$iv.limit + 1] = (byte)(c$iv & 63 | 128);
                        tail$iv.limit += 2;
                        $this$commonWriteUtf8$iv.setSize$okio($this$commonWriteUtf8$iv.size() + 2L);
                        ++i$iv;
                     } else if (c$iv >= '\ud800' && c$iv <= '\udfff') {
                        int low$iv = i$iv + 1 < endIndex ? string.charAt(i$iv + 1) : 0;
                        if (c$iv <= '\udbff') {
                           if ('\udc00' <= low$iv) {
                              if ('\udfff' >= low$iv) {
                                 int codePoint$iv = 65536 + ((c$iv & 1023) << 10 | low$iv & 1023);
                                 Segment tail$iv = $this$commonWriteUtf8$iv.writableSegment$okio(4);
                                 tail$iv.data[tail$iv.limit] = (byte)(codePoint$iv >> 18 | 240);
                                 tail$iv.data[tail$iv.limit + 1] = (byte)(codePoint$iv >> 12 & 63 | 128);
                                 tail$iv.data[tail$iv.limit + 2] = (byte)(codePoint$iv >> 6 & 63 | 128);
                                 tail$iv.data[tail$iv.limit + 3] = (byte)(codePoint$iv & 63 | 128);
                                 tail$iv.limit += 4;
                                 $this$commonWriteUtf8$iv.setSize$okio($this$commonWriteUtf8$iv.size() + 4L);
                                 i$iv += 2;
                                 continue;
                              }
                           }
                        }

                        $this$commonWriteUtf8$iv.writeByte(63);
                        ++i$iv;
                     } else {
                        tail$iv = $this$commonWriteUtf8$iv.writableSegment$okio(3);
                        tail$iv.data[tail$iv.limit] = (byte)(c$iv >> 12 | 224);
                        tail$iv.data[tail$iv.limit + 1] = (byte)(c$iv >> 6 & 63 | 128);
                        tail$iv.data[tail$iv.limit + 2] = (byte)(c$iv & 63 | 128);
                        tail$iv.limit += 3;
                        $this$commonWriteUtf8$iv.setSize$okio($this$commonWriteUtf8$iv.size() + 3L);
                        ++i$iv;
                     }
                  }

                  return $this$commonWriteUtf8$iv;
               }
            }
         }
      }
   }

   @NotNull
   public Buffer writeUtf8CodePoint(int codePoint) {
      int $i$f$commonWriteUtf8CodePoint = false;
      if (codePoint < 128) {
         this.writeByte(codePoint);
      } else {
         Segment tail$iv;
         if (codePoint < 2048) {
            tail$iv = this.writableSegment$okio(2);
            tail$iv.data[tail$iv.limit] = (byte)(codePoint >> 6 | 192);
            tail$iv.data[tail$iv.limit + 1] = (byte)(codePoint & 63 | 128);
            tail$iv.limit += 2;
            this.setSize$okio(this.size() + 2L);
         } else {
            if (55296 <= codePoint) {
               if (57343 >= codePoint) {
                  this.writeByte(63);
                  return this;
               }
            }

            if (codePoint < 65536) {
               tail$iv = this.writableSegment$okio(3);
               tail$iv.data[tail$iv.limit] = (byte)(codePoint >> 12 | 224);
               tail$iv.data[tail$iv.limit + 1] = (byte)(codePoint >> 6 & 63 | 128);
               tail$iv.data[tail$iv.limit + 2] = (byte)(codePoint & 63 | 128);
               tail$iv.limit += 3;
               this.setSize$okio(this.size() + 3L);
            } else {
               if (codePoint > 1114111) {
                  throw (Throwable)(new IllegalArgumentException("Unexpected code point: 0x" + -Util.toHexString(codePoint)));
               }

               tail$iv = this.writableSegment$okio(4);
               tail$iv.data[tail$iv.limit] = (byte)(codePoint >> 18 | 240);
               tail$iv.data[tail$iv.limit + 1] = (byte)(codePoint >> 12 & 63 | 128);
               tail$iv.data[tail$iv.limit + 2] = (byte)(codePoint >> 6 & 63 | 128);
               tail$iv.data[tail$iv.limit + 3] = (byte)(codePoint & 63 | 128);
               tail$iv.limit += 4;
               this.setSize$okio(this.size() + 4L);
            }
         }
      }

      return this;
   }

   @NotNull
   public Buffer writeString(@NotNull String string, @NotNull Charset charset) {
      Intrinsics.checkNotNullParameter(string, "string");
      Intrinsics.checkNotNullParameter(charset, "charset");
      return this.writeString(string, 0, string.length(), charset);
   }

   @NotNull
   public Buffer writeString(@NotNull String string, int beginIndex, int endIndex, @NotNull Charset charset) {
      Intrinsics.checkNotNullParameter(string, "string");
      Intrinsics.checkNotNullParameter(charset, "charset");
      boolean var5 = beginIndex >= 0;
      boolean var6 = false;
      boolean var7 = false;
      boolean var8;
      String var11;
      if (!var5) {
         var8 = false;
         var11 = "beginIndex < 0: " + beginIndex;
         throw (Throwable)(new IllegalArgumentException(var11.toString()));
      } else {
         var5 = endIndex >= beginIndex;
         var6 = false;
         var7 = false;
         if (!var5) {
            var8 = false;
            var11 = "endIndex < beginIndex: " + endIndex + " < " + beginIndex;
            throw (Throwable)(new IllegalArgumentException(var11.toString()));
         } else {
            var5 = endIndex <= string.length();
            var6 = false;
            var7 = false;
            if (!var5) {
               var8 = false;
               var11 = "endIndex > string.length: " + endIndex + " > " + string.length();
               throw (Throwable)(new IllegalArgumentException(var11.toString()));
            } else if (Intrinsics.areEqual((Object)charset, (Object)Charsets.UTF_8)) {
               return this.writeUtf8(string, beginIndex, endIndex);
            } else {
               var7 = false;
               String var10000 = string.substring(beginIndex, endIndex);
               Intrinsics.checkNotNullExpressionValue(var10000, "(this as java.lang.Strin…ing(startIndex, endIndex)");
               String var10 = var10000;
               var7 = false;
               if (var10 == null) {
                  throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
               } else {
                  byte[] var12 = var10.getBytes(charset);
                  Intrinsics.checkNotNullExpressionValue(var12, "(this as java.lang.String).getBytes(charset)");
                  byte[] data = var12;
                  return this.write((byte[])data, 0, data.length);
               }
            }
         }
      }
   }

   @NotNull
   public Buffer write(@NotNull byte[] source) {
      Intrinsics.checkNotNullParameter(source, "source");
      int $i$f$commonWrite = false;
      return this.write((byte[])source, 0, source.length);
   }

   @NotNull
   public Buffer write(@NotNull byte[] source, int offset, int byteCount) {
      Intrinsics.checkNotNullParameter(source, "source");
      Buffer $this$commonWrite$iv = this;
      int $i$f$commonWrite = false;
      int offset$iv = offset;
      -Util.checkOffsetAndCount((long)source.length, (long)offset, (long)byteCount);

      Segment tail$iv;
      int toCopy$iv;
      for(int limit$iv = offset + byteCount; offset$iv < limit$iv; tail$iv.limit += toCopy$iv) {
         tail$iv = $this$commonWrite$iv.writableSegment$okio(1);
         int var9 = limit$iv - offset$iv;
         int var10 = 8192 - tail$iv.limit;
         boolean var11 = false;
         toCopy$iv = Math.min(var9, var10);
         ArraysKt.copyInto(source, tail$iv.data, tail$iv.limit, offset$iv, offset$iv + toCopy$iv);
         offset$iv += toCopy$iv;
      }

      $this$commonWrite$iv.setSize$okio($this$commonWrite$iv.size() + (long)byteCount);
      return $this$commonWrite$iv;
   }

   public int write(@NotNull ByteBuffer source) throws IOException {
      Intrinsics.checkNotNullParameter(source, "source");
      int byteCount = source.remaining();

      Segment tail;
      int toCopy;
      for(int remaining = byteCount; remaining > 0; tail.limit += toCopy) {
         tail = this.writableSegment$okio(1);
         int var6 = 8192 - tail.limit;
         boolean var7 = false;
         toCopy = Math.min(remaining, var6);
         source.get(tail.data, tail.limit, toCopy);
         remaining -= toCopy;
      }

      this.size += (long)byteCount;
      return byteCount;
   }

   public long writeAll(@NotNull Source source) throws IOException {
      Intrinsics.checkNotNullParameter(source, "source");
      Buffer $this$commonWriteAll$iv = this;
      int $i$f$commonWriteAll = false;
      long totalBytesRead$iv = 0L;

      while(true) {
         long readCount$iv = source.read($this$commonWriteAll$iv, (long)8192);
         if (readCount$iv == -1L) {
            return totalBytesRead$iv;
         }

         totalBytesRead$iv += readCount$iv;
      }
   }

   @NotNull
   public Buffer write(@NotNull Source source, long byteCount) throws IOException {
      Intrinsics.checkNotNullParameter(source, "source");
      Buffer $this$commonWrite$iv = this;
      int $i$f$commonWrite = false;

      long read$iv;
      for(long byteCount$iv = byteCount; byteCount$iv > 0L; byteCount$iv -= read$iv) {
         read$iv = source.read($this$commonWrite$iv, byteCount$iv);
         if (read$iv == -1L) {
            throw (Throwable)(new EOFException());
         }
      }

      return $this$commonWrite$iv;
   }

   @NotNull
   public Buffer writeByte(int b) {
      int $i$f$commonWriteByte = false;
      Segment tail$iv = this.writableSegment$okio(1);
      byte[] var10000 = tail$iv.data;
      int var5;
      tail$iv.limit = (var5 = tail$iv.limit) + 1;
      var10000[var5] = (byte)b;
      this.setSize$okio(this.size() + 1L);
      return this;
   }

   @NotNull
   public Buffer writeShort(int s) {
      int $i$f$commonWriteShort = false;
      Segment tail$iv = this.writableSegment$okio(2);
      byte[] data$iv = tail$iv.data;
      int limit$iv = tail$iv.limit;
      data$iv[limit$iv++] = (byte)(s >>> 8 & 255);
      data$iv[limit$iv++] = (byte)(s & 255);
      tail$iv.limit = limit$iv;
      this.setSize$okio(this.size() + 2L);
      return this;
   }

   @NotNull
   public Buffer writeShortLe(int s) {
      return this.writeShort(-Util.reverseBytes((short)s));
   }

   @NotNull
   public Buffer writeInt(int i) {
      int $i$f$commonWriteInt = false;
      Segment tail$iv = this.writableSegment$okio(4);
      byte[] data$iv = tail$iv.data;
      int limit$iv = tail$iv.limit;
      data$iv[limit$iv++] = (byte)(i >>> 24 & 255);
      data$iv[limit$iv++] = (byte)(i >>> 16 & 255);
      data$iv[limit$iv++] = (byte)(i >>> 8 & 255);
      data$iv[limit$iv++] = (byte)(i & 255);
      tail$iv.limit = limit$iv;
      this.setSize$okio(this.size() + 4L);
      return this;
   }

   @NotNull
   public Buffer writeIntLe(int i) {
      return this.writeInt(-Util.reverseBytes(i));
   }

   @NotNull
   public Buffer writeLong(long v) {
      int $i$f$commonWriteLong = false;
      Segment tail$iv = this.writableSegment$okio(8);
      byte[] data$iv = tail$iv.data;
      int limit$iv = tail$iv.limit;
      data$iv[limit$iv++] = (byte)((int)(v >>> 56 & 255L));
      data$iv[limit$iv++] = (byte)((int)(v >>> 48 & 255L));
      data$iv[limit$iv++] = (byte)((int)(v >>> 40 & 255L));
      data$iv[limit$iv++] = (byte)((int)(v >>> 32 & 255L));
      data$iv[limit$iv++] = (byte)((int)(v >>> 24 & 255L));
      data$iv[limit$iv++] = (byte)((int)(v >>> 16 & 255L));
      data$iv[limit$iv++] = (byte)((int)(v >>> 8 & 255L));
      data$iv[limit$iv++] = (byte)((int)(v & 255L));
      tail$iv.limit = limit$iv;
      this.setSize$okio(this.size() + 8L);
      return this;
   }

   @NotNull
   public Buffer writeLongLe(long v) {
      return this.writeLong(-Util.reverseBytes(v));
   }

   @NotNull
   public Buffer writeDecimalLong(long v) {
      int $i$f$commonWriteDecimalLong = false;
      long v$iv = v;
      Buffer var10000;
      if (v == 0L) {
         var10000 = this.writeByte(48);
      } else {
         boolean negative$iv = false;
         if (v < 0L) {
            v$iv = -v;
            if (v$iv < 0L) {
               var10000 = this.writeUtf8("-9223372036854775808");
               return var10000;
            }

            negative$iv = true;
         }

         int width$iv = v$iv < 100000000L ? (v$iv < 10000L ? (v$iv < 100L ? (v$iv < 10L ? 1 : 2) : (v$iv < 1000L ? 3 : 4)) : (v$iv < 1000000L ? (v$iv < 100000L ? 5 : 6) : (v$iv < 10000000L ? 7 : 8))) : (v$iv < 1000000000000L ? (v$iv < 10000000000L ? (v$iv < 1000000000L ? 9 : 10) : (v$iv < 100000000000L ? 11 : 12)) : (v$iv < 1000000000000000L ? (v$iv < 10000000000000L ? 13 : (v$iv < 100000000000000L ? 14 : 15)) : (v$iv < 100000000000000000L ? (v$iv < 10000000000000000L ? 16 : 17) : (v$iv < 1000000000000000000L ? 18 : 19))));
         if (negative$iv) {
            ++width$iv;
         }

         Segment tail$iv = this.writableSegment$okio(width$iv);
         byte[] data$iv = tail$iv.data;

         int pos$iv;
         for(pos$iv = tail$iv.limit + width$iv; v$iv != 0L; v$iv /= (long)10) {
            int digit$iv = (int)(v$iv % (long)10);
            --pos$iv;
            data$iv[pos$iv] = BufferKt.getHEX_DIGIT_BYTES()[digit$iv];
         }

         if (negative$iv) {
            --pos$iv;
            data$iv[pos$iv] = (byte)45;
         }

         tail$iv.limit += width$iv;
         this.setSize$okio(this.size() + (long)width$iv);
         var10000 = this;
      }

      return var10000;
   }

   @NotNull
   public Buffer writeHexadecimalUnsignedLong(long v) {
      int $i$f$commonWriteHexadecimalUnsignedLong = false;
      long v$iv = v;
      Buffer var10000;
      if (v == 0L) {
         var10000 = this.writeByte(48);
      } else {
         long x$iv = v | v >>> 1;
         x$iv |= x$iv >>> 2;
         x$iv |= x$iv >>> 4;
         x$iv |= x$iv >>> 8;
         x$iv |= x$iv >>> 16;
         x$iv |= x$iv >>> 32;
         x$iv -= x$iv >>> 1 & 6148914691236517205L;
         x$iv = (x$iv >>> 2 & 3689348814741910323L) + (x$iv & 3689348814741910323L);
         x$iv = (x$iv >>> 4) + x$iv & 1085102592571150095L;
         x$iv += x$iv >>> 8;
         x$iv += x$iv >>> 16;
         x$iv = (x$iv & 63L) + (x$iv >>> 32 & 63L);
         int width$iv = (int)((x$iv + (long)3) / (long)4);
         Segment tail$iv = this.writableSegment$okio(width$iv);
         byte[] data$iv = tail$iv.data;
         int pos$iv = tail$iv.limit + width$iv - 1;

         for(int start$iv = tail$iv.limit; pos$iv >= start$iv; --pos$iv) {
            data$iv[pos$iv] = BufferKt.getHEX_DIGIT_BYTES()[(int)(v$iv & 15L)];
            v$iv >>>= 4;
         }

         tail$iv.limit += width$iv;
         this.setSize$okio(this.size() + (long)width$iv);
         var10000 = this;
      }

      return var10000;
   }

   @NotNull
   public final Segment writableSegment$okio(int minimumCapacity) {
      int $i$f$commonWritableSegment = false;
      boolean var4 = minimumCapacity >= 1 && minimumCapacity <= 8192;
      boolean var5 = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var9 = "unexpected capacity";
         throw (Throwable)(new IllegalArgumentException(var9.toString()));
      } else {
         Segment var10000;
         Segment tail$iv;
         if (this.head == null) {
            tail$iv = SegmentPool.take();
            this.head = tail$iv;
            tail$iv.prev = tail$iv;
            tail$iv.next = tail$iv;
            var10000 = tail$iv;
         } else {
            var10000 = this.head;
            Intrinsics.checkNotNull(var10000);
            tail$iv = var10000.prev;
            Intrinsics.checkNotNull(tail$iv);
            if (tail$iv.limit + minimumCapacity > 8192 || !tail$iv.owner) {
               tail$iv = tail$iv.push(SegmentPool.take());
            }

            var10000 = tail$iv;
         }

         return var10000;
      }
   }

   public void write(@NotNull Buffer source, long byteCount) {
      Intrinsics.checkNotNullParameter(source, "source");
      Buffer $this$commonWrite$iv = this;
      int $i$f$commonWrite = false;
      long byteCount$iv = byteCount;
      boolean var8 = source != this;
      boolean var9 = false;
      boolean var10 = false;
      if (!var8) {
         int var16 = false;
         String var15 = "source == this";
         throw (Throwable)(new IllegalArgumentException(var15.toString()));
      } else {
         -Util.checkOffsetAndCount(source.size(), 0L, byteCount);

         while(byteCount$iv > 0L) {
            Segment var10001 = source.head;
            Intrinsics.checkNotNull(var10001);
            int var17 = var10001.limit;
            Segment var10002 = source.head;
            Intrinsics.checkNotNull(var10002);
            Segment tail$iv;
            Segment var10000;
            if (byteCount$iv < (long)(var17 - var10002.pos)) {
               if ($this$commonWrite$iv.head != null) {
                  var10000 = $this$commonWrite$iv.head;
                  Intrinsics.checkNotNull(var10000);
                  var10000 = var10000.prev;
               } else {
                  var10000 = null;
               }

               tail$iv = var10000;
               if (tail$iv != null && tail$iv.owner && byteCount$iv + (long)tail$iv.limit - (long)(tail$iv.shared ? 0 : tail$iv.pos) <= (long)8192) {
                  var10000 = source.head;
                  Intrinsics.checkNotNull(var10000);
                  var10000.writeTo(tail$iv, (int)byteCount$iv);
                  source.setSize$okio(source.size() - byteCount$iv);
                  $this$commonWrite$iv.setSize$okio($this$commonWrite$iv.size() + byteCount$iv);
                  break;
               }

               var10001 = source.head;
               Intrinsics.checkNotNull(var10001);
               source.head = var10001.split((int)byteCount$iv);
            }

            tail$iv = source.head;
            Intrinsics.checkNotNull(tail$iv);
            long movedByteCount$iv = (long)(tail$iv.limit - tail$iv.pos);
            source.head = tail$iv.pop();
            if ($this$commonWrite$iv.head == null) {
               $this$commonWrite$iv.head = tail$iv;
               tail$iv.prev = tail$iv;
               tail$iv.next = tail$iv.prev;
            } else {
               var10000 = $this$commonWrite$iv.head;
               Intrinsics.checkNotNull(var10000);
               Segment tail$iv = var10000.prev;
               Intrinsics.checkNotNull(tail$iv);
               tail$iv = tail$iv.push(tail$iv);
               tail$iv.compact();
            }

            source.setSize$okio(source.size() - movedByteCount$iv);
            $this$commonWrite$iv.setSize$okio($this$commonWrite$iv.size() + movedByteCount$iv);
            byteCount$iv -= movedByteCount$iv;
         }

      }
   }

   public long read(@NotNull Buffer sink, long byteCount) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      int $i$f$commonRead = false;
      long byteCount$iv = byteCount;
      boolean var6 = byteCount >= 0L;
      boolean var7 = false;
      boolean var8 = false;
      if (!var6) {
         int var9 = false;
         String var12 = "byteCount < 0: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var12.toString()));
      } else {
         long var10000;
         if (this.size() == 0L) {
            var10000 = -1L;
         } else {
            if (byteCount > this.size()) {
               byteCount$iv = this.size();
            }

            sink.write(this, byteCount$iv);
            var10000 = byteCount$iv;
         }

         return var10000;
      }
   }

   public long indexOf(byte b) {
      return this.indexOf(b, 0L, Long.MAX_VALUE);
   }

   public long indexOf(byte b, long fromIndex) {
      return this.indexOf(b, fromIndex, Long.MAX_VALUE);
   }

   public long indexOf(byte b, long fromIndex, long toIndex) {
      boolean var10000;
      long fromIndex$iv;
      long toIndex$iv;
      label102: {
         int $i$f$commonIndexOf = false;
         fromIndex$iv = fromIndex;
         toIndex$iv = toIndex;
         if (0L <= fromIndex) {
            if (toIndex >= fromIndex) {
               var10000 = true;
               break label102;
            }
         }

         var10000 = false;
      }

      boolean var10 = var10000;
      boolean var11 = false;
      boolean var12 = false;
      boolean $i$f$seek;
      if (!var10) {
         $i$f$seek = false;
         String var52 = "size=" + this.size() + " fromIndex=" + fromIndex + " toIndex=" + toIndex;
         throw (Throwable)(new IllegalArgumentException(var52.toString()));
      } else {
         if (toIndex > this.size()) {
            toIndex$iv = this.size();
         }

         long var53;
         if (fromIndex == toIndex$iv) {
            var53 = -1L;
         } else {
            long fromIndex$iv$iv = fromIndex;
            $i$f$seek = false;
            Segment var54 = this.head;
            boolean var19;
            if (var54 != null) {
               Segment s$iv$iv = var54;
               long var26;
               long offset$iv$iv;
               if (this.size() - fromIndex < fromIndex) {
                  for(offset$iv$iv = this.size(); offset$iv$iv > fromIndex$iv$iv; offset$iv$iv -= (long)(s$iv$iv.limit - s$iv$iv.pos)) {
                     var54 = s$iv$iv.prev;
                     Intrinsics.checkNotNull(var54);
                     s$iv$iv = var54;
                  }

                  var19 = false;
                  if (s$iv$iv != null) {
                     Segment s$iv = s$iv$iv;
                     long offset$iv = offset$iv$iv;

                     while(true) {
                        if (offset$iv >= toIndex$iv) {
                           var53 = -1L;
                           break;
                        }

                        byte[] data$iv = s$iv.data;
                        long var24 = (long)s$iv.limit;
                        var26 = (long)s$iv.pos + toIndex$iv - offset$iv;
                        boolean var28 = false;
                        int limit$iv = (int)Math.min(var24, var26);

                        for(int pos$iv = (int)((long)s$iv.pos + fromIndex$iv - offset$iv); pos$iv < limit$iv; ++pos$iv) {
                           if (data$iv[pos$iv] == b) {
                              var53 = (long)(pos$iv - s$iv.pos) + offset$iv;
                              return var53;
                           }
                        }

                        offset$iv += (long)(s$iv.limit - s$iv.pos);
                        fromIndex$iv = offset$iv;
                        var54 = s$iv.next;
                        Intrinsics.checkNotNull(var54);
                        s$iv = var54;
                     }
                  } else {
                     var53 = -1L;
                  }
               } else {
                  offset$iv$iv = 0L;

                  while(true) {
                     long nextOffset$iv$iv = offset$iv$iv + (long)(s$iv$iv.limit - s$iv$iv.pos);
                     if (nextOffset$iv$iv > fromIndex$iv$iv) {
                        int var39 = false;
                        if (s$iv$iv != null) {
                           Segment s$iv = s$iv$iv;

                           for(long offset$iv = offset$iv$iv; offset$iv < toIndex$iv; s$iv = var54) {
                              byte[] data$iv = s$iv.data;
                              var26 = (long)s$iv.limit;
                              long var44 = (long)s$iv.pos + toIndex$iv - offset$iv;
                              boolean var55 = false;
                              int limit$iv = (int)Math.min(var26, var44);

                              for(int pos$iv = (int)((long)s$iv.pos + fromIndex$iv - offset$iv); pos$iv < limit$iv; ++pos$iv) {
                                 if (data$iv[pos$iv] == b) {
                                    var53 = (long)(pos$iv - s$iv.pos) + offset$iv;
                                    return var53;
                                 }
                              }

                              offset$iv += (long)(s$iv.limit - s$iv.pos);
                              fromIndex$iv = offset$iv;
                              var54 = s$iv.next;
                              Intrinsics.checkNotNull(var54);
                           }

                           var53 = -1L;
                        } else {
                           var53 = -1L;
                        }
                        break;
                     }

                     var54 = s$iv$iv.next;
                     Intrinsics.checkNotNull(var54);
                     s$iv$iv = var54;
                     offset$iv$iv = nextOffset$iv$iv;
                  }
               }
            } else {
               long var16 = -1L;
               Segment s$iv = (Segment)null;
               var19 = false;
               var53 = -1L;
            }
         }

         return var53;
      }
   }

   public long indexOf(@NotNull ByteString bytes) throws IOException {
      Intrinsics.checkNotNullParameter(bytes, "bytes");
      return this.indexOf(bytes, 0L);
   }

   public long indexOf(@NotNull ByteString bytes, long fromIndex) throws IOException {
      Intrinsics.checkNotNullParameter(bytes, "bytes");
      int $i$f$commonIndexOf = false;
      long fromIndex$iv = fromIndex;
      boolean var6 = bytes.size() > 0;
      boolean var7 = false;
      boolean var8 = false;
      boolean $i$f$seek;
      String var61;
      if (!var6) {
         $i$f$seek = false;
         var61 = "bytes is empty";
         throw (Throwable)(new IllegalArgumentException(var61.toString()));
      } else {
         var6 = fromIndex >= 0L;
         var7 = false;
         var8 = false;
         if (!var6) {
            $i$f$seek = false;
            var61 = "fromIndex < 0: " + fromIndex;
            throw (Throwable)(new IllegalArgumentException(var61.toString()));
         } else {
            long fromIndex$iv$iv = fromIndex;
            $i$f$seek = false;
            Segment var10000 = this.head;
            boolean var15;
            long var62;
            if (var10000 != null) {
               Segment s$iv$iv = var10000;
               long offset$iv$iv;
               if (this.size() - fromIndex < fromIndex) {
                  for(offset$iv$iv = this.size(); offset$iv$iv > fromIndex$iv$iv; offset$iv$iv -= (long)(s$iv$iv.limit - s$iv$iv.pos)) {
                     var10000 = s$iv$iv.prev;
                     Intrinsics.checkNotNull(var10000);
                     s$iv$iv = var10000;
                  }

                  var15 = false;
                  if (s$iv$iv != null) {
                     Segment s$iv = s$iv$iv;
                     long offset$iv = offset$iv$iv;
                     byte[] targetByteArray$iv = bytes.internalArray$okio();
                     byte b0$iv = targetByteArray$iv[0];
                     int bytesSize$iv = bytes.size();
                     long resultLimit$iv = this.size() - (long)bytesSize$iv + 1L;

                     while(true) {
                        if (offset$iv >= resultLimit$iv) {
                           var62 = -1L;
                           break;
                        }

                        byte[] data$iv = s$iv.data;
                        int pos$iv = s$iv.limit;
                        long b$iv$iv = (long)s$iv.pos + resultLimit$iv - offset$iv;
                        int $i$f$minOf = false;
                        long var29 = (long)pos$iv;
                        boolean var31 = false;
                        int segmentLimit$iv = (int)Math.min(var29, b$iv$iv);
                        pos$iv = (int)((long)s$iv.pos + fromIndex$iv - offset$iv);

                        for(int var33 = segmentLimit$iv; pos$iv < var33; ++pos$iv) {
                           if (data$iv[pos$iv] == b0$iv && BufferKt.rangeEquals(s$iv, pos$iv + 1, targetByteArray$iv, 1, bytesSize$iv)) {
                              var62 = (long)(pos$iv - s$iv.pos) + offset$iv;
                              return var62;
                           }
                        }

                        offset$iv += (long)(s$iv.limit - s$iv.pos);
                        fromIndex$iv = offset$iv;
                        var10000 = s$iv.next;
                        Intrinsics.checkNotNull(var10000);
                        s$iv = var10000;
                     }
                  } else {
                     var62 = -1L;
                  }
               } else {
                  offset$iv$iv = 0L;

                  while(true) {
                     long nextOffset$iv$iv = offset$iv$iv + (long)(s$iv$iv.limit - s$iv$iv.pos);
                     if (nextOffset$iv$iv > fromIndex$iv$iv) {
                        int var42 = false;
                        if (s$iv$iv != null) {
                           Segment s$iv = s$iv$iv;
                           long offset$iv = offset$iv$iv;
                           byte[] targetByteArray$iv = bytes.internalArray$okio();
                           byte b0$iv = targetByteArray$iv[0];
                           int bytesSize$iv = bytes.size();

                           for(long resultLimit$iv = this.size() - (long)bytesSize$iv + 1L; offset$iv < resultLimit$iv; s$iv = var10000) {
                              byte[] data$iv = s$iv.data;
                              int pos$iv = s$iv.limit;
                              long b$iv$iv = (long)s$iv.pos + resultLimit$iv - offset$iv;
                              int $i$f$minOf = false;
                              long var55 = (long)pos$iv;
                              boolean var64 = false;
                              int segmentLimit$iv = (int)Math.min(var55, b$iv$iv);
                              pos$iv = (int)((long)s$iv.pos + fromIndex$iv - offset$iv);

                              for(int var58 = segmentLimit$iv; pos$iv < var58; ++pos$iv) {
                                 if (data$iv[pos$iv] == b0$iv && BufferKt.rangeEquals(s$iv, pos$iv + 1, targetByteArray$iv, 1, bytesSize$iv)) {
                                    var62 = (long)(pos$iv - s$iv.pos) + offset$iv;
                                    return var62;
                                 }
                              }

                              offset$iv += (long)(s$iv.limit - s$iv.pos);
                              fromIndex$iv = offset$iv;
                              var10000 = s$iv.next;
                              Intrinsics.checkNotNull(var10000);
                           }

                           var62 = -1L;
                        } else {
                           var62 = -1L;
                        }
                        break;
                     }

                     var10000 = s$iv$iv.next;
                     Intrinsics.checkNotNull(var10000);
                     s$iv$iv = var10000;
                     offset$iv$iv = nextOffset$iv$iv;
                  }
               }
            } else {
               long var12 = -1L;
               Segment s$iv = (Segment)null;
               var15 = false;
               var62 = -1L;
            }

            return var62;
         }
      }
   }

   public long indexOfElement(@NotNull ByteString targetBytes) {
      Intrinsics.checkNotNullParameter(targetBytes, "targetBytes");
      return this.indexOfElement(targetBytes, 0L);
   }

   public long indexOfElement(@NotNull ByteString targetBytes, long fromIndex) {
      Intrinsics.checkNotNullParameter(targetBytes, "targetBytes");
      Buffer $this$commonIndexOfElement$iv = this;
      int $i$f$commonIndexOfElement = false;
      long fromIndex$iv = fromIndex;
      boolean var6 = fromIndex >= 0L;
      boolean var7 = false;
      boolean var8 = false;
      boolean $i$f$seek;
      if (!var6) {
         $i$f$seek = false;
         String var44 = "fromIndex < 0: " + fromIndex;
         throw (Throwable)(new IllegalArgumentException(var44.toString()));
      } else {
         long fromIndex$iv$iv = fromIndex;
         $i$f$seek = false;
         Segment var10000 = this.head;
         boolean var15;
         long var45;
         if (var10000 != null) {
            Segment s$iv$iv = var10000;
            byte[] data$iv;
            int pos$iv;
            long offset$iv$iv;
            if (this.size() - fromIndex < fromIndex) {
               for(offset$iv$iv = this.size(); offset$iv$iv > fromIndex$iv$iv; offset$iv$iv -= (long)(s$iv$iv.limit - s$iv$iv.pos)) {
                  var10000 = s$iv$iv.prev;
                  Intrinsics.checkNotNull(var10000);
                  s$iv$iv = var10000;
               }

               var15 = false;
               if (s$iv$iv != null) {
                  Segment s$iv = s$iv$iv;
                  long offset$iv = offset$iv$iv;
                  int pos$iv;
                  byte t$iv;
                  if (targetBytes.size() != 2) {
                     for(byte[] targetByteArray$iv = targetBytes.internalArray$okio(); offset$iv < $this$commonIndexOfElement$iv.size(); s$iv = var10000) {
                        byte[] data$iv = s$iv.data;
                        int pos$iv = (int)((long)s$iv.pos + fromIndex$iv - offset$iv);

                        for(pos$iv = s$iv.limit; pos$iv < pos$iv; ++pos$iv) {
                           int b$iv = data$iv[pos$iv];
                           byte[] var25 = targetByteArray$iv;
                           int var26 = targetByteArray$iv.length;

                           for(int var27 = 0; var27 < var26; ++var27) {
                              t$iv = var25[var27];
                              if (b$iv == t$iv) {
                                 var45 = (long)(pos$iv - s$iv.pos) + offset$iv;
                                 return var45;
                              }
                           }
                        }

                        offset$iv += (long)(s$iv.limit - s$iv.pos);
                        fromIndex$iv = offset$iv;
                        var10000 = s$iv.next;
                        Intrinsics.checkNotNull(var10000);
                     }
                  } else {
                     byte b0$iv = targetBytes.getByte(0);

                     for(byte b1$iv = targetBytes.getByte(1); offset$iv < $this$commonIndexOfElement$iv.size(); s$iv = var10000) {
                        data$iv = s$iv.data;
                        pos$iv = (int)((long)s$iv.pos + fromIndex$iv - offset$iv);

                        for(pos$iv = s$iv.limit; pos$iv < pos$iv; ++pos$iv) {
                           t$iv = data$iv[pos$iv];
                           if (t$iv == b0$iv || t$iv == b1$iv) {
                              var45 = (long)(pos$iv - s$iv.pos) + offset$iv;
                              return var45;
                           }
                        }

                        offset$iv += (long)(s$iv.limit - s$iv.pos);
                        fromIndex$iv = offset$iv;
                        var10000 = s$iv.next;
                        Intrinsics.checkNotNull(var10000);
                     }
                  }

                  var45 = -1L;
               } else {
                  var45 = -1L;
               }
            } else {
               offset$iv$iv = 0L;

               while(true) {
                  long nextOffset$iv$iv = offset$iv$iv + (long)(s$iv$iv.limit - s$iv$iv.pos);
                  if (nextOffset$iv$iv > fromIndex$iv$iv) {
                     int var36 = false;
                     if (s$iv$iv != null) {
                        Segment s$iv = s$iv$iv;
                        long offset$iv = offset$iv$iv;
                        int pos$iv;
                        byte t$iv;
                        if (targetBytes.size() != 2) {
                           for(data$iv = targetBytes.internalArray$okio(); offset$iv < $this$commonIndexOfElement$iv.size(); s$iv = var10000) {
                              byte[] data$iv = s$iv.data;
                              pos$iv = (int)((long)s$iv.pos + fromIndex$iv - offset$iv);

                              for(pos$iv = s$iv.limit; pos$iv < pos$iv; ++pos$iv) {
                                 int b$iv = data$iv[pos$iv];
                                 byte[] var58 = data$iv;
                                 int var40 = data$iv.length;

                                 for(int var41 = 0; var41 < var40; ++var41) {
                                    t$iv = var58[var41];
                                    if (b$iv == t$iv) {
                                       var45 = (long)(pos$iv - s$iv.pos) + offset$iv;
                                       return var45;
                                    }
                                 }
                              }

                              offset$iv += (long)(s$iv.limit - s$iv.pos);
                              fromIndex$iv = offset$iv;
                              var10000 = s$iv.next;
                              Intrinsics.checkNotNull(var10000);
                           }
                        } else {
                           byte b0$iv = targetBytes.getByte(0);

                           for(byte b1$iv = targetBytes.getByte(1); offset$iv < $this$commonIndexOfElement$iv.size(); s$iv = var10000) {
                              byte[] data$iv = s$iv.data;
                              pos$iv = (int)((long)s$iv.pos + fromIndex$iv - offset$iv);

                              for(int limit$iv = s$iv.limit; pos$iv < limit$iv; ++pos$iv) {
                                 t$iv = data$iv[pos$iv];
                                 if (t$iv == b0$iv || t$iv == b1$iv) {
                                    var45 = (long)(pos$iv - s$iv.pos) + offset$iv;
                                    return var45;
                                 }
                              }

                              offset$iv += (long)(s$iv.limit - s$iv.pos);
                              fromIndex$iv = offset$iv;
                              var10000 = s$iv.next;
                              Intrinsics.checkNotNull(var10000);
                           }
                        }

                        var45 = -1L;
                     } else {
                        var45 = -1L;
                     }
                     break;
                  }

                  var10000 = s$iv$iv.next;
                  Intrinsics.checkNotNull(var10000);
                  s$iv$iv = var10000;
                  offset$iv$iv = nextOffset$iv$iv;
               }
            }
         } else {
            long var12 = -1L;
            Segment s$iv = (Segment)null;
            var15 = false;
            var45 = -1L;
         }

         return var45;
      }
   }

   public boolean rangeEquals(long offset, @NotNull ByteString bytes) {
      Intrinsics.checkNotNullParameter(bytes, "bytes");
      return this.rangeEquals(offset, bytes, 0, bytes.size());
   }

   public boolean rangeEquals(long offset, @NotNull ByteString bytes, int bytesOffset, int byteCount) {
      Intrinsics.checkNotNullParameter(bytes, "bytes");
      Buffer $this$commonRangeEquals$iv = this;
      int $i$f$commonRangeEquals = false;
      boolean var10000;
      if (offset >= 0L && bytesOffset >= 0 && byteCount >= 0 && this.size() - offset >= (long)byteCount && bytes.size() - bytesOffset >= byteCount) {
         int i$iv = 0;
         int var9 = byteCount;

         while(true) {
            if (i$iv >= var9) {
               var10000 = true;
               break;
            }

            if ($this$commonRangeEquals$iv.getByte(offset + (long)i$iv) != bytes.getByte(bytesOffset + i$iv)) {
               var10000 = false;
               break;
            }

            ++i$iv;
         }
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public void flush() {
   }

   public boolean isOpen() {
      return true;
   }

   public void close() {
   }

   @NotNull
   public Timeout timeout() {
      return Timeout.NONE;
   }

   @NotNull
   public final ByteString md5() {
      return this.digest("MD5");
   }

   @NotNull
   public final ByteString sha1() {
      return this.digest("SHA-1");
   }

   @NotNull
   public final ByteString sha256() {
      return this.digest("SHA-256");
   }

   @NotNull
   public final ByteString sha512() {
      return this.digest("SHA-512");
   }

   private final ByteString digest(String algorithm) {
      MessageDigest messageDigest = MessageDigest.getInstance(algorithm);
      Segment var10000 = this.head;
      if (var10000 != null) {
         Segment var3 = var10000;
         boolean var4 = false;
         boolean var5 = false;
         Segment head = var3;
         int var7 = false;
         messageDigest.update(var3.data, var3.pos, var3.limit - var3.pos);
         var10000 = var3.next;
         Intrinsics.checkNotNull(var10000);

         for(Segment s = var10000; s != head; s = var10000) {
            messageDigest.update(s.data, s.pos, s.limit - s.pos);
            var10000 = s.next;
            Intrinsics.checkNotNull(var10000);
         }
      }

      byte[] var10002 = messageDigest.digest();
      Intrinsics.checkNotNullExpressionValue(var10002, "messageDigest.digest()");
      return new ByteString(var10002);
   }

   @NotNull
   public final ByteString hmacSha1(@NotNull ByteString key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.hmac("HmacSHA1", key);
   }

   @NotNull
   public final ByteString hmacSha256(@NotNull ByteString key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.hmac("HmacSHA256", key);
   }

   @NotNull
   public final ByteString hmacSha512(@NotNull ByteString key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.hmac("HmacSHA512", key);
   }

   private final ByteString hmac(String algorithm, ByteString key) {
      try {
         Mac mac = Mac.getInstance(algorithm);
         mac.init((Key)(new SecretKeySpec(key.internalArray$okio(), algorithm)));
         Segment var10000 = this.head;
         if (var10000 != null) {
            Segment var4 = var10000;
            boolean var5 = false;
            boolean var6 = false;
            Segment head = var4;
            int var8 = false;
            mac.update(var4.data, var4.pos, var4.limit - var4.pos);
            var10000 = var4.next;
            Intrinsics.checkNotNull(var10000);

            for(Segment s = var10000; s != head; s = var10000) {
               mac.update(s.data, s.pos, s.limit - s.pos);
               var10000 = s.next;
               Intrinsics.checkNotNull(var10000);
            }
         }

         byte[] var10002 = mac.doFinal();
         Intrinsics.checkNotNullExpressionValue(var10002, "mac.doFinal()");
         return new ByteString(var10002);
      } catch (InvalidKeyException var10) {
         throw (Throwable)(new IllegalArgumentException((Throwable)var10));
      }
   }

   public boolean equals(@Nullable Object other) {
      Buffer $this$commonEquals$iv = this;
      int $i$f$commonEquals = false;
      boolean var10000;
      if (this == other) {
         var10000 = true;
      } else if (!(other instanceof Buffer)) {
         var10000 = false;
      } else if (this.size() != ((Buffer)other).size()) {
         var10000 = false;
      } else if (this.size() == 0L) {
         var10000 = true;
      } else {
         Segment var19 = this.head;
         Intrinsics.checkNotNull(var19);
         Segment sa$iv = var19;
         var19 = ((Buffer)other).head;
         Intrinsics.checkNotNull(var19);
         Segment sb$iv = var19;
         int posA$iv = sa$iv.pos;
         int posB$iv = sb$iv.pos;
         long pos$iv = 0L;
         long count$iv = 0L;

         while(true) {
            if (pos$iv >= $this$commonEquals$iv.size()) {
               var10000 = true;
               break;
            }

            int var12 = sa$iv.limit - posA$iv;
            int var13 = sb$iv.limit - posB$iv;
            boolean var14 = false;
            count$iv = (long)Math.min(var12, var13);
            long i$iv = 0L;

            for(long var17 = count$iv; i$iv < var17; ++i$iv) {
               if (sa$iv.data[posA$iv++] != sb$iv.data[posB$iv++]) {
                  var10000 = false;
                  return var10000;
               }
            }

            if (posA$iv == sa$iv.limit) {
               var19 = sa$iv.next;
               Intrinsics.checkNotNull(var19);
               sa$iv = var19;
               posA$iv = sa$iv.pos;
            }

            if (posB$iv == sb$iv.limit) {
               var19 = sb$iv.next;
               Intrinsics.checkNotNull(var19);
               sb$iv = var19;
               posB$iv = sb$iv.pos;
            }

            pos$iv += count$iv;
         }
      }

      return var10000;
   }

   public int hashCode() {
      Buffer $this$commonHashCode$iv = this;
      int $i$f$commonHashCode = false;
      Segment var10000 = this.head;
      int var7;
      if (var10000 != null) {
         Segment s$iv = var10000;
         int result$iv = 1;

         do {
            int pos$iv = s$iv.pos;

            for(int limit$iv = s$iv.limit; pos$iv < limit$iv; ++pos$iv) {
               result$iv = 31 * result$iv + s$iv.data[pos$iv];
            }

            var10000 = s$iv.next;
            Intrinsics.checkNotNull(var10000);
            s$iv = var10000;
         } while(s$iv != $this$commonHashCode$iv.head);

         var7 = result$iv;
      } else {
         var7 = 0;
      }

      return var7;
   }

   @NotNull
   public String toString() {
      return this.snapshot().toString();
   }

   @NotNull
   public final Buffer copy() {
      int $i$f$commonCopy = false;
      Buffer result$iv = new Buffer();
      Buffer var10000;
      if (this.size() == 0L) {
         var10000 = result$iv;
      } else {
         Segment var7 = this.head;
         Intrinsics.checkNotNull(var7);
         Segment head$iv = var7;
         Segment headCopy$iv = head$iv.sharedCopy();
         result$iv.head = headCopy$iv;
         headCopy$iv.prev = result$iv.head;
         headCopy$iv.next = headCopy$iv.prev;

         for(Segment s$iv = head$iv.next; s$iv != head$iv; s$iv = s$iv.next) {
            var7 = headCopy$iv.prev;
            Intrinsics.checkNotNull(var7);
            Intrinsics.checkNotNull(s$iv);
            var7.push(s$iv.sharedCopy());
         }

         result$iv.setSize$okio(this.size());
         var10000 = result$iv;
      }

      return var10000;
   }

   @NotNull
   public Buffer clone() {
      return this.copy();
   }

   @NotNull
   public final ByteString snapshot() {
      int $i$f$commonSnapshot = false;
      boolean var3 = this.size() <= (long)Integer.MAX_VALUE;
      boolean var4 = false;
      boolean var5 = false;
      if (!var3) {
         int var6 = false;
         String var7 = "size > Int.MAX_VALUE: " + this.size();
         throw (Throwable)(new IllegalStateException(var7.toString()));
      } else {
         return this.snapshot((int)this.size());
      }
   }

   @NotNull
   public final ByteString snapshot(int byteCount) {
      int $i$f$commonSnapshot = false;
      ByteString var10000;
      if (byteCount == 0) {
         var10000 = ByteString.EMPTY;
      } else {
         -Util.checkOffsetAndCount(this.size(), 0L, (long)byteCount);
         int offset$iv = 0;
         int segmentCount$iv = 0;

         Segment s$iv;
         for(s$iv = this.head; offset$iv < byteCount; s$iv = s$iv.next) {
            Intrinsics.checkNotNull(s$iv);
            if (s$iv.limit == s$iv.pos) {
               throw (Throwable)(new AssertionError("s.limit == s.pos"));
            }

            offset$iv += s$iv.limit - s$iv.pos;
            ++segmentCount$iv;
         }

         byte[][] segments$iv = new byte[segmentCount$iv][];
         int[] directory$iv = new int[segmentCount$iv * 2];
         offset$iv = 0;
         segmentCount$iv = 0;

         for(s$iv = this.head; offset$iv < byteCount; s$iv = s$iv.next) {
            Intrinsics.checkNotNull(s$iv);
            segments$iv[segmentCount$iv] = s$iv.data;
            offset$iv += s$iv.limit - s$iv.pos;
            boolean var9 = false;
            directory$iv[segmentCount$iv] = Math.min(offset$iv, byteCount);
            directory$iv[segmentCount$iv + ((Object[])segments$iv).length] = s$iv.pos;
            s$iv.shared = true;
            ++segmentCount$iv;
         }

         var10000 = (ByteString)(new SegmentedByteString((byte[][])segments$iv, directory$iv));
      }

      return var10000;
   }

   @JvmOverloads
   @NotNull
   public final Buffer.UnsafeCursor readUnsafe(@NotNull Buffer.UnsafeCursor unsafeCursor) {
      Intrinsics.checkNotNullParameter(unsafeCursor, "unsafeCursor");
      boolean var2 = unsafeCursor.buffer == null;
      boolean var3 = false;
      boolean var4 = false;
      if (!var2) {
         int var5 = false;
         String var6 = "already attached to a buffer";
         throw (Throwable)(new IllegalStateException(var6.toString()));
      } else {
         unsafeCursor.buffer = (Buffer)this;
         unsafeCursor.readWrite = false;
         return unsafeCursor;
      }
   }

   // $FF: synthetic method
   public static Buffer.UnsafeCursor readUnsafe$default(Buffer var0, Buffer.UnsafeCursor var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = new Buffer.UnsafeCursor();
      }

      return var0.readUnsafe(var1);
   }

   @JvmOverloads
   @NotNull
   public final Buffer.UnsafeCursor readUnsafe() {
      return readUnsafe$default(this, (Buffer.UnsafeCursor)null, 1, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final Buffer.UnsafeCursor readAndWriteUnsafe(@NotNull Buffer.UnsafeCursor unsafeCursor) {
      Intrinsics.checkNotNullParameter(unsafeCursor, "unsafeCursor");
      boolean var2 = unsafeCursor.buffer == null;
      boolean var3 = false;
      boolean var4 = false;
      if (!var2) {
         int var5 = false;
         String var6 = "already attached to a buffer";
         throw (Throwable)(new IllegalStateException(var6.toString()));
      } else {
         unsafeCursor.buffer = (Buffer)this;
         unsafeCursor.readWrite = true;
         return unsafeCursor;
      }
   }

   // $FF: synthetic method
   public static Buffer.UnsafeCursor readAndWriteUnsafe$default(Buffer var0, Buffer.UnsafeCursor var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = new Buffer.UnsafeCursor();
      }

      return var0.readAndWriteUnsafe(var1);
   }

   @JvmOverloads
   @NotNull
   public final Buffer.UnsafeCursor readAndWriteUnsafe() {
      return readAndWriteUnsafe$default(this, (Buffer.UnsafeCursor)null, 1, (Object)null);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to operator function",
      replaceWith = @ReplaceWith(
   imports = {},
   expression = "this[index]"
),
      level = DeprecationLevel.ERROR
   )
   @JvmName(
      name = "-deprecated_getByte"
   )
   public final byte _deprecated_getByte/* $FF was: -deprecated_getByte*/(long index) {
      return this.getByte(index);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to val",
      replaceWith = @ReplaceWith(
   imports = {},
   expression = "size"
),
      level = DeprecationLevel.ERROR
   )
   @JvmName(
      name = "-deprecated_size"
   )
   public final long _deprecated_size/* $FF was: -deprecated_size*/() {
      return this.size;
   }

   @Metadata(
      mv = {1, 4, 0},
      bv = {1, 0, 3},
      k = 1,
      d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0010\u001a\u00020\u0011H\u0016J\u000e\u0010\u0012\u001a\u00020\n2\u0006\u0010\u0013\u001a\u00020\bJ\u0006\u0010\u0014\u001a\u00020\bJ\u000e\u0010\u0015\u001a\u00020\n2\u0006\u0010\u0016\u001a\u00020\nJ\u000e\u0010\u0017\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nR\u0014\u0010\u0003\u001a\u0004\u0018\u00010\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\u0004\u0018\u00010\u00068\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0007\u001a\u00020\b8\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\t\u001a\u00020\n8\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u000b\u001a\u00020\f8\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u000f\u001a\u00020\b8\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000¨\u0006\u0018"},
      d2 = {"Li/Buffer$UnsafeCursor;", "Ljava/io/Closeable;", "()V", "buffer", "Li/Buffer;", "data", "", "end", "", "offset", "", "readWrite", "", "segment", "Li/Segment;", "start", "close", "", "expandBuffer", "minByteCount", "next", "resizeBuffer", "newSize", "seek", "i"}
   )
   public static final class UnsafeCursor implements Closeable {
      @JvmField
      @Nullable
      public Buffer buffer;
      @JvmField
      public boolean readWrite;
      private Segment segment;
      @JvmField
      public long offset = -1L;
      @JvmField
      @Nullable
      public byte[] data;
      @JvmField
      public int start = -1;
      @JvmField
      public int end = -1;

      public final int next() {
         long var10000 = this.offset;
         Buffer var10001 = this.buffer;
         Intrinsics.checkNotNull(var10001);
         boolean var1 = var10000 != var10001.size();
         boolean var2 = false;
         boolean var3 = false;
         if (!var1) {
            int var4 = false;
            String var5 = "no more bytes";
            throw (Throwable)(new IllegalStateException(var5.toString()));
         } else {
            return this.offset == -1L ? this.seek(0L) : this.seek(this.offset + (long)(this.end - this.start));
         }
      }

      public final int seek(long offset) {
         Buffer var4 = this.buffer;
         boolean var5 = false;
         boolean var6 = false;
         boolean var7;
         if (var4 == null) {
            var7 = false;
            String var19 = "not attached to a buffer";
            throw (Throwable)(new IllegalStateException(var19.toString()));
         } else {
            Buffer buffer = var4;
            if (offset >= (long)-1 && offset <= var4.size()) {
               if (offset != -1L && offset != var4.size()) {
                  long min = 0L;
                  long max = buffer.size();
                  Segment head = buffer.head;
                  Segment tail = buffer.head;
                  if (this.segment != null) {
                     long var10000 = this.offset;
                     int var10001 = this.start;
                     Segment var22 = this.segment;
                     Intrinsics.checkNotNull(var22);
                     long segmentOffset = var10000 - (long)(var10001 - var22.pos);
                     if (segmentOffset > offset) {
                        max = segmentOffset;
                        tail = this.segment;
                     } else {
                        min = segmentOffset;
                        head = this.segment;
                     }
                  }

                  Segment next = null;
                  long nextOffset = 0L;
                  if (max - offset > offset - min) {
                     next = head;
                     nextOffset = min;

                     while(true) {
                        Intrinsics.checkNotNull(next);
                        if (offset < nextOffset + (long)(next.limit - next.pos)) {
                           break;
                        }

                        nextOffset += (long)(next.limit - next.pos);
                        next = next.next;
                     }
                  } else {
                     next = tail;

                     for(nextOffset = max; nextOffset > offset; nextOffset -= (long)(next.limit - next.pos)) {
                        Intrinsics.checkNotNull(next);
                        next = next.prev;
                        Intrinsics.checkNotNull(next);
                     }
                  }

                  if (this.readWrite) {
                     Intrinsics.checkNotNull(next);
                     if (next.shared) {
                        Segment unsharedNext = next.unsharedCopy();
                        if (buffer.head == next) {
                           buffer.head = unsharedNext;
                        }

                        next = next.push(unsharedNext);
                        Segment var21 = next.prev;
                        Intrinsics.checkNotNull(var21);
                        var21.pop();
                     }
                  }

                  this.segment = next;
                  this.offset = offset;
                  Intrinsics.checkNotNull(next);
                  this.data = next.data;
                  this.start = next.pos + (int)(offset - nextOffset);
                  this.end = next.limit;
                  return this.end - this.start;
               } else {
                  this.segment = (Segment)null;
                  this.offset = offset;
                  this.data = (byte[])null;
                  this.start = -1;
                  this.end = -1;
                  return -1;
               }
            } else {
               StringCompanionObject var14 = StringCompanionObject.INSTANCE;
               String var16 = "offset=%s > size=%s";
               Object[] var17 = new Object[]{offset, buffer.size()};
               var7 = false;
               String var10002 = String.format(var16, Arrays.copyOf(var17, var17.length));
               Intrinsics.checkNotNullExpressionValue(var10002, "java.lang.String.format(format, *args)");
               throw (Throwable)(new ArrayIndexOutOfBoundsException(var10002));
            }
         }
      }

      public final long resizeBuffer(long newSize) {
         Buffer var4 = this.buffer;
         boolean var5 = false;
         boolean needsToSeek = false;
         boolean var7;
         String var20;
         if (var4 == null) {
            var7 = false;
            var20 = "not attached to a buffer";
            throw (Throwable)(new IllegalStateException(var20.toString()));
         } else {
            Buffer buffer = var4;
            boolean var16 = this.readWrite;
            var5 = false;
            needsToSeek = false;
            if (!var16) {
               var7 = false;
               var20 = "resizeBuffer() only permitted for read/write buffers";
               throw (Throwable)(new IllegalStateException(var20.toString()));
            } else {
               long oldSize = buffer.size();
               if (newSize <= oldSize) {
                  needsToSeek = newSize >= 0L;
                  var7 = false;
                  boolean var8 = false;
                  if (!needsToSeek) {
                     int var23 = false;
                     String var22 = "newSize < 0: " + newSize;
                     throw (Throwable)(new IllegalArgumentException(var22.toString()));
                  }

                  int tailSize;
                  for(long bytesToSubtract = oldSize - newSize; bytesToSubtract > 0L; bytesToSubtract -= (long)tailSize) {
                     Segment var10000 = buffer.head;
                     Intrinsics.checkNotNull(var10000);
                     Segment tail = var10000.prev;
                     Intrinsics.checkNotNull(tail);
                     tailSize = tail.limit - tail.pos;
                     if ((long)tailSize > bytesToSubtract) {
                        tail.limit -= (int)bytesToSubtract;
                        break;
                     }

                     buffer.head = tail.pop();
                     SegmentPool.recycle(tail);
                  }

                  this.segment = (Segment)null;
                  this.offset = newSize;
                  this.data = (byte[])null;
                  this.start = -1;
                  this.end = -1;
               } else if (newSize > oldSize) {
                  needsToSeek = true;
                  long bytesToAdd = newSize - oldSize;

                  while(bytesToAdd > 0L) {
                     Segment tail = buffer.writableSegment$okio(1);
                     int b$iv = 8192 - tail.limit;
                     int $i$f$minOf = false;
                     long var13 = (long)b$iv;
                     boolean var15 = false;
                     int segmentBytesToAdd = (int)Math.min(bytesToAdd, var13);
                     tail.limit += segmentBytesToAdd;
                     bytesToAdd -= (long)segmentBytesToAdd;
                     if (needsToSeek) {
                        this.segment = tail;
                        this.offset = oldSize;
                        this.data = tail.data;
                        this.start = tail.limit - segmentBytesToAdd;
                        this.end = tail.limit;
                        needsToSeek = false;
                     }
                  }
               }

               buffer.setSize$okio(newSize);
               return oldSize;
            }
         }
      }

      public final long expandBuffer(int minByteCount) {
         boolean var2 = minByteCount > 0;
         boolean var3 = false;
         boolean var4 = false;
         boolean var5;
         String var10;
         if (!var2) {
            var5 = false;
            var10 = "minByteCount <= 0: " + minByteCount;
            throw (Throwable)(new IllegalArgumentException(var10.toString()));
         } else {
            var2 = minByteCount <= 8192;
            var3 = false;
            var4 = false;
            if (!var2) {
               var5 = false;
               var10 = "minByteCount > Segment.SIZE: " + minByteCount;
               throw (Throwable)(new IllegalArgumentException(var10.toString()));
            } else {
               Buffer var8 = this.buffer;
               var4 = false;
               var5 = false;
               String var12;
               boolean var13;
               if (var8 == null) {
                  var13 = false;
                  var12 = "not attached to a buffer";
                  throw (Throwable)(new IllegalStateException(var12.toString()));
               } else {
                  Buffer buffer = var8;
                  var3 = this.readWrite;
                  var4 = false;
                  var5 = false;
                  if (!var3) {
                     var13 = false;
                     var12 = "expandBuffer() only permitted for read/write buffers";
                     throw (Throwable)(new IllegalStateException(var12.toString()));
                  } else {
                     long oldSize = buffer.size();
                     Segment tail = buffer.writableSegment$okio(minByteCount);
                     int result = 8192 - tail.limit;
                     tail.limit = 8192;
                     buffer.setSize$okio(oldSize + (long)result);
                     this.segment = tail;
                     this.offset = oldSize;
                     this.data = tail.data;
                     this.start = 8192 - result;
                     this.end = 8192;
                     return (long)result;
                  }
               }
            }
         }
      }

      public void close() {
         boolean var1 = this.buffer != null;
         boolean var2 = false;
         boolean var3 = false;
         if (!var1) {
            int var4 = false;
            String var5 = "not attached to a buffer";
            throw (Throwable)(new IllegalStateException(var5.toString()));
         } else {
            this.buffer = (Buffer)null;
            this.segment = (Segment)null;
            this.offset = -1L;
            this.data = (byte[])null;
            this.start = -1;
            this.end = -1;
         }
      }
   }
}
