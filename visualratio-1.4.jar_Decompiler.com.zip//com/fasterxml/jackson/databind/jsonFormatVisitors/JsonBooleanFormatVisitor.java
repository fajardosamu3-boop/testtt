package com.fasterxml.jackson.databind.jsonFormatVisitors;

public interface JsonBooleanFormatVisitor extends JsonValueFormatVisitor {
   public static class Base extends JsonValueFormatVisitor.Base implements JsonBooleanFormatVisitor {
   }
}
