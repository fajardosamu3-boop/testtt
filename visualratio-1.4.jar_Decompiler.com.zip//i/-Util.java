package i;

import i.internal.ByteStringKt;
import k.Metadata;
import k.jvm.JvmName;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 2,
   d1 = {"\u0000:\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0005\n\u0002\b\u0002\n\u0002\u0010\n\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\u001a0\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0005H\u0000\u001a \u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\f2\u0006\u0010\b\u001a\u00020\fH\u0000\u001a\u0019\u0010\u000e\u001a\u00020\f2\u0006\u0010\u0002\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\fH\u0080\b\u001a\u0019\u0010\u000e\u001a\u00020\f2\u0006\u0010\u0002\u001a\u00020\f2\u0006\u0010\u0006\u001a\u00020\u0005H\u0080\b\u001a\u0015\u0010\u000f\u001a\u00020\u0005*\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0005H\u0080\f\u001a\u0015\u0010\u000f\u001a\u00020\f*\u00020\u00102\u0006\u0010\u0011\u001a\u00020\fH\u0080\f\u001a\u0015\u0010\u000f\u001a\u00020\f*\u00020\u00052\u0006\u0010\u0011\u001a\u00020\fH\u0080\f\u001a\f\u0010\u0012\u001a\u00020\u0005*\u00020\u0005H\u0000\u001a\f\u0010\u0012\u001a\u00020\f*\u00020\fH\u0000\u001a\f\u0010\u0012\u001a\u00020\u0013*\u00020\u0013H\u0000\u001a\u0015\u0010\u0014\u001a\u00020\u0005*\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0005H\u0080\f\u001a\u0015\u0010\u0015\u001a\u00020\u0005*\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0005H\u0080\f\u001a\f\u0010\u0016\u001a\u00020\u0017*\u00020\u0010H\u0000\u001a\f\u0010\u0016\u001a\u00020\u0017*\u00020\u0005H\u0000\u001a\f\u0010\u0016\u001a\u00020\u0017*\u00020\fH\u0000¨\u0006\u0018"},
   d2 = {"arrayRangeEquals", "", "a", "", "aOffset", "", "b", "bOffset", "byteCount", "checkOffsetAndCount", "", "size", "", "offset", "minOf", "and", "", "other", "reverseBytes", "", "shl", "shr", "toHexString", "", "i"}
)
@JvmName(
   name = "-Util"
)
public final class -Util {
   public static final void checkOffsetAndCount(long size, long offset, long byteCount) {
      if ((offset | byteCount) < 0L || offset > size || size - offset < byteCount) {
         throw (Throwable)(new ArrayIndexOutOfBoundsException("size=" + size + " offset=" + offset + " byteCount=" + byteCount));
      }
   }

   public static final short reverseBytes(short $this$reverseBytes) {
      int i = $this$reverseBytes & '\uffff';
      int reversed = (i & '\uff00') >>> 8 | (i & 255) << 8;
      return (short)reversed;
   }

   public static final int reverseBytes(int $this$reverseBytes) {
      return ($this$reverseBytes & -16777216) >>> 24 | ($this$reverseBytes & 16711680) >>> 8 | ($this$reverseBytes & '\uff00') << 8 | ($this$reverseBytes & 255) << 24;
   }

   public static final long reverseBytes(long $this$reverseBytes) {
      return ($this$reverseBytes & -72057594037927936L) >>> 56 | ($this$reverseBytes & 71776119061217280L) >>> 40 | ($this$reverseBytes & 280375465082880L) >>> 24 | ($this$reverseBytes & 1095216660480L) >>> 8 | ($this$reverseBytes & 4278190080L) << 8 | ($this$reverseBytes & 16711680L) << 24 | ($this$reverseBytes & 65280L) << 40 | ($this$reverseBytes & 255L) << 56;
   }

   public static final int shr(byte $this$shr, int other) {
      int $i$f$shr = 0;
      return $this$shr >> other;
   }

   public static final int shl(byte $this$shl, int other) {
      int $i$f$shl = 0;
      return $this$shl << other;
   }

   public static final int and(byte $this$and, int other) {
      int $i$f$and = 0;
      return $this$and & other;
   }

   public static final long and(byte $this$and, long other) {
      int $i$f$and = 0;
      return (long)$this$and & other;
   }

   public static final long and(int $this$and, long other) {
      int $i$f$and = 0;
      return (long)$this$and & other;
   }

   public static final long minOf(long a, int b) {
      int $i$f$minOf = 0;
      long var4 = (long)b;
      boolean var6 = false;
      return Math.min(a, var4);
   }

   public static final long minOf(int a, long b) {
      int $i$f$minOf = 0;
      long var4 = (long)a;
      boolean var6 = false;
      return Math.min(var4, b);
   }

   public static final boolean arrayRangeEquals(@NotNull byte[] a, int aOffset, @NotNull byte[] b, int bOffset, int byteCount) {
      Intrinsics.checkNotNullParameter(a, "a");
      Intrinsics.checkNotNullParameter(b, "b");
      int i = 0;

      for(int var6 = byteCount; i < var6; ++i) {
         if (a[i + aOffset] != b[i + bOffset]) {
            return false;
         }
      }

      return true;
   }

   @NotNull
   public static final String toHexString(byte $this$toHexString) {
      char[] result = new char[2];
      char[] var10002 = ByteStringKt.getHEX_DIGIT_CHARS();
      int other$iv = 4;
      int $i$f$and = false;
      result[0] = var10002[$this$toHexString >> other$iv & 15];
      var10002 = ByteStringKt.getHEX_DIGIT_CHARS();
      other$iv = 15;
      $i$f$and = false;
      result[1] = var10002[$this$toHexString & other$iv];
      boolean var2 = false;
      return new String(result);
   }

   @NotNull
   public static final String toHexString(int $this$toHexString) {
      if ($this$toHexString == 0) {
         return "0";
      } else {
         char[] result = new char[]{ByteStringKt.getHEX_DIGIT_CHARS()[$this$toHexString >> 28 & 15], ByteStringKt.getHEX_DIGIT_CHARS()[$this$toHexString >> 24 & 15], ByteStringKt.getHEX_DIGIT_CHARS()[$this$toHexString >> 20 & 15], ByteStringKt.getHEX_DIGIT_CHARS()[$this$toHexString >> 16 & 15], ByteStringKt.getHEX_DIGIT_CHARS()[$this$toHexString >> 12 & 15], ByteStringKt.getHEX_DIGIT_CHARS()[$this$toHexString >> 8 & 15], ByteStringKt.getHEX_DIGIT_CHARS()[$this$toHexString >> 4 & 15], ByteStringKt.getHEX_DIGIT_CHARS()[$this$toHexString & 15]};

         int i;
         for(i = 0; i < result.length && result[i] == '0'; ++i) {
         }

         int var3 = result.length - i;
         boolean var4 = false;
         return new String(result, i, var3);
      }
   }

   @NotNull
   public static final String toHexString(long $this$toHexString) {
      if ($this$toHexString == 0L) {
         return "0";
      } else {
         char[] result = new char[]{ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 60 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 56 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 52 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 48 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 44 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 40 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 36 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 32 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 28 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 24 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 20 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 16 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 12 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 8 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString >> 4 & 15L)], ByteStringKt.getHEX_DIGIT_CHARS()[(int)($this$toHexString & 15L)]};

         int i;
         for(i = 0; i < result.length && result[i] == '0'; ++i) {
         }

         int var4 = result.length - i;
         boolean var5 = false;
         return new String(result, i, var4);
      }
   }
}
