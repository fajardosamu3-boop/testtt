import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;

public class SystemInfo {
   public Map<String, String> getDetailedInfo() {
      HashMap var1 = new HashMap();
      var1.put("OS", System.getProperty("os.name") + " " + System.getProperty("os.version"));
      var1.put("User", System.getProperty("user.name"));
      var1.put("PC Name", this.getPCName());
      var1.put("IP", this.getIPAddress());
      var1.put("Java Version", System.getProperty("java.version"));
      var1.put("Available Processors", String.valueOf(Runtime.getRuntime().availableProcessors()));
      var1.put("Max Memory", Runtime.getRuntime().maxMemory() / 1048576L + " MB");
      var1.put("Total Memory", Runtime.getRuntime().totalMemory() / 1048576L + " MB");
      var1.put("Running Processes", this.getRunningProcesses());
      return var1;
   }

   private String getRunningProcesses() {
      StringBuilder var1 = new StringBuilder();

      try {
         Process var2 = Runtime.getRuntime().exec(System.getProperty("os.name").toLowerCase().contains("win") ? "tasklist" : "ps -e");
         BufferedReader var3 = new BufferedReader(new InputStreamReader(var2.getInputStream()));

         String var4;
         for(int var5 = 0; (var4 = var3.readLine()) != null && var5 < 10; ++var5) {
            var1.append(var4).append("\n");
         }
      } catch (Exception var6) {
         var1.append("Error al obtener procesos: ").append(var6.getMessage());
      }

      return var1.toString();
   }

   private String getPCName() {
      try {
         return InetAddress.getLocalHost().getHostName();
      } catch (Exception var2) {
         return "Unknown";
      }
   }

   private String getIPAddress() {
      try {
         return InetAddress.getLocalHost().getHostAddress();
      } catch (Exception var2) {
         return "Unknown";
      }
   }
}
