package com.fasterxml.jackson.databind.jsonFormatVisitors;

public interface JsonNullFormatVisitor {
   public static class Base implements JsonNullFormatVisitor {
   }
}
