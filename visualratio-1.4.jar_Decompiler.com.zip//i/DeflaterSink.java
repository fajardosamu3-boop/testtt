package i;

import java.io.IOException;
import java.util.zip.Deflater;
import k.Metadata;
import k.jvm.internal.Intrinsics;
import org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\u0018\u00002\u00020\u0001B\u0017\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005B\u0017\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0006\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0007J\b\u0010\n\u001a\u00020\u000bH\u0016J\u0010\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\tH\u0003J\r\u0010\u000e\u001a\u00020\u000bH\u0000¢\u0006\u0002\b\u000fJ\b\u0010\u0010\u001a\u00020\u000bH\u0016J\b\u0010\u0011\u001a\u00020\u0012H\u0016J\b\u0010\u0013\u001a\u00020\u0014H\u0016J\u0018\u0010\u0015\u001a\u00020\u000b2\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u0019H\u0016R\u000e\u0010\b\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001a"},
   d2 = {"Li/DeflaterSink;", "Li/Sink;", "sink", "deflater", "Ljava/util/zip/Deflater;", "(Lokio/Sink;Ljava/util/zip/Deflater;)V", "Li/BufferedSink;", "(Lokio/BufferedSink;Ljava/util/zip/Deflater;)V", "closed", "", "close", "", "deflate", "syncFlush", "finishDeflate", "finishDeflate$okio", "flush", "timeout", "Li/Timeout;", "toString", "", "write", "source", "Li/Buffer;", "byteCount", "", "i"}
)
public final class DeflaterSink implements Sink {
   private boolean closed;
   private final BufferedSink sink;
   private final Deflater deflater;

   public void write(@NotNull Buffer source, long byteCount) throws IOException {
      Intrinsics.checkNotNullParameter(source, "source");
      -Util.checkOffsetAndCount(source.size(), 0L, byteCount);

      int toDeflate;
      for(long remaining = byteCount; remaining > 0L; remaining -= (long)toDeflate) {
         Segment var10000 = source.head;
         Intrinsics.checkNotNull(var10000);
         Segment head = var10000;
         int b$iv = head.limit - head.pos;
         int $i$f$minOf = false;
         long var10 = (long)b$iv;
         boolean var12 = false;
         toDeflate = (int)Math.min(remaining, var10);
         this.deflater.setInput(head.data, head.pos, toDeflate);
         this.deflate(false);
         source.setSize$okio(source.size() - (long)toDeflate);
         head.pos += toDeflate;
         if (head.pos == head.limit) {
            source.head = head.pop();
            SegmentPool.recycle(head);
         }
      }

   }

   @IgnoreJRERequirement
   private final void deflate(boolean syncFlush) {
      Buffer buffer = this.sink.getBuffer();

      while(true) {
         Segment s = buffer.writableSegment$okio(1);
         int deflated = syncFlush ? this.deflater.deflate(s.data, s.limit, 8192 - s.limit, 2) : this.deflater.deflate(s.data, s.limit, 8192 - s.limit);
         if (deflated > 0) {
            s.limit += deflated;
            buffer.setSize$okio(buffer.size() + (long)deflated);
            this.sink.emitCompleteSegments();
         } else if (this.deflater.needsInput()) {
            if (s.pos == s.limit) {
               buffer.head = s.pop();
               SegmentPool.recycle(s);
            }

            return;
         }
      }
   }

   public void flush() throws IOException {
      this.deflate(true);
      this.sink.flush();
   }

   public final void finishDeflate$okio() {
      this.deflater.finish();
      this.deflate(false);
   }

   public void close() throws IOException {
      if (!this.closed) {
         Throwable thrown = (Throwable)null;

         try {
            this.finishDeflate$okio();
         } catch (Throwable var3) {
            thrown = var3;
         }

         try {
            this.deflater.end();
         } catch (Throwable var5) {
            if (thrown == null) {
               thrown = var5;
            }
         }

         try {
            this.sink.close();
         } catch (Throwable var4) {
            if (thrown == null) {
               thrown = var4;
            }
         }

         this.closed = true;
         if (thrown != null) {
            throw thrown;
         }
      }
   }

   @NotNull
   public Timeout timeout() {
      return this.sink.timeout();
   }

   @NotNull
   public String toString() {
      return "DeflaterSink(" + this.sink + ')';
   }

   public DeflaterSink(@NotNull BufferedSink sink, @NotNull Deflater deflater) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      Intrinsics.checkNotNullParameter(deflater, "deflater");
      super();
      this.sink = sink;
      this.deflater = deflater;
   }

   public DeflaterSink(@NotNull Sink sink, @NotNull Deflater deflater) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      Intrinsics.checkNotNullParameter(deflater, "deflater");
      this(Okio.buffer(sink), deflater);
   }
}
