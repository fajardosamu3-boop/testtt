import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;
import javax.sound.sampled.Mixer.Info;

public class AudioRecorder {
   private TargetDataLine targetLine;
   private ByteArrayOutputStream outputStream;
   private boolean isRecording = false;
   private byte[] audioData;
   private String errorMessage = null;

   public static boolean isAudioAvailable() {
      try {
         Info[] var0 = AudioSystem.getMixerInfo();
         ArrayList var1 = new ArrayList();
         Info[] var2 = var0;
         int var3 = var0.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            Info var5 = var2[var4];
            Mixer var6 = AudioSystem.getMixer(var5);
            javax.sound.sampled.Line.Info[] var7 = var6.getTargetLineInfo();
            javax.sound.sampled.Line.Info[] var8 = var7;
            int var9 = var7.length;

            for(int var10 = 0; var10 < var9; ++var10) {
               javax.sound.sampled.Line.Info var11 = var8[var10];
               if (var11.getLineClass().equals(TargetDataLine.class)) {
                  var1.add(var5);
                  break;
               }
            }
         }

         return !var1.isEmpty();
      } catch (Exception var12) {
         return false;
      }
   }

   public void startRecording(int var1) {
      this.errorMessage = null;

      try {
         if (!isAudioAvailable()) {
            this.errorMessage = "No se encontraron dispositivos de entrada de audio (micrófono).";
            return;
         }

         if (this.isRecording) {
            this.stopRecording();
         }

         AudioFormat var2 = new AudioFormat(16000.0F, 16, 1, true, false);
         javax.sound.sampled.DataLine.Info var3 = new javax.sound.sampled.DataLine.Info(TargetDataLine.class, var2);
         this.targetLine = (TargetDataLine)AudioSystem.getLine(var3);
         this.targetLine.open(var2);
         this.targetLine.start();
         this.outputStream = new ByteArrayOutputStream();
         this.isRecording = true;
         Thread var4 = new Thread(() -> {
            try {
               byte[] var2 = new byte[1024];
               long var3 = System.currentTimeMillis();
               long var5 = (long)(var1 * 1000);

               while(this.isRecording && System.currentTimeMillis() - var3 < var5) {
                  int var7 = this.targetLine.read(var2, 0, var2.length);
                  if (var7 > 0) {
                     this.outputStream.write(var2, 0, var7);
                  }
               }

               this.stopRecording();
            } catch (Exception var8) {
               this.errorMessage = "Error durante la grabación: " + var8.getMessage();
               this.stopRecording();
            }

         });
         var4.start();
      } catch (LineUnavailableException var5) {
         this.errorMessage = "El dispositivo de audio no está disponible o está siendo utilizado por otra aplicación.";
      } catch (Exception var6) {
         this.errorMessage = "Error al iniciar la grabación: " + var6.getMessage();
      }

   }

   public void stopRecording() {
      if (this.isRecording) {
         this.isRecording = false;

         try {
            if (this.targetLine != null) {
               this.targetLine.stop();
               this.targetLine.close();
            }

            if (this.outputStream != null) {
               this.audioData = this.outputStream.toByteArray();
               this.outputStream.close();
            }
         } catch (IOException var2) {
            this.errorMessage = "Error al detener la grabación: " + var2.getMessage();
         }
      }

   }

   public boolean isRecording() {
      return this.isRecording;
   }

   public byte[] getAudioData() {
      return this.audioData;
   }

   public String getErrorMessage() {
      return this.errorMessage;
   }

   public boolean hasError() {
      return this.errorMessage != null;
   }
}
