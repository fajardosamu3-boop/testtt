package com.fasterxml.jackson.databind.annotation;

public final class NoClass {
   private NoClass() {
   }
}
