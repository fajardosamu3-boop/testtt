package com.fasterxml.jackson.databind.jsonFormatVisitors;

public interface JsonAnyFormatVisitor {
   public static class Base implements JsonAnyFormatVisitor {
   }
}
