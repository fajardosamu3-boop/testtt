import a.api.entities.Message;
import a.api.entities.MessageEmbed;
import a.api.requests.RestAction;
import a.api.requests.restaction.MessageAction;

public class TextChannel {
   public RestAction<TextChannel> sendMessage(MessageEmbed var1) {
      throw new UnsupportedOperationException("Unimplemented method 'sendMessage'");
   }

   public MessageAction sendMessage(String var1) {
      throw new UnsupportedOperationException("Unimplemented method 'sendMessage'");
   }

   public String getName() {
      throw new UnsupportedOperationException("Unimplemented method 'getName'");
   }

   public RestAction<Message> sendMessageEmbeds(MessageEmbed var1) {
      throw new UnsupportedOperationException("Unimplemented method 'sendMessageEmbeds'");
   }
}
