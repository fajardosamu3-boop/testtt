package i;

import java.io.EOFException;
import java.io.IOException;
import java.util.Arrays;
import java.util.zip.CRC32;
import java.util.zip.Inflater;
import k.Metadata;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0002\u0010\u0003J \u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0012H\u0002J\b\u0010\u0014\u001a\u00020\u000eH\u0016J\b\u0010\u0015\u001a\u00020\u000eH\u0002J\b\u0010\u0016\u001a\u00020\u000eH\u0002J\u0018\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u0018H\u0016J\b\u0010\u001c\u001a\u00020\u001dH\u0016J \u0010\u001e\u001a\u00020\u000e2\u0006\u0010\u001f\u001a\u00020\u001a2\u0006\u0010 \u001a\u00020\u00182\u0006\u0010\u001b\u001a\u00020\u0018H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006!"},
   d2 = {"Li/GzipSource;", "Li/Source;", "source", "(Lokio/Source;)V", "crc", "Ljava/util/zip/CRC32;", "inflater", "Ljava/util/zip/Inflater;", "inflaterSource", "Li/InflaterSource;", "section", "", "Li/RealBufferedSource;", "checkEqual", "", "name", "", "expected", "", "actual", "close", "consumeHeader", "consumeTrailer", "read", "", "sink", "Li/Buffer;", "byteCount", "timeout", "Li/Timeout;", "updateCrc", "buffer", "offset", "i"}
)
public final class GzipSource implements Source {
   private byte section;
   private final RealBufferedSource source;
   private final Inflater inflater;
   private final InflaterSource inflaterSource;
   private final CRC32 crc;

   public long read(@NotNull Buffer sink, long byteCount) throws IOException {
      Intrinsics.checkNotNullParameter(sink, "sink");
      boolean var4 = byteCount >= 0L;
      boolean var5 = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var10 = "byteCount < 0: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var10.toString()));
      } else if (byteCount == 0L) {
         return 0L;
      } else {
         if (this.section == 0) {
            this.consumeHeader();
            this.section = 1;
         }

         if (this.section == 1) {
            long offset = sink.size();
            long result = this.inflaterSource.read(sink, byteCount);
            if (result != -1L) {
               this.updateCrc(sink, offset, result);
               return result;
            }

            this.section = 2;
         }

         if (this.section == 2) {
            this.consumeTrailer();
            this.section = 3;
            if (!this.source.exhausted()) {
               throw (Throwable)(new IOException("gzip finished without exhausting source"));
            }
         }

         return -1L;
      }
   }

   private final void consumeHeader() throws IOException {
      this.source.require(10L);
      RealBufferedSource this_$iv = this.source;
      int $i$f$getBuffer = false;
      int flags = this_$iv.bufferField.getByte(3L);
      int bit$iv = 1;
      int $i$f$getBuffer = false;
      boolean fhcrc = (flags >> bit$iv & 1) == 1;
      if (fhcrc) {
         RealBufferedSource this_$iv = this.source;
         int $i$f$getBuffer = false;
         this.updateCrc(this_$iv.bufferField, 0L, 10L);
      }

      short id1id2 = this.source.readShort();
      this.checkEqual("ID1ID2", 8075, id1id2);
      this.source.skip(8L);
      int bit$iv = 2;
      int $i$f$getBit = false;
      boolean $i$f$getBuffer;
      long index;
      RealBufferedSource this_$iv;
      if ((flags >> bit$iv & 1) == 1) {
         this.source.require(2L);
         if (fhcrc) {
            RealBufferedSource this_$iv = this.source;
            $i$f$getBuffer = false;
            this.updateCrc(this_$iv.bufferField, 0L, 2L);
         }

         this_$iv = this.source;
         $i$f$getBuffer = false;
         index = (long)this_$iv.bufferField.readShortLe();
         this.source.require(index);
         if (fhcrc) {
            this_$iv = this.source;
            $i$f$getBuffer = false;
            this.updateCrc(this_$iv.bufferField, 0L, index);
         }

         this.source.skip(index);
      }

      bit$iv = 3;
      $i$f$getBit = false;
      if ((flags >> bit$iv & 1) == 1) {
         index = this.source.indexOf((byte)0);
         if (index == -1L) {
            throw (Throwable)(new EOFException());
         }

         if (fhcrc) {
            this_$iv = this.source;
            $i$f$getBuffer = false;
            this.updateCrc(this_$iv.bufferField, 0L, index + 1L);
         }

         this.source.skip(index + 1L);
      }

      bit$iv = 4;
      $i$f$getBit = false;
      if ((flags >> bit$iv & 1) == 1) {
         index = this.source.indexOf((byte)0);
         if (index == -1L) {
            throw (Throwable)(new EOFException());
         }

         if (fhcrc) {
            this_$iv = this.source;
            $i$f$getBuffer = false;
            this.updateCrc(this_$iv.bufferField, 0L, index + 1L);
         }

         this.source.skip(index + 1L);
      }

      if (fhcrc) {
         this.checkEqual("FHCRC", this.source.readShortLe(), (short)((int)this.crc.getValue()));
         this.crc.reset();
      }

   }

   private final void consumeTrailer() throws IOException {
      this.checkEqual("CRC", this.source.readIntLe(), (int)this.crc.getValue());
      this.checkEqual("ISIZE", this.source.readIntLe(), (int)this.inflater.getBytesWritten());
   }

   @NotNull
   public Timeout timeout() {
      return this.source.timeout();
   }

   public void close() throws IOException {
      this.inflaterSource.close();
   }

   private final void updateCrc(Buffer buffer, long offset, long byteCount) {
      long offset = offset;
      long byteCount = byteCount;
      Segment var10000 = buffer.head;
      Intrinsics.checkNotNull(var10000);

      Segment s;
      for(s = var10000; offset >= (long)(s.limit - s.pos); s = var10000) {
         offset -= (long)(s.limit - s.pos);
         var10000 = s.next;
         Intrinsics.checkNotNull(var10000);
      }

      while(byteCount > 0L) {
         int pos = (int)((long)s.pos + offset);
         int a$iv = s.limit - pos;
         int $i$f$minOf = false;
         long var15 = (long)a$iv;
         boolean var17 = false;
         int toUpdate = (int)Math.min(var15, byteCount);
         this.crc.update(s.data, pos, toUpdate);
         byteCount -= (long)toUpdate;
         offset = 0L;
         var10000 = s.next;
         Intrinsics.checkNotNull(var10000);
         s = var10000;
      }

   }

   private final void checkEqual(String name, int expected, int actual) {
      if (actual != expected) {
         String var4 = "%s: actual 0x%08x != expected 0x%08x";
         Object[] var5 = new Object[]{name, actual, expected};
         boolean var6 = false;
         String var10002 = String.format(var4, Arrays.copyOf(var5, var5.length));
         Intrinsics.checkNotNullExpressionValue(var10002, "java.lang.String.format(this, *args)");
         throw (Throwable)(new IOException(var10002));
      }
   }

   public GzipSource(@NotNull Source source) {
      Intrinsics.checkNotNullParameter(source, "source");
      super();
      this.source = new RealBufferedSource(source);
      this.inflater = new Inflater(true);
      this.inflaterSource = new InflaterSource((BufferedSource)this.source, this.inflater);
      this.crc = new CRC32();
   }
}
