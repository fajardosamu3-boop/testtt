package i;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;
import k.Metadata;
import k.PublishedApi;
import k.Unit;
import k.jvm.functions.Function0;
import k.jvm.internal.DefaultConstructorMarker;
import k.jvm.internal.InlineMarker;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0016\u0018\u0000 \u001b2\u00020\u0001:\u0002\u001b\u001cB\u0005¢\u0006\u0002\u0010\u0002J\u0012\u0010\b\u001a\u00020\t2\b\u0010\n\u001a\u0004\u0018\u00010\tH\u0001J\u0006\u0010\u000b\u001a\u00020\fJ\u0006\u0010\r\u001a\u00020\u0004J\u0012\u0010\u000e\u001a\u00020\t2\b\u0010\n\u001a\u0004\u0018\u00010\tH\u0014J\u0010\u0010\u000f\u001a\u00020\u00072\u0006\u0010\u0010\u001a\u00020\u0007H\u0002J\u000e\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0011\u001a\u00020\u0012J\u000e\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0013\u001a\u00020\u0014J\b\u0010\u0015\u001a\u00020\fH\u0014J%\u0010\u0016\u001a\u0002H\u0017\"\u0004\b\u0000\u0010\u00172\f\u0010\u0018\u001a\b\u0012\u0004\u0012\u0002H\u00170\u0019H\u0086\bø\u0001\u0000¢\u0006\u0002\u0010\u001aR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0000X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\u001d"},
   d2 = {"Li/AsyncTimeout;", "Li/Timeout;", "()V", "inQueue", "", "next", "timeoutAt", "", "access$newTimeoutException", "Ljava/io/IOException;", "cause", "enter", "", "exit", "newTimeoutException", "remainingNanos", "now", "sink", "Li/Sink;", "source", "Li/Source;", "timedOut", "withTimeout", "T", "block", "Lk/Function0;", "(Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "Companion", "Watchdog", "i"}
)
public class AsyncTimeout extends Timeout {
   private boolean inQueue;
   private AsyncTimeout next;
   private long timeoutAt;
   private static final int TIMEOUT_WRITE_SIZE = 65536;
   private static final long IDLE_TIMEOUT_MILLIS;
   private static final long IDLE_TIMEOUT_NANOS;
   private static AsyncTimeout head;
   public static final AsyncTimeout.Companion Companion = new AsyncTimeout.Companion((DefaultConstructorMarker)null);

   public final void enter() {
      boolean var1 = !this.inQueue;
      boolean var2 = false;
      boolean hasDeadline = false;
      if (!var1) {
         int var4 = false;
         String var6 = "Unbalanced enter/exit";
         throw (Throwable)(new IllegalStateException(var6.toString()));
      } else {
         long timeoutNanos = this.timeoutNanos();
         hasDeadline = this.hasDeadline();
         if (timeoutNanos != 0L || hasDeadline) {
            this.inQueue = true;
            Companion.scheduleTimeout(this, timeoutNanos, hasDeadline);
         }
      }
   }

   public final boolean exit() {
      if (!this.inQueue) {
         return false;
      } else {
         this.inQueue = false;
         return Companion.cancelScheduledTimeout(this);
      }
   }

   private final long remainingNanos(long now) {
      return this.timeoutAt - now;
   }

   protected void timedOut() {
   }

   @NotNull
   public final Sink sink(@NotNull final Sink sink) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      return (Sink)(new Sink() {
         public void write(@NotNull Buffer source, long byteCount) {
            Intrinsics.checkNotNullParameter(source, "source");
            -Util.checkOffsetAndCount(source.size(), 0L, byteCount);

            long toWrite;
            for(long remaining = byteCount; remaining > 0L; remaining -= toWrite) {
               toWrite = 0L;
               Segment var10000 = source.head;
               Intrinsics.checkNotNull(var10000);

               for(Segment s = var10000; toWrite < (long)65536; s = var10000) {
                  int segmentSize = s.limit - s.pos;
                  toWrite += (long)segmentSize;
                  if (toWrite >= remaining) {
                     toWrite = remaining;
                     break;
                  }

                  var10000 = s.next;
                  Intrinsics.checkNotNull(var10000);
               }

               AsyncTimeout this_$iv = AsyncTimeout.this;
               int $i$f$withTimeout = false;
               boolean throwOnTimeout$iv = false;
               this_$iv.enter();
               boolean var17 = false;

               boolean timedOut$iv;
               try {
                  var17 = true;
                  timedOut$iv = false;
                  sink.write(source, toWrite);
                  Object result$iv = Unit.INSTANCE;
                  throwOnTimeout$iv = true;
                  var17 = false;
               } catch (IOException var18) {
                  throw !this_$iv.exit() ? (Throwable)var18 : (Throwable)this_$iv.access$newTimeoutException(var18);
               } finally {
                  if (var17) {
                     boolean var12 = this_$iv.exit();
                     if (var12 && throwOnTimeout$iv) {
                        throw (Throwable)this_$iv.access$newTimeoutException((IOException)null);
                     }

                  }
               }

               timedOut$iv = this_$iv.exit();
               if (timedOut$iv) {
                  throw (Throwable)this_$iv.access$newTimeoutException((IOException)null);
               }
            }

         }

         public void flush() {
            AsyncTimeout this_$iv = AsyncTimeout.this;
            int $i$f$withTimeout = false;
            boolean throwOnTimeout$iv = false;
            this_$iv.enter();
            boolean var9 = false;

            try {
               var9 = true;
               int var4 = false;
               sink.flush();
               Object result$iv = Unit.INSTANCE;
               throwOnTimeout$iv = true;
               var9 = false;
            } catch (IOException var10) {
               throw !this_$iv.exit() ? (Throwable)var10 : (Throwable)this_$iv.access$newTimeoutException(var10);
            } finally {
               if (var9) {
                  boolean var5 = this_$iv.exit();
                  if (var5 && throwOnTimeout$iv) {
                     throw (Throwable)this_$iv.access$newTimeoutException((IOException)null);
                  }

               }
            }

            boolean timedOut$iv = this_$iv.exit();
            if (timedOut$iv) {
               throw (Throwable)this_$iv.access$newTimeoutException((IOException)null);
            }
         }

         public void close() {
            AsyncTimeout this_$iv = AsyncTimeout.this;
            int $i$f$withTimeout = false;
            boolean throwOnTimeout$iv = false;
            this_$iv.enter();
            boolean var9 = false;

            try {
               var9 = true;
               int var4 = false;
               sink.close();
               Object result$iv = Unit.INSTANCE;
               throwOnTimeout$iv = true;
               var9 = false;
            } catch (IOException var10) {
               throw !this_$iv.exit() ? (Throwable)var10 : (Throwable)this_$iv.access$newTimeoutException(var10);
            } finally {
               if (var9) {
                  boolean var5 = this_$iv.exit();
                  if (var5 && throwOnTimeout$iv) {
                     throw (Throwable)this_$iv.access$newTimeoutException((IOException)null);
                  }

               }
            }

            boolean timedOut$iv = this_$iv.exit();
            if (timedOut$iv) {
               throw (Throwable)this_$iv.access$newTimeoutException((IOException)null);
            }
         }

         @NotNull
         public AsyncTimeout timeout() {
            return AsyncTimeout.this;
         }

         @NotNull
         public String toString() {
            return "AsyncTimeout.sink(" + sink + ')';
         }
      });
   }

   @NotNull
   public final Source source(@NotNull final Source source) {
      Intrinsics.checkNotNullParameter(source, "source");
      return (Source)(new Source() {
         public long read(@NotNull Buffer sink, long byteCount) {
            Intrinsics.checkNotNullParameter(sink, "sink");
            AsyncTimeout this_$iv = AsyncTimeout.this;
            int $i$f$withTimeout = false;
            boolean throwOnTimeout$iv = false;
            this_$iv.enter();
            boolean var15 = false;

            long var10;
            try {
               var15 = true;
               int var7 = false;
               long result$iv = source.read(sink, byteCount);
               throwOnTimeout$iv = true;
               var10 = result$iv;
               var15 = false;
            } catch (IOException var16) {
               throw !this_$iv.exit() ? (Throwable)var16 : (Throwable)this_$iv.access$newTimeoutException(var16);
            } finally {
               if (var15) {
                  boolean var18 = this_$iv.exit();
                  if (var18 && throwOnTimeout$iv) {
                     throw (Throwable)this_$iv.access$newTimeoutException((IOException)null);
                  }

               }
            }

            boolean timedOut$iv = this_$iv.exit();
            if (timedOut$iv) {
               throw (Throwable)this_$iv.access$newTimeoutException((IOException)null);
            } else {
               return var10;
            }
         }

         public void close() {
            AsyncTimeout this_$iv = AsyncTimeout.this;
            int $i$f$withTimeout = false;
            boolean throwOnTimeout$iv = false;
            this_$iv.enter();
            boolean var9 = false;

            try {
               var9 = true;
               int var4 = false;
               source.close();
               Object result$iv = Unit.INSTANCE;
               throwOnTimeout$iv = true;
               var9 = false;
            } catch (IOException var10) {
               throw !this_$iv.exit() ? (Throwable)var10 : (Throwable)this_$iv.access$newTimeoutException(var10);
            } finally {
               if (var9) {
                  boolean var5 = this_$iv.exit();
                  if (var5 && throwOnTimeout$iv) {
                     throw (Throwable)this_$iv.access$newTimeoutException((IOException)null);
                  }

               }
            }

            boolean timedOut$iv = this_$iv.exit();
            if (timedOut$iv) {
               throw (Throwable)this_$iv.access$newTimeoutException((IOException)null);
            }
         }

         @NotNull
         public AsyncTimeout timeout() {
            return AsyncTimeout.this;
         }

         @NotNull
         public String toString() {
            return "AsyncTimeout.source(" + source + ')';
         }
      });
   }

   public final <T> T withTimeout(@NotNull Function0<? extends T> block) {
      int $i$f$withTimeout = 0;
      Intrinsics.checkNotNullParameter(block, "block");
      boolean throwOnTimeout = false;
      this.enter();
      boolean var9 = false;

      Object var5;
      try {
         var9 = true;
         Object result = block.invoke();
         throwOnTimeout = true;
         var5 = result;
         var9 = false;
      } catch (IOException var10) {
         throw !this.exit() ? (Throwable)var10 : (Throwable)this.access$newTimeoutException(var10);
      } finally {
         if (var9) {
            InlineMarker.finallyStart(1);
            boolean var12 = this.exit();
            if (var12 && throwOnTimeout) {
               throw (Throwable)this.access$newTimeoutException((IOException)null);
            }

            InlineMarker.finallyEnd(1);
         }
      }

      InlineMarker.finallyStart(1);
      boolean timedOut = this.exit();
      if (timedOut) {
         throw (Throwable)this.access$newTimeoutException((IOException)null);
      } else {
         InlineMarker.finallyEnd(1);
         return var5;
      }
   }

   @PublishedApi
   @NotNull
   public final IOException access$newTimeoutException(@Nullable IOException cause) {
      return this.newTimeoutException(cause);
   }

   @NotNull
   protected IOException newTimeoutException(@Nullable IOException cause) {
      InterruptedIOException e = new InterruptedIOException("timeout");
      if (cause != null) {
         e.initCause((Throwable)cause);
      }

      return (IOException)e;
   }

   static {
      IDLE_TIMEOUT_MILLIS = TimeUnit.SECONDS.toMillis(60L);
      IDLE_TIMEOUT_NANOS = TimeUnit.MILLISECONDS.toNanos(IDLE_TIMEOUT_MILLIS);
   }

   // $FF: synthetic method
   public static final long access$getTimeoutAt$p(AsyncTimeout $this) {
      return $this.timeoutAt;
   }

   @Metadata(
      mv = {1, 4, 0},
      bv = {1, 0, 3},
      k = 1,
      d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0000¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0016¨\u0006\u0005"},
      d2 = {"Li/AsyncTimeout$Watchdog;", "Ljava/lang/Thread;", "()V", "run", "", "i"}
   )
   private static final class Watchdog extends Thread {
      public void run() {
         while(true) {
            try {
               Object timedOut = (AsyncTimeout)null;
               Object lock$iv = AsyncTimeout.class;
               int $i$f$synchronized = false;
               boolean var4 = false;
               boolean var5 = false;
               synchronized(lock$iv){}

               try {
                  int var6 = false;
                  timedOut = AsyncTimeout.Companion.awaitTimeout$okio();
                  if (timedOut == AsyncTimeout.head) {
                     AsyncTimeout.head = (AsyncTimeout)null;
                     return;
                  }

                  Unit var11 = Unit.INSTANCE;
               } finally {
                  ;
               }

               if (timedOut != null) {
                  timedOut.timedOut();
               }
            } catch (InterruptedException var10) {
            }
         }
      }

      public Watchdog() {
         super("Okio Watchdog");
         this.setDaemon(true);
      }
   }

   @Metadata(
      mv = {1, 4, 0},
      bv = {1, 0, 3},
      k = 1,
      d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000f\u0010\n\u001a\u0004\u0018\u00010\tH\u0000¢\u0006\u0002\b\u000bJ\u0010\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\tH\u0002J \u0010\u000f\u001a\u00020\u00102\u0006\u0010\u000e\u001a\u00020\t2\u0006\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u0012\u001a\u00020\rH\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0013"},
      d2 = {"Li/AsyncTimeout$Companion;", "", "()V", "IDLE_TIMEOUT_MILLIS", "", "IDLE_TIMEOUT_NANOS", "TIMEOUT_WRITE_SIZE", "", "head", "Li/AsyncTimeout;", "awaitTimeout", "awaitTimeout$okio", "cancelScheduledTimeout", "", "node", "scheduleTimeout", "", "timeoutNanos", "hasDeadline", "i"}
   )
   public static final class Companion {
      private final void scheduleTimeout(AsyncTimeout node, long timeoutNanos, boolean hasDeadline) {
         Object lock$iv = AsyncTimeout.class;
         int $i$f$synchronized = false;
         boolean var7 = false;
         boolean var8 = false;
         synchronized(lock$iv){}

         try {
            int var9 = false;
            if (AsyncTimeout.head == null) {
               AsyncTimeout.head = new AsyncTimeout();
               (new AsyncTimeout.Watchdog()).start();
            }

            long now = System.nanoTime();
            if (timeoutNanos != 0L && hasDeadline) {
               long var14 = node.deadlineNanoTime() - now;
               boolean var16 = false;
               node.timeoutAt = now + Math.min(timeoutNanos, var14);
            } else if (timeoutNanos != 0L) {
               node.timeoutAt = now + timeoutNanos;
            } else {
               if (!hasDeadline) {
                  throw (Throwable)(new AssertionError());
               }

               node.timeoutAt = node.deadlineNanoTime();
            }

            long remainingNanos = node.remainingNanos(now);
            AsyncTimeout var10000 = AsyncTimeout.head;
            Intrinsics.checkNotNull(var10000);

            AsyncTimeout prev;
            for(prev = var10000; prev.next != null; prev = var10000) {
               AsyncTimeout var10001 = prev.next;
               Intrinsics.checkNotNull(var10001);
               if (remainingNanos < var10001.remainingNanos(now)) {
                  break;
               }

               var10000 = prev.next;
               Intrinsics.checkNotNull(var10000);
            }

            node.next = prev.next;
            prev.next = node;
            if (prev == AsyncTimeout.head) {
               ((Object)AsyncTimeout.class).notify();
            }

            Unit var20 = Unit.INSTANCE;
         } finally {
            ;
         }

      }

      private final boolean cancelScheduledTimeout(AsyncTimeout node) {
         Object lock$iv = AsyncTimeout.class;
         int $i$f$synchronized = false;
         boolean var4 = false;
         boolean var5 = false;
         synchronized(lock$iv){}

         try {
            int var6 = false;

            for(AsyncTimeout prev = AsyncTimeout.head; prev != null; prev = prev.next) {
               if (prev.next == node) {
                  prev.next = node.next;
                  node.next = (AsyncTimeout)null;
                  boolean var9 = false;
                  return var9;
               }
            }

            boolean var8 = true;
            return var8;
         } finally {
            ;
         }
      }

      @Nullable
      public final AsyncTimeout awaitTimeout$okio() throws InterruptedException {
         AsyncTimeout var10000 = AsyncTimeout.head;
         Intrinsics.checkNotNull(var10000);
         AsyncTimeout node = var10000.next;
         long waitNanos;
         if (node != null) {
            waitNanos = node.remainingNanos(System.nanoTime());
            if (waitNanos > 0L) {
               long waitMillis = waitNanos / 1000000L;
               waitNanos -= waitMillis * 1000000L;
               ((Object)AsyncTimeout.class).wait(waitMillis, (int)waitNanos);
               return null;
            } else {
               var10000 = AsyncTimeout.head;
               Intrinsics.checkNotNull(var10000);
               var10000.next = node.next;
               node.next = (AsyncTimeout)null;
               return node;
            }
         } else {
            waitNanos = System.nanoTime();
            ((Object)AsyncTimeout.class).wait(AsyncTimeout.IDLE_TIMEOUT_MILLIS);
            var10000 = AsyncTimeout.head;
            Intrinsics.checkNotNull(var10000);
            return var10000.next == null && System.nanoTime() - waitNanos >= AsyncTimeout.IDLE_TIMEOUT_NANOS ? AsyncTimeout.head : null;
         }
      }

      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
