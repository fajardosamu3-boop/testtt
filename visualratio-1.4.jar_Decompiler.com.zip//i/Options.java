package i;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.RandomAccess;
import k.Metadata;
import k.collections.AbstractList;
import k.collections.ArraysKt;
import k.collections.CollectionsKt;
import k.jvm.JvmStatic;
import k.jvm.internal.DefaultConstructorMarker;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0000\n\u0002\u0010\u0015\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\b\u0018\u0000 \u00152\b\u0012\u0004\u0012\u00020\u00020\u00012\u00060\u0003j\u0002`\u0004:\u0001\u0015B\u001f\b\u0002\u0012\u000e\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tJ\u0011\u0010\u0013\u001a\u00020\u00022\u0006\u0010\u0014\u001a\u00020\u000eH\u0096\u0002R\u001e\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00020\u0006X\u0080\u0004¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\n\u0010\u000bR\u0014\u0010\r\u001a\u00020\u000e8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010R\u0014\u0010\u0007\u001a\u00020\bX\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012¨\u0006\u0016"},
   d2 = {"Li/Options;", "Lk/collections/AbstractList;", "Li/ByteString;", "Ljava/util/RandomAccess;", "Lk/collections/RandomAccess;", "byteStrings", "", "trie", "", "([Lokio/ByteString;[I)V", "getByteStrings$okio", "()[Lokio/ByteString;", "[Li/ByteString;", "size", "", "getSize", "()I", "getTrie$okio", "()[I", "get", "index", "Companion", "i"}
)
public final class Options extends AbstractList<ByteString> implements RandomAccess {
   @NotNull
   private final ByteString[] byteStrings;
   @NotNull
   private final int[] trie;
   public static final Options.Companion Companion = new Options.Companion((DefaultConstructorMarker)null);

   public int getSize() {
      return this.byteStrings.length;
   }

   @NotNull
   public ByteString get(int index) {
      return this.byteStrings[index];
   }

   @NotNull
   public final ByteString[] getByteStrings$okio() {
      return this.byteStrings;
   }

   @NotNull
   public final int[] getTrie$okio() {
      return this.trie;
   }

   private Options(ByteString[] byteStrings, int[] trie) {
      this.byteStrings = byteStrings;
      this.trie = trie;
   }

   // $FF: synthetic method
   public Options(ByteString[] byteStrings, int[] trie, DefaultConstructorMarker $constructor_marker) {
      this(byteStrings, trie);
   }

   @JvmStatic
   @NotNull
   public static final Options of(@NotNull ByteString... byteStrings) {
      return Companion.of(byteStrings);
   }

   @Metadata(
      mv = {1, 4, 0},
      bv = {1, 0, 3},
      k = 1,
      d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002JT\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u00052\b\b\u0002\u0010\f\u001a\u00020\r2\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000f2\b\b\u0002\u0010\u0011\u001a\u00020\r2\b\b\u0002\u0010\u0012\u001a\u00020\r2\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\r0\u000fH\u0002J!\u0010\u0014\u001a\u00020\u00152\u0012\u0010\u000e\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00100\u0016\"\u00020\u0010H\u0007¢\u0006\u0002\u0010\u0017R\u0018\u0010\u0003\u001a\u00020\u0004*\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0018"},
      d2 = {"Li/Options$Companion;", "", "()V", "intCount", "", "Li/Buffer;", "getIntCount", "(Lokio/Buffer;)J", "buildTrieRecursive", "", "nodeOffset", "node", "byteStringOffset", "", "byteStrings", "", "Li/ByteString;", "fromIndex", "toIndex", "indexes", "of", "Li/Options;", "", "([Lokio/ByteString;)Lokio/Options;", "i"}
   )
   public static final class Companion {
      @JvmStatic
      @NotNull
      public final Options of(@NotNull ByteString... byteStrings) {
         Intrinsics.checkNotNullParameter(byteStrings, "byteStrings");
         boolean var3 = false;
         if (byteStrings.length == 0) {
            return new Options(new ByteString[0], new int[]{0, -1}, (DefaultConstructorMarker)null);
         } else {
            List list = ArraysKt.toMutableList(byteStrings);
            CollectionsKt.sort(list);
            int $i$f$forEachIndexed = false;
            Collection destination$iv$iv = (Collection)(new ArrayList(byteStrings.length));
            int $i$f$mapTo = false;
            ByteString[] var9 = byteStrings;
            int var10 = byteStrings.length;

            for(int var11 = 0; var11 < var10; ++var11) {
               Object item$iv$iv = var9[var11];
               int var14 = false;
               Integer var16 = -1;
               destination$iv$iv.add(var16);
            }

            Collection $this$toTypedArray$iv = (Collection)((List)destination$iv$iv);
            $i$f$forEachIndexed = false;
            Object[] var10000 = $this$toTypedArray$iv.toArray(new Integer[0]);
            if (var10000 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
            } else {
               List indexes = CollectionsKt.mutableListOf((Integer[])Arrays.copyOf((Integer[])var10000, ((Integer[])var10000).length));
               $i$f$forEachIndexed = false;
               int b = 0;
               ByteString[] var23 = byteStrings;
               int var28 = byteStrings.length;

               for(int var30 = 0; var30 < var28; ++var30) {
                  Object item$iv = var23[var30];
                  int callerIndex = b++;
                  int var13 = false;
                  int sortedIndex = CollectionsKt.binarySearch$default(list, (Comparable)item$iv, 0, 0, 6, (Object)null);
                  indexes.set(sortedIndex, callerIndex);
               }

               boolean var18 = ((ByteString)list.get(0)).size() > 0;
               $i$f$forEachIndexed = false;
               boolean var21 = false;
               if (!var18) {
                  int var29 = false;
                  String var26 = "the empty byte string is not a supported option";
                  throw (Throwable)(new IllegalArgumentException(var26.toString()));
               } else {
                  boolean var31;
                  for(int a = 0; a < list.size(); ++a) {
                     ByteString prefix = (ByteString)list.get(a);
                     b = a + 1;

                     while(b < list.size()) {
                        ByteString byteString = (ByteString)list.get(b);
                        if (!byteString.startsWith(prefix)) {
                           break;
                        }

                        $i$f$mapTo = byteString.size() != prefix.size();
                        var31 = false;
                        boolean var33 = false;
                        if (!$i$f$mapTo) {
                           int var35 = false;
                           String var34 = "duplicate option: " + byteString;
                           throw (Throwable)(new IllegalArgumentException(var34.toString()));
                        }

                        if (((Number)indexes.get(b)).intValue() > ((Number)indexes.get(a)).intValue()) {
                           list.remove(b);
                           indexes.remove(b);
                        } else {
                           ++b;
                        }
                     }
                  }

                  Buffer trieBytes = new Buffer();
                  buildTrieRecursive$default((Options.Companion)this, 0L, trieBytes, 0, list, 0, 0, indexes, 53, (Object)null);
                  int[] trie = new int[(int)((Options.Companion)this).getIntCount(trieBytes)];

                  for(int var27 = 0; !trieBytes.exhausted(); trie[var27++] = trieBytes.readInt()) {
                  }

                  var31 = false;
                  Object[] var10002 = Arrays.copyOf(byteStrings, byteStrings.length);
                  Intrinsics.checkNotNullExpressionValue(var10002, "java.util.Arrays.copyOf(this, size)");
                  return new Options((ByteString[])var10002, trie, (DefaultConstructorMarker)null);
               }
            }
         }
      }

      private final void buildTrieRecursive(long nodeOffset, Buffer node, int byteStringOffset, List<? extends ByteString> byteStrings, int fromIndex, int toIndex, List<Integer> indexes) {
         boolean var9 = fromIndex < toIndex;
         boolean var10 = false;
         boolean var11 = false;
         var11 = false;
         boolean var12 = false;
         boolean var13;
         if (!var9) {
            var13 = false;
            String var28 = "Failed requirement.";
            throw (Throwable)(new IllegalArgumentException(var28.toString()));
         } else {
            int fromIndex = fromIndex;

            for(int var23 = toIndex; fromIndex < var23; ++fromIndex) {
               var11 = ((ByteString)byteStrings.get(fromIndex)).size() >= byteStringOffset;
               var12 = false;
               var13 = false;
               var13 = false;
               boolean var14 = false;
               if (!var11) {
                  boolean var15 = false;
                  String var29 = "Failed requirement.";
                  throw (Throwable)(new IllegalArgumentException(var29.toString()));
               }
            }

            fromIndex = fromIndex;
            ByteString from = (ByteString)byteStrings.get(fromIndex);
            ByteString to = (ByteString)byteStrings.get(toIndex - 1);
            int prefixIndex = -1;
            if (byteStringOffset == from.size()) {
               prefixIndex = ((Number)indexes.get(fromIndex)).intValue();
               fromIndex = fromIndex + 1;
               from = (ByteString)byteStrings.get(fromIndex);
            }

            int i;
            int rangeStart;
            byte rangeByte;
            int scanByteCount;
            int i;
            int var31;
            long childNodesOffset;
            Buffer childNodes;
            if (from.getByte(byteStringOffset) != to.getByte(byteStringOffset)) {
               scanByteCount = 1;
               i = fromIndex + 1;

               for(var31 = toIndex; i < var31; ++i) {
                  if (((ByteString)byteStrings.get(i - 1)).getByte(byteStringOffset) != ((ByteString)byteStrings.get(i)).getByte(byteStringOffset)) {
                     ++scanByteCount;
                  }
               }

               childNodesOffset = nodeOffset + ((Options.Companion)this).getIntCount(node) + (long)2 + (long)(scanByteCount * 2);
               node.writeInt(scanByteCount);
               node.writeInt(prefixIndex);
               i = fromIndex;

               for(rangeStart = toIndex; i < rangeStart; ++i) {
                  rangeByte = ((ByteString)byteStrings.get(i)).getByte(byteStringOffset);
                  if (i == fromIndex || rangeByte != ((ByteString)byteStrings.get(i - 1)).getByte(byteStringOffset)) {
                     int other$iv = 255;
                     int $i$f$and = false;
                     node.writeInt(rangeByte & other$iv);
                  }
               }

               childNodes = new Buffer();

               int rangeEnd;
               for(rangeStart = fromIndex; rangeStart < toIndex; rangeStart = rangeEnd) {
                  rangeByte = ((ByteString)byteStrings.get(rangeStart)).getByte(byteStringOffset);
                  rangeEnd = toIndex;
                  int i = rangeStart + 1;

                  for(int var42 = toIndex; i < var42; ++i) {
                     if (rangeByte != ((ByteString)byteStrings.get(i)).getByte(byteStringOffset)) {
                        rangeEnd = i;
                        break;
                     }
                  }

                  if (rangeStart + 1 == rangeEnd && byteStringOffset + 1 == ((ByteString)byteStrings.get(rangeStart)).size()) {
                     node.writeInt(((Number)indexes.get(rangeStart)).intValue());
                  } else {
                     node.writeInt(-1 * (int)(childNodesOffset + ((Options.Companion)this).getIntCount(childNodes)));
                     ((Options.Companion)this).buildTrieRecursive(childNodesOffset, childNodes, byteStringOffset + 1, byteStrings, rangeStart, rangeEnd, indexes);
                  }
               }

               node.writeAll((Source)childNodes);
            } else {
               scanByteCount = 0;
               i = byteStringOffset;
               i = from.size();
               rangeStart = to.size();
               boolean var35 = false;

               for(var31 = Math.min(i, rangeStart); i < var31 && from.getByte(i) == to.getByte(i); ++i) {
                  ++scanByteCount;
               }

               childNodesOffset = nodeOffset + ((Options.Companion)this).getIntCount(node) + (long)2 + (long)scanByteCount + 1L;
               node.writeInt(-scanByteCount);
               node.writeInt(prefixIndex);
               i = byteStringOffset;

               boolean $i$f$and;
               for(rangeStart = byteStringOffset + scanByteCount; i < rangeStart; ++i) {
                  rangeByte = from.getByte(i);
                  int other$iv = 255;
                  $i$f$and = false;
                  node.writeInt(rangeByte & other$iv);
               }

               if (fromIndex + 1 == toIndex) {
                  boolean var34 = byteStringOffset + scanByteCount == ((ByteString)byteStrings.get(fromIndex)).size();
                  boolean var36 = false;
                  var35 = false;
                  var35 = false;
                  boolean var38 = false;
                  if (!var34) {
                     $i$f$and = false;
                     String var40 = "Check failed.";
                     throw (Throwable)(new IllegalStateException(var40.toString()));
                  }

                  node.writeInt(((Number)indexes.get(fromIndex)).intValue());
               } else {
                  childNodes = new Buffer();
                  node.writeInt(-1 * (int)(childNodesOffset + ((Options.Companion)this).getIntCount(childNodes)));
                  ((Options.Companion)this).buildTrieRecursive(childNodesOffset, childNodes, byteStringOffset + scanByteCount, byteStrings, fromIndex, toIndex, indexes);
                  node.writeAll((Source)childNodes);
               }
            }

         }
      }

      // $FF: synthetic method
      static void buildTrieRecursive$default(Options.Companion var0, long var1, Buffer var3, int var4, List var5, int var6, int var7, List var8, int var9, Object var10) {
         if ((var9 & 1) != 0) {
            var1 = 0L;
         }

         if ((var9 & 4) != 0) {
            var4 = 0;
         }

         if ((var9 & 16) != 0) {
            var6 = 0;
         }

         if ((var9 & 32) != 0) {
            var7 = var5.size();
         }

         var0.buildTrieRecursive(var1, var3, var4, var5, var6, var7, var8);
      }

      private final long getIntCount(Buffer $this$intCount) {
         return $this$intCount.size() / (long)4;
      }

      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
