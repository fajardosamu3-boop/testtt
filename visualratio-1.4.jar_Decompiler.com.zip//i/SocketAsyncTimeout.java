package i;

import java.io.IOException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import k.Metadata;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0012\u0010\u0005\u001a\u00020\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\u0006H\u0014J\b\u0010\b\u001a\u00020\tH\u0014R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\n"},
   d2 = {"Li/SocketAsyncTimeout;", "Li/AsyncTimeout;", "socket", "Ljava/net/Socket;", "(Ljava/net/Socket;)V", "newTimeoutException", "Ljava/io/IOException;", "cause", "timedOut", "", "i"}
)
final class SocketAsyncTimeout extends AsyncTimeout {
   private final Socket socket;

   @NotNull
   protected IOException newTimeoutException(@Nullable IOException cause) {
      SocketTimeoutException ioe = new SocketTimeoutException("timeout");
      if (cause != null) {
         ioe.initCause((Throwable)cause);
      }

      return (IOException)ioe;
   }

   protected void timedOut() {
      try {
         this.socket.close();
      } catch (Exception var2) {
         Okio__JvmOkioKt.access$getLogger$p().log(Level.WARNING, "Failed to close timed out socket " + this.socket, (Throwable)var2);
      } catch (AssertionError var3) {
         if (!Okio.isAndroidGetsocknameError(var3)) {
            throw (Throwable)var3;
         }

         Okio__JvmOkioKt.access$getLogger$p().log(Level.WARNING, "Failed to close timed out socket " + this.socket, (Throwable)var3);
      }

   }

   public SocketAsyncTimeout(@NotNull Socket socket) {
      Intrinsics.checkNotNullParameter(socket, "socket");
      super();
      this.socket = socket;
   }
}
