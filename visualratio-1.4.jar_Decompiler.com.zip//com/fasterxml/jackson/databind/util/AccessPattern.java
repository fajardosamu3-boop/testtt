package com.fasterxml.jackson.databind.util;

public enum AccessPattern {
   ALWAYS_NULL,
   CONSTANT,
   DYNAMIC;
}
