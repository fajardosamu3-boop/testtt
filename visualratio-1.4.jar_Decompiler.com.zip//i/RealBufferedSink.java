package i;

import java.io.EOFException;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import k.Metadata;
import k.jvm.JvmField;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u0005\u001a\u00020\u0006H\u0016J\b\u0010\u000e\u001a\u00020\u000fH\u0016J\b\u0010\u0010\u001a\u00020\u0001H\u0016J\b\u0010\u0011\u001a\u00020\u0001H\u0016J\b\u0010\u0012\u001a\u00020\u000fH\u0016J\b\u0010\u0013\u001a\u00020\rH\u0016J\b\u0010\u0014\u001a\u00020\u0015H\u0016J\b\u0010\u0016\u001a\u00020\u0017H\u0016J\b\u0010\u0018\u001a\u00020\u0019H\u0016J\u0010\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001dH\u0016J\u0010\u0010\u001a\u001a\u00020\u00012\u0006\u0010\u001c\u001a\u00020\u001eH\u0016J \u0010\u001a\u001a\u00020\u00012\u0006\u0010\u001c\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\u001b2\u0006\u0010 \u001a\u00020\u001bH\u0016J\u0018\u0010\u001a\u001a\u00020\u000f2\u0006\u0010\u001c\u001a\u00020\u00062\u0006\u0010 \u001a\u00020!H\u0016J\u0010\u0010\u001a\u001a\u00020\u00012\u0006\u0010\"\u001a\u00020#H\u0016J \u0010\u001a\u001a\u00020\u00012\u0006\u0010\"\u001a\u00020#2\u0006\u0010\u001f\u001a\u00020\u001b2\u0006\u0010 \u001a\u00020\u001bH\u0016J\u0018\u0010\u001a\u001a\u00020\u00012\u0006\u0010\u001c\u001a\u00020$2\u0006\u0010 \u001a\u00020!H\u0016J\u0010\u0010%\u001a\u00020!2\u0006\u0010\u001c\u001a\u00020$H\u0016J\u0010\u0010&\u001a\u00020\u00012\u0006\u0010'\u001a\u00020\u001bH\u0016J\u0010\u0010(\u001a\u00020\u00012\u0006\u0010)\u001a\u00020!H\u0016J\u0010\u0010*\u001a\u00020\u00012\u0006\u0010)\u001a\u00020!H\u0016J\u0010\u0010+\u001a\u00020\u00012\u0006\u0010,\u001a\u00020\u001bH\u0016J\u0010\u0010-\u001a\u00020\u00012\u0006\u0010,\u001a\u00020\u001bH\u0016J\u0010\u0010.\u001a\u00020\u00012\u0006\u0010)\u001a\u00020!H\u0016J\u0010\u0010/\u001a\u00020\u00012\u0006\u0010)\u001a\u00020!H\u0016J\u0010\u00100\u001a\u00020\u00012\u0006\u00101\u001a\u00020\u001bH\u0016J\u0010\u00102\u001a\u00020\u00012\u0006\u00101\u001a\u00020\u001bH\u0016J\u0018\u00103\u001a\u00020\u00012\u0006\u00104\u001a\u00020\u00192\u0006\u00105\u001a\u000206H\u0016J(\u00103\u001a\u00020\u00012\u0006\u00104\u001a\u00020\u00192\u0006\u00107\u001a\u00020\u001b2\u0006\u00108\u001a\u00020\u001b2\u0006\u00105\u001a\u000206H\u0016J\u0010\u00109\u001a\u00020\u00012\u0006\u00104\u001a\u00020\u0019H\u0016J \u00109\u001a\u00020\u00012\u0006\u00104\u001a\u00020\u00192\u0006\u00107\u001a\u00020\u001b2\u0006\u00108\u001a\u00020\u001bH\u0016J\u0010\u0010:\u001a\u00020\u00012\u0006\u0010;\u001a\u00020\u001bH\u0016R\u001b\u0010\u0005\u001a\u00020\u00068Ö\u0002X\u0096\u0004¢\u0006\f\u0012\u0004\b\u0007\u0010\b\u001a\u0004\b\t\u0010\nR\u0010\u0010\u000b\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\f\u001a\u00020\r8\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006<"},
   d2 = {"Li/RealBufferedSink;", "Li/BufferedSink;", "sink", "Li/Sink;", "(Lokio/Sink;)V", "buffer", "Li/Buffer;", "getBuffer$annotations", "()V", "getBuffer", "()Lokio/Buffer;", "bufferField", "closed", "", "close", "", "emit", "emitCompleteSegments", "flush", "isOpen", "outputStream", "Ljava/io/OutputStream;", "timeout", "Li/Timeout;", "toString", "", "write", "", "source", "Ljava/nio/ByteBuffer;", "", "offset", "byteCount", "", "byteString", "Li/ByteString;", "Li/Source;", "writeAll", "writeByte", "b", "writeDecimalLong", "v", "writeHexadecimalUnsignedLong", "writeInt", "i", "writeIntLe", "writeLong", "writeLongLe", "writeShort", "s", "writeShortLe", "writeString", "string", "charset", "Ljava/nio/charset/Charset;", "beginIndex", "endIndex", "writeUtf8", "writeUtf8CodePoint", "codePoint", "i"}
)
public final class RealBufferedSink implements BufferedSink {
   @JvmField
   @NotNull
   public final Buffer bufferField;
   @JvmField
   public boolean closed;
   @JvmField
   @NotNull
   public final Sink sink;

   /** @deprecated */
   // $FF: synthetic method
   public static void getBuffer$annotations() {
   }

   @NotNull
   public Buffer getBuffer() {
      int $i$f$getBuffer = 0;
      return this.bufferField;
   }

   @NotNull
   public Buffer buffer() {
      return this.bufferField;
   }

   public void write(@NotNull Buffer source, long byteCount) {
      Intrinsics.checkNotNullParameter(source, "source");
      int $i$f$commonWrite = false;
      boolean var6 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var8 = false;
      if (!var6) {
         int var9 = false;
         String var10 = "closed";
         throw (Throwable)(new IllegalStateException(var10.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.write(source, byteCount);
         this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink write(@NotNull ByteString byteString) {
      Intrinsics.checkNotNullParameter(byteString, "byteString");
      int $i$f$commonWrite = false;
      boolean var4 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var8 = "closed";
         throw (Throwable)(new IllegalStateException(var8.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.write(byteString);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink write(@NotNull ByteString byteString, int offset, int byteCount) {
      Intrinsics.checkNotNullParameter(byteString, "byteString");
      int $i$f$commonWrite = false;
      boolean var6 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var8 = false;
      if (!var6) {
         int var9 = false;
         String var10 = "closed";
         throw (Throwable)(new IllegalStateException(var10.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.write(byteString, offset, byteCount);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeUtf8(@NotNull String string) {
      Intrinsics.checkNotNullParameter(string, "string");
      int $i$f$commonWriteUtf8 = false;
      boolean var4 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var8 = "closed";
         throw (Throwable)(new IllegalStateException(var8.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeUtf8(string);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeUtf8(@NotNull String string, int beginIndex, int endIndex) {
      Intrinsics.checkNotNullParameter(string, "string");
      int $i$f$commonWriteUtf8 = false;
      boolean var6 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var8 = false;
      if (!var6) {
         int var9 = false;
         String var10 = "closed";
         throw (Throwable)(new IllegalStateException(var10.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeUtf8(string, beginIndex, endIndex);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeUtf8CodePoint(int codePoint) {
      int $i$f$commonWriteUtf8CodePoint = false;
      boolean var4 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var8 = "closed";
         throw (Throwable)(new IllegalStateException(var8.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeUtf8CodePoint(codePoint);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeString(@NotNull String string, @NotNull Charset charset) {
      Intrinsics.checkNotNullParameter(string, "string");
      Intrinsics.checkNotNullParameter(charset, "charset");
      boolean var3 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var5 = false;
      if (!var3) {
         int var6 = false;
         String var7 = "closed";
         throw (Throwable)(new IllegalStateException(var7.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeString(string, charset);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeString(@NotNull String string, int beginIndex, int endIndex, @NotNull Charset charset) {
      Intrinsics.checkNotNullParameter(string, "string");
      Intrinsics.checkNotNullParameter(charset, "charset");
      boolean var5 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var7 = false;
      if (!var5) {
         int var8 = false;
         String var9 = "closed";
         throw (Throwable)(new IllegalStateException(var9.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeString(string, beginIndex, endIndex, charset);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink write(@NotNull byte[] source) {
      Intrinsics.checkNotNullParameter(source, "source");
      int $i$f$commonWrite = false;
      boolean var4 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var8 = "closed";
         throw (Throwable)(new IllegalStateException(var8.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.write(source);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink write(@NotNull byte[] source, int offset, int byteCount) {
      Intrinsics.checkNotNullParameter(source, "source");
      int $i$f$commonWrite = false;
      boolean var6 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var8 = false;
      if (!var6) {
         int var9 = false;
         String var10 = "closed";
         throw (Throwable)(new IllegalStateException(var10.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.write(source, offset, byteCount);
         return this.emitCompleteSegments();
      }
   }

   public int write(@NotNull ByteBuffer source) {
      Intrinsics.checkNotNullParameter(source, "source");
      boolean var2 = !this.closed;
      boolean var3 = false;
      boolean $i$f$getBuffer = false;
      if (!var2) {
         int var5 = false;
         String var7 = "closed";
         throw (Throwable)(new IllegalStateException(var7.toString()));
      } else {
         $i$f$getBuffer = false;
         int result = this.bufferField.write(source);
         this.emitCompleteSegments();
         return result;
      }
   }

   public long writeAll(@NotNull Source source) {
      Intrinsics.checkNotNullParameter(source, "source");
      RealBufferedSink $this$commonWriteAll$iv = this;
      int $i$f$commonWriteAll = false;
      long totalBytesRead$iv = 0L;

      while(true) {
         int $i$f$getBuffer = false;
         long readCount$iv = source.read($this$commonWriteAll$iv.bufferField, (long)8192);
         if (readCount$iv == -1L) {
            return totalBytesRead$iv;
         }

         totalBytesRead$iv += readCount$iv;
         $this$commonWriteAll$iv.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink write(@NotNull Source source, long byteCount) {
      Intrinsics.checkNotNullParameter(source, "source");
      RealBufferedSink $this$commonWrite$iv = this;
      int $i$f$commonWrite = false;
      long byteCount$iv = byteCount;

      while(byteCount$iv > 0L) {
         int $i$f$getBuffer = false;
         long read$iv = source.read($this$commonWrite$iv.bufferField, byteCount$iv);
         if (read$iv == -1L) {
            throw (Throwable)(new EOFException());
         }

         byteCount$iv -= read$iv;
         $this$commonWrite$iv.emitCompleteSegments();
      }

      return (BufferedSink)$this$commonWrite$iv;
   }

   @NotNull
   public BufferedSink writeByte(int b) {
      int $i$f$commonWriteByte = false;
      boolean var4 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var8 = "closed";
         throw (Throwable)(new IllegalStateException(var8.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeByte(b);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeShort(int s) {
      int $i$f$commonWriteShort = false;
      boolean var4 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var8 = "closed";
         throw (Throwable)(new IllegalStateException(var8.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeShort(s);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeShortLe(int s) {
      int $i$f$commonWriteShortLe = false;
      boolean var4 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var8 = "closed";
         throw (Throwable)(new IllegalStateException(var8.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeShortLe(s);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeInt(int i) {
      int $i$f$commonWriteInt = false;
      boolean var4 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var8 = "closed";
         throw (Throwable)(new IllegalStateException(var8.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeInt(i);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeIntLe(int i) {
      int $i$f$commonWriteIntLe = false;
      boolean var4 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var8 = "closed";
         throw (Throwable)(new IllegalStateException(var8.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeIntLe(i);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeLong(long v) {
      int $i$f$commonWriteLong = false;
      boolean var5 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var7 = false;
      if (!var5) {
         int var8 = false;
         String var9 = "closed";
         throw (Throwable)(new IllegalStateException(var9.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeLong(v);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeLongLe(long v) {
      int $i$f$commonWriteLongLe = false;
      boolean var5 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var7 = false;
      if (!var5) {
         int var8 = false;
         String var9 = "closed";
         throw (Throwable)(new IllegalStateException(var9.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeLongLe(v);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeDecimalLong(long v) {
      int $i$f$commonWriteDecimalLong = false;
      boolean var5 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var7 = false;
      if (!var5) {
         int var8 = false;
         String var9 = "closed";
         throw (Throwable)(new IllegalStateException(var9.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeDecimalLong(v);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink writeHexadecimalUnsignedLong(long v) {
      int $i$f$commonWriteHexadecimalUnsignedLong = false;
      boolean var5 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var7 = false;
      if (!var5) {
         int var8 = false;
         String var9 = "closed";
         throw (Throwable)(new IllegalStateException(var9.toString()));
      } else {
         $i$f$getBuffer = false;
         this.bufferField.writeHexadecimalUnsignedLong(v);
         return this.emitCompleteSegments();
      }
   }

   @NotNull
   public BufferedSink emitCompleteSegments() {
      int $i$f$commonEmitCompleteSegments = false;
      boolean var3 = !this.closed;
      boolean var4 = false;
      boolean var5 = false;
      boolean $i$f$getBuffer;
      if (!var3) {
         $i$f$getBuffer = false;
         String var9 = "closed";
         throw (Throwable)(new IllegalStateException(var9.toString()));
      } else {
         $i$f$getBuffer = false;
         long byteCount$iv = this.bufferField.completeSegmentByteCount();
         if (byteCount$iv > 0L) {
            $i$f$getBuffer = false;
            this.sink.write(this.bufferField, byteCount$iv);
         }

         return (BufferedSink)this;
      }
   }

   @NotNull
   public BufferedSink emit() {
      int $i$f$commonEmit = false;
      boolean var3 = !this.closed;
      boolean var4 = false;
      boolean var5 = false;
      boolean $i$f$getBuffer;
      if (!var3) {
         $i$f$getBuffer = false;
         String var9 = "closed";
         throw (Throwable)(new IllegalStateException(var9.toString()));
      } else {
         $i$f$getBuffer = false;
         long byteCount$iv = this.bufferField.size();
         if (byteCount$iv > 0L) {
            $i$f$getBuffer = false;
            this.sink.write(this.bufferField, byteCount$iv);
         }

         return (BufferedSink)this;
      }
   }

   @NotNull
   public OutputStream outputStream() {
      return (OutputStream)(new OutputStream() {
         public void write(int b) {
            if (RealBufferedSink.this.closed) {
               throw (Throwable)(new IOException("closed"));
            } else {
               RealBufferedSink this_$iv = RealBufferedSink.this;
               int $i$f$getBuffer = false;
               this_$iv.bufferField.writeByte((byte)b);
               RealBufferedSink.this.emitCompleteSegments();
            }
         }

         public void write(@NotNull byte[] data, int offset, int byteCount) {
            Intrinsics.checkNotNullParameter(data, "data");
            if (RealBufferedSink.this.closed) {
               throw (Throwable)(new IOException("closed"));
            } else {
               RealBufferedSink this_$iv = RealBufferedSink.this;
               int $i$f$getBuffer = false;
               this_$iv.bufferField.write(data, offset, byteCount);
               RealBufferedSink.this.emitCompleteSegments();
            }
         }

         public void flush() {
            if (!RealBufferedSink.this.closed) {
               RealBufferedSink.this.flush();
            }

         }

         public void close() {
            RealBufferedSink.this.close();
         }

         @NotNull
         public String toString() {
            return RealBufferedSink.this + ".outputStream()";
         }
      });
   }

   public void flush() {
      int $i$f$commonFlush = false;
      boolean var3 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var5 = false;
      if (!var3) {
         int var6 = false;
         String var7 = "closed";
         throw (Throwable)(new IllegalStateException(var7.toString()));
      } else {
         $i$f$getBuffer = false;
         if (this.bufferField.size() > 0L) {
            $i$f$getBuffer = false;
            $i$f$getBuffer = false;
            this.sink.write(this.bufferField, this.bufferField.size());
         }

         this.sink.flush();
      }
   }

   public boolean isOpen() {
      return !this.closed;
   }

   public void close() {
      RealBufferedSink $this$commonClose$iv = this;
      int $i$f$commonClose = false;
      if (!this.closed) {
         Throwable thrown$iv = (Throwable)null;

         try {
            int $i$f$getBuffer = false;
            if ($this$commonClose$iv.bufferField.size() > 0L) {
               $i$f$getBuffer = false;
               $i$f$getBuffer = false;
               $this$commonClose$iv.sink.write($this$commonClose$iv.bufferField, $this$commonClose$iv.bufferField.size());
            }
         } catch (Throwable var6) {
            thrown$iv = var6;
         }

         try {
            $this$commonClose$iv.sink.close();
         } catch (Throwable var7) {
            if (thrown$iv == null) {
               thrown$iv = var7;
            }
         }

         this.closed = true;
         if (thrown$iv != null) {
            throw thrown$iv;
         }
      }

   }

   @NotNull
   public Timeout timeout() {
      int $i$f$commonTimeout = false;
      return this.sink.timeout();
   }

   @NotNull
   public String toString() {
      int $i$f$commonToString = false;
      return "buffer(" + this.sink + ')';
   }

   public RealBufferedSink(@NotNull Sink sink) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      super();
      this.sink = sink;
      this.bufferField = new Buffer();
   }
}
