package i.internal;

import i.-Base64;
import i.-Platform;
import i.-Util;
import i.Buffer;
import i.ByteString;
import java.util.Arrays;
import k.Metadata;
import k.Unit;
import k.collections.ArraysKt;
import k.jvm.internal.Intrinsics;
import k.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 2,
   d1 = {"\u0000P\n\u0000\n\u0002\u0010\u0019\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\f\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0005\n\u0002\b\u0018\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0005H\u0002\u001a\u0011\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u0007H\u0080\b\u001a\u0010\u0010\f\u001a\u00020\u00052\u0006\u0010\r\u001a\u00020\u000eH\u0002\u001a\r\u0010\u000f\u001a\u00020\u0010*\u00020\nH\u0080\b\u001a\r\u0010\u0011\u001a\u00020\u0010*\u00020\nH\u0080\b\u001a\u0015\u0010\u0012\u001a\u00020\u0005*\u00020\n2\u0006\u0010\u0013\u001a\u00020\nH\u0080\b\u001a\u000f\u0010\u0014\u001a\u0004\u0018\u00010\n*\u00020\u0010H\u0080\b\u001a\r\u0010\u0015\u001a\u00020\n*\u00020\u0010H\u0080\b\u001a\r\u0010\u0016\u001a\u00020\n*\u00020\u0010H\u0080\b\u001a\u0015\u0010\u0017\u001a\u00020\u0018*\u00020\n2\u0006\u0010\u0019\u001a\u00020\u0007H\u0080\b\u001a\u0015\u0010\u0017\u001a\u00020\u0018*\u00020\n2\u0006\u0010\u0019\u001a\u00020\nH\u0080\b\u001a\u0017\u0010\u001a\u001a\u00020\u0018*\u00020\n2\b\u0010\u0013\u001a\u0004\u0018\u00010\u001bH\u0080\b\u001a\u0015\u0010\u001c\u001a\u00020\u001d*\u00020\n2\u0006\u0010\u001e\u001a\u00020\u0005H\u0080\b\u001a\r\u0010\u001f\u001a\u00020\u0005*\u00020\nH\u0080\b\u001a\r\u0010 \u001a\u00020\u0005*\u00020\nH\u0080\b\u001a\r\u0010!\u001a\u00020\u0010*\u00020\nH\u0080\b\u001a\u001d\u0010\"\u001a\u00020\u0005*\u00020\n2\u0006\u0010\u0013\u001a\u00020\u00072\u0006\u0010#\u001a\u00020\u0005H\u0080\b\u001a\r\u0010$\u001a\u00020\u0007*\u00020\nH\u0080\b\u001a\u001d\u0010%\u001a\u00020\u0005*\u00020\n2\u0006\u0010\u0013\u001a\u00020\u00072\u0006\u0010#\u001a\u00020\u0005H\u0080\b\u001a\u001d\u0010%\u001a\u00020\u0005*\u00020\n2\u0006\u0010\u0013\u001a\u00020\n2\u0006\u0010#\u001a\u00020\u0005H\u0080\b\u001a-\u0010&\u001a\u00020\u0018*\u00020\n2\u0006\u0010'\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u00072\u0006\u0010(\u001a\u00020\u00052\u0006\u0010)\u001a\u00020\u0005H\u0080\b\u001a-\u0010&\u001a\u00020\u0018*\u00020\n2\u0006\u0010'\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\n2\u0006\u0010(\u001a\u00020\u00052\u0006\u0010)\u001a\u00020\u0005H\u0080\b\u001a\u0015\u0010*\u001a\u00020\u0018*\u00020\n2\u0006\u0010+\u001a\u00020\u0007H\u0080\b\u001a\u0015\u0010*\u001a\u00020\u0018*\u00020\n2\u0006\u0010+\u001a\u00020\nH\u0080\b\u001a\u001d\u0010,\u001a\u00020\n*\u00020\n2\u0006\u0010-\u001a\u00020\u00052\u0006\u0010.\u001a\u00020\u0005H\u0080\b\u001a\r\u0010/\u001a\u00020\n*\u00020\nH\u0080\b\u001a\r\u00100\u001a\u00020\n*\u00020\nH\u0080\b\u001a\r\u00101\u001a\u00020\u0007*\u00020\nH\u0080\b\u001a\u001d\u00102\u001a\u00020\n*\u00020\u00072\u0006\u0010'\u001a\u00020\u00052\u0006\u0010)\u001a\u00020\u0005H\u0080\b\u001a\r\u00103\u001a\u00020\u0010*\u00020\nH\u0080\b\u001a\r\u00104\u001a\u00020\u0010*\u00020\nH\u0080\b\u001a$\u00105\u001a\u000206*\u00020\n2\u0006\u00107\u001a\u0002082\u0006\u0010'\u001a\u00020\u00052\u0006\u0010)\u001a\u00020\u0005H\u0000\"\u0014\u0010\u0000\u001a\u00020\u0001X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u00069"},
   d2 = {"HEX_DIGIT_CHARS", "", "getHEX_DIGIT_CHARS", "()[C", "codePointIndexToCharIndex", "", "s", "", "codePointCount", "commonOf", "Li/ByteString;", "data", "decodeHexDigit", "c", "", "commonBase64", "", "commonBase64Url", "commonCompareTo", "other", "commonDecodeBase64", "commonDecodeHex", "commonEncodeUtf8", "commonEndsWith", "", "suffix", "commonEquals", "", "commonGetByte", "", "pos", "commonGetSize", "commonHashCode", "commonHex", "commonIndexOf", "fromIndex", "commonInternalArray", "commonLastIndexOf", "commonRangeEquals", "offset", "otherOffset", "byteCount", "commonStartsWith", "prefix", "commonSubstring", "beginIndex", "endIndex", "commonToAsciiLowercase", "commonToAsciiUppercase", "commonToByteArray", "commonToByteString", "commonToString", "commonUtf8", "commonWrite", "", "buffer", "Li/Buffer;", "i"}
)
public final class ByteStringKt {
   @NotNull
   private static final char[] HEX_DIGIT_CHARS = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

   @NotNull
   public static final String commonUtf8(@NotNull ByteString $this$commonUtf8) {
      int $i$f$commonUtf8 = 0;
      Intrinsics.checkNotNullParameter($this$commonUtf8, "$this$commonUtf8");
      String result = $this$commonUtf8.getUtf8$okio();
      if (result == null) {
         result = -Platform.toUtf8String($this$commonUtf8.internalArray$okio());
         $this$commonUtf8.setUtf8$okio(result);
      }

      return result;
   }

   @NotNull
   public static final String commonBase64(@NotNull ByteString $this$commonBase64) {
      int $i$f$commonBase64 = 0;
      Intrinsics.checkNotNullParameter($this$commonBase64, "$this$commonBase64");
      return -Base64.encodeBase64$default($this$commonBase64.getData$okio(), (byte[])null, 1, (Object)null);
   }

   @NotNull
   public static final String commonBase64Url(@NotNull ByteString $this$commonBase64Url) {
      int $i$f$commonBase64Url = 0;
      Intrinsics.checkNotNullParameter($this$commonBase64Url, "$this$commonBase64Url");
      return -Base64.encodeBase64($this$commonBase64Url.getData$okio(), -Base64.getBASE64_URL_SAFE());
   }

   @NotNull
   public static final char[] getHEX_DIGIT_CHARS() {
      return HEX_DIGIT_CHARS;
   }

   @NotNull
   public static final String commonHex(@NotNull ByteString $this$commonHex) {
      int $i$f$commonHex = 0;
      Intrinsics.checkNotNullParameter($this$commonHex, "$this$commonHex");
      char[] result = new char[$this$commonHex.getData$okio().length * 2];
      int c = 0;
      byte[] var6 = $this$commonHex.getData$okio();
      int var7 = var6.length;

      for(int var5 = 0; var5 < var7; ++var5) {
         byte b = var6[var5];
         int var10001 = c++;
         char[] var10002 = getHEX_DIGIT_CHARS();
         int other$iv = 4;
         int $i$f$and = false;
         result[var10001] = var10002[b >> other$iv & 15];
         var10001 = c++;
         var10002 = getHEX_DIGIT_CHARS();
         other$iv = 15;
         $i$f$and = false;
         result[var10001] = var10002[b & other$iv];
      }

      boolean var11 = false;
      return new String(result);
   }

   @NotNull
   public static final ByteString commonToAsciiLowercase(@NotNull ByteString $this$commonToAsciiLowercase) {
      int $i$f$commonToAsciiLowercase = 0;
      Intrinsics.checkNotNullParameter($this$commonToAsciiLowercase, "$this$commonToAsciiLowercase");

      for(int i = 0; i < $this$commonToAsciiLowercase.getData$okio().length; ++i) {
         byte c = $this$commonToAsciiLowercase.getData$okio()[i];
         if (c >= (byte)65 && c <= (byte)90) {
            byte[] var5 = $this$commonToAsciiLowercase.getData$okio();
            boolean var6 = false;
            byte[] var10000 = Arrays.copyOf(var5, var5.length);
            Intrinsics.checkNotNullExpressionValue(var10000, "java.util.Arrays.copyOf(this, size)");
            byte[] lowercase = var10000;
            lowercase[i++] = (byte)(c - -32);

            while(true) {
               while(i < lowercase.length) {
                  c = lowercase[i];
                  if (c >= (byte)65 && c <= (byte)90) {
                     lowercase[i] = (byte)(c - -32);
                     ++i;
                  } else {
                     ++i;
                  }
               }

               return new ByteString(lowercase);
            }
         }
      }

      return $this$commonToAsciiLowercase;
   }

   @NotNull
   public static final ByteString commonToAsciiUppercase(@NotNull ByteString $this$commonToAsciiUppercase) {
      int $i$f$commonToAsciiUppercase = 0;
      Intrinsics.checkNotNullParameter($this$commonToAsciiUppercase, "$this$commonToAsciiUppercase");

      for(int i = 0; i < $this$commonToAsciiUppercase.getData$okio().length; ++i) {
         byte c = $this$commonToAsciiUppercase.getData$okio()[i];
         if (c >= (byte)97 && c <= (byte)122) {
            byte[] var5 = $this$commonToAsciiUppercase.getData$okio();
            boolean var6 = false;
            byte[] var10000 = Arrays.copyOf(var5, var5.length);
            Intrinsics.checkNotNullExpressionValue(var10000, "java.util.Arrays.copyOf(this, size)");
            byte[] lowercase = var10000;
            lowercase[i++] = (byte)(c - 32);

            while(true) {
               while(i < lowercase.length) {
                  c = lowercase[i];
                  if (c >= (byte)97 && c <= (byte)122) {
                     lowercase[i] = (byte)(c - 32);
                     ++i;
                  } else {
                     ++i;
                  }
               }

               return new ByteString(lowercase);
            }
         }
      }

      return $this$commonToAsciiUppercase;
   }

   @NotNull
   public static final ByteString commonSubstring(@NotNull ByteString $this$commonSubstring, int beginIndex, int endIndex) {
      int $i$f$commonSubstring = 0;
      Intrinsics.checkNotNullParameter($this$commonSubstring, "$this$commonSubstring");
      boolean var4 = beginIndex >= 0;
      boolean var5 = false;
      boolean var6 = false;
      boolean var7;
      String var11;
      if (!var4) {
         var7 = false;
         var11 = "beginIndex < 0";
         throw (Throwable)(new IllegalArgumentException(var11.toString()));
      } else {
         var4 = endIndex <= $this$commonSubstring.getData$okio().length;
         var5 = false;
         var6 = false;
         if (!var4) {
            var7 = false;
            var11 = "endIndex > length(" + $this$commonSubstring.getData$okio().length + ')';
            throw (Throwable)(new IllegalArgumentException(var11.toString()));
         } else {
            int subLen = endIndex - beginIndex;
            var5 = subLen >= 0;
            var6 = false;
            var7 = false;
            if (!var5) {
               int var8 = false;
               String var12 = "endIndex < beginIndex";
               throw (Throwable)(new IllegalArgumentException(var12.toString()));
            } else if (beginIndex == 0 && endIndex == $this$commonSubstring.getData$okio().length) {
               return $this$commonSubstring;
            } else {
               byte[] var10 = $this$commonSubstring.getData$okio();
               var6 = false;
               return new ByteString(ArraysKt.copyOfRange(var10, beginIndex, endIndex));
            }
         }
      }
   }

   public static final byte commonGetByte(@NotNull ByteString $this$commonGetByte, int pos) {
      int $i$f$commonGetByte = 0;
      Intrinsics.checkNotNullParameter($this$commonGetByte, "$this$commonGetByte");
      return $this$commonGetByte.getData$okio()[pos];
   }

   public static final int commonGetSize(@NotNull ByteString $this$commonGetSize) {
      int $i$f$commonGetSize = 0;
      Intrinsics.checkNotNullParameter($this$commonGetSize, "$this$commonGetSize");
      return $this$commonGetSize.getData$okio().length;
   }

   @NotNull
   public static final byte[] commonToByteArray(@NotNull ByteString $this$commonToByteArray) {
      int $i$f$commonToByteArray = 0;
      Intrinsics.checkNotNullParameter($this$commonToByteArray, "$this$commonToByteArray");
      byte[] var2 = $this$commonToByteArray.getData$okio();
      boolean var3 = false;
      byte[] var10000 = Arrays.copyOf(var2, var2.length);
      Intrinsics.checkNotNullExpressionValue(var10000, "java.util.Arrays.copyOf(this, size)");
      return var10000;
   }

   @NotNull
   public static final byte[] commonInternalArray(@NotNull ByteString $this$commonInternalArray) {
      int $i$f$commonInternalArray = 0;
      Intrinsics.checkNotNullParameter($this$commonInternalArray, "$this$commonInternalArray");
      return $this$commonInternalArray.getData$okio();
   }

   public static final boolean commonRangeEquals(@NotNull ByteString $this$commonRangeEquals, int offset, @NotNull ByteString other, int otherOffset, int byteCount) {
      int $i$f$commonRangeEquals = 0;
      Intrinsics.checkNotNullParameter($this$commonRangeEquals, "$this$commonRangeEquals");
      Intrinsics.checkNotNullParameter(other, "other");
      return other.rangeEquals(otherOffset, $this$commonRangeEquals.getData$okio(), offset, byteCount);
   }

   public static final boolean commonRangeEquals(@NotNull ByteString $this$commonRangeEquals, int offset, @NotNull byte[] other, int otherOffset, int byteCount) {
      int $i$f$commonRangeEquals = 0;
      Intrinsics.checkNotNullParameter($this$commonRangeEquals, "$this$commonRangeEquals");
      Intrinsics.checkNotNullParameter(other, "other");
      return offset >= 0 && offset <= $this$commonRangeEquals.getData$okio().length - byteCount && otherOffset >= 0 && otherOffset <= other.length - byteCount && -Util.arrayRangeEquals($this$commonRangeEquals.getData$okio(), offset, other, otherOffset, byteCount);
   }

   public static final boolean commonStartsWith(@NotNull ByteString $this$commonStartsWith, @NotNull ByteString prefix) {
      int $i$f$commonStartsWith = 0;
      Intrinsics.checkNotNullParameter($this$commonStartsWith, "$this$commonStartsWith");
      Intrinsics.checkNotNullParameter(prefix, "prefix");
      return $this$commonStartsWith.rangeEquals(0, (ByteString)prefix, 0, prefix.size());
   }

   public static final boolean commonStartsWith(@NotNull ByteString $this$commonStartsWith, @NotNull byte[] prefix) {
      int $i$f$commonStartsWith = 0;
      Intrinsics.checkNotNullParameter($this$commonStartsWith, "$this$commonStartsWith");
      Intrinsics.checkNotNullParameter(prefix, "prefix");
      return $this$commonStartsWith.rangeEquals(0, (byte[])prefix, 0, prefix.length);
   }

   public static final boolean commonEndsWith(@NotNull ByteString $this$commonEndsWith, @NotNull ByteString suffix) {
      int $i$f$commonEndsWith = 0;
      Intrinsics.checkNotNullParameter($this$commonEndsWith, "$this$commonEndsWith");
      Intrinsics.checkNotNullParameter(suffix, "suffix");
      return $this$commonEndsWith.rangeEquals($this$commonEndsWith.size() - suffix.size(), (ByteString)suffix, 0, suffix.size());
   }

   public static final boolean commonEndsWith(@NotNull ByteString $this$commonEndsWith, @NotNull byte[] suffix) {
      int $i$f$commonEndsWith = 0;
      Intrinsics.checkNotNullParameter($this$commonEndsWith, "$this$commonEndsWith");
      Intrinsics.checkNotNullParameter(suffix, "suffix");
      return $this$commonEndsWith.rangeEquals($this$commonEndsWith.size() - suffix.length, (byte[])suffix, 0, suffix.length);
   }

   public static final int commonIndexOf(@NotNull ByteString $this$commonIndexOf, @NotNull byte[] other, int fromIndex) {
      int $i$f$commonIndexOf = 0;
      Intrinsics.checkNotNullParameter($this$commonIndexOf, "$this$commonIndexOf");
      Intrinsics.checkNotNullParameter(other, "other");
      int limit = $this$commonIndexOf.getData$okio().length - other.length;
      byte var7 = 0;
      boolean var8 = false;
      int i = Math.max(fromIndex, var7);
      int var6 = limit;
      if (i <= limit) {
         while(true) {
            if (-Util.arrayRangeEquals($this$commonIndexOf.getData$okio(), i, other, 0, other.length)) {
               return i;
            }

            if (i == var6) {
               break;
            }

            ++i;
         }
      }

      return -1;
   }

   public static final int commonLastIndexOf(@NotNull ByteString $this$commonLastIndexOf, @NotNull ByteString other, int fromIndex) {
      int $i$f$commonLastIndexOf = 0;
      Intrinsics.checkNotNullParameter($this$commonLastIndexOf, "$this$commonLastIndexOf");
      Intrinsics.checkNotNullParameter(other, "other");
      return $this$commonLastIndexOf.lastIndexOf(other.internalArray$okio(), fromIndex);
   }

   public static final int commonLastIndexOf(@NotNull ByteString $this$commonLastIndexOf, @NotNull byte[] other, int fromIndex) {
      int $i$f$commonLastIndexOf = 0;
      Intrinsics.checkNotNullParameter($this$commonLastIndexOf, "$this$commonLastIndexOf");
      Intrinsics.checkNotNullParameter(other, "other");
      int limit = $this$commonLastIndexOf.getData$okio().length - other.length;
      boolean var7 = false;
      int i = Math.min(fromIndex, limit);

      for(boolean var6 = false; i >= 0; --i) {
         if (-Util.arrayRangeEquals($this$commonLastIndexOf.getData$okio(), i, other, 0, other.length)) {
            return i;
         }
      }

      return -1;
   }

   public static final boolean commonEquals(@NotNull ByteString $this$commonEquals, @Nullable Object other) {
      int $i$f$commonEquals = 0;
      Intrinsics.checkNotNullParameter($this$commonEquals, "$this$commonEquals");
      return other == $this$commonEquals ? true : (other instanceof ByteString ? ((ByteString)other).size() == $this$commonEquals.getData$okio().length && ((ByteString)other).rangeEquals(0, (byte[])$this$commonEquals.getData$okio(), 0, $this$commonEquals.getData$okio().length) : false);
   }

   public static final int commonHashCode(@NotNull ByteString $this$commonHashCode) {
      int $i$f$commonHashCode = 0;
      Intrinsics.checkNotNullParameter($this$commonHashCode, "$this$commonHashCode");
      int result = $this$commonHashCode.getHashCode$okio();
      if (result != 0) {
         return result;
      } else {
         byte[] var3 = $this$commonHashCode.getData$okio();
         boolean var4 = false;
         int var8 = Arrays.hashCode(var3);
         var4 = false;
         boolean var5 = false;
         int var7 = false;
         $this$commonHashCode.setHashCode$okio(var8);
         return var8;
      }
   }

   public static final int commonCompareTo(@NotNull ByteString $this$commonCompareTo, @NotNull ByteString other) {
      int $i$f$commonCompareTo = 0;
      Intrinsics.checkNotNullParameter($this$commonCompareTo, "$this$commonCompareTo");
      Intrinsics.checkNotNullParameter(other, "other");
      int sizeA = $this$commonCompareTo.size();
      int sizeB = other.size();
      int i = 0;
      boolean var7 = false;

      for(int size = Math.min(sizeA, sizeB); i < size; ++i) {
         byte $this$and$iv = $this$commonCompareTo.getByte(i);
         int other$iv = 255;
         int $i$f$and = false;
         int byteA = $this$and$iv & other$iv;
         byte $this$and$iv = other.getByte(i);
         int other$iv = 255;
         int $i$f$and = false;
         int byteB = $this$and$iv & other$iv;
         if (byteA != byteB) {
            return byteA < byteB ? -1 : 1;
         }
      }

      if (sizeA == sizeB) {
         return 0;
      } else {
         return sizeA < sizeB ? -1 : 1;
      }
   }

   @NotNull
   public static final ByteString commonOf(@NotNull byte[] data) {
      int $i$f$commonOf = 0;
      Intrinsics.checkNotNullParameter(data, "data");
      boolean var3 = false;
      byte[] var10002 = Arrays.copyOf(data, data.length);
      Intrinsics.checkNotNullExpressionValue(var10002, "java.util.Arrays.copyOf(this, size)");
      return new ByteString(var10002);
   }

   @NotNull
   public static final ByteString commonToByteString(@NotNull byte[] $this$commonToByteString, int offset, int byteCount) {
      int $i$f$commonToByteString = 0;
      Intrinsics.checkNotNullParameter($this$commonToByteString, "$this$commonToByteString");
      -Util.checkOffsetAndCount((long)$this$commonToByteString.length, (long)offset, (long)byteCount);
      int var5 = offset + byteCount;
      boolean var6 = false;
      return new ByteString(ArraysKt.copyOfRange($this$commonToByteString, offset, var5));
   }

   @NotNull
   public static final ByteString commonEncodeUtf8(@NotNull String $this$commonEncodeUtf8) {
      int $i$f$commonEncodeUtf8 = 0;
      Intrinsics.checkNotNullParameter($this$commonEncodeUtf8, "$this$commonEncodeUtf8");
      ByteString byteString = new ByteString(-Platform.asUtf8ToByteArray($this$commonEncodeUtf8));
      byteString.setUtf8$okio($this$commonEncodeUtf8);
      return byteString;
   }

   @Nullable
   public static final ByteString commonDecodeBase64(@NotNull String $this$commonDecodeBase64) {
      int $i$f$commonDecodeBase64 = 0;
      Intrinsics.checkNotNullParameter($this$commonDecodeBase64, "$this$commonDecodeBase64");
      byte[] decoded = -Base64.decodeBase64ToArray($this$commonDecodeBase64);
      return decoded != null ? new ByteString(decoded) : null;
   }

   @NotNull
   public static final ByteString commonDecodeHex(@NotNull String $this$commonDecodeHex) {
      int $i$f$commonDecodeHex = 0;
      Intrinsics.checkNotNullParameter($this$commonDecodeHex, "$this$commonDecodeHex");
      boolean var2 = $this$commonDecodeHex.length() % 2 == 0;
      boolean var3 = false;
      boolean var4 = false;
      if (!var2) {
         int var11 = false;
         String var10 = "Unexpected hex string: " + $this$commonDecodeHex;
         throw (Throwable)(new IllegalArgumentException(var10.toString()));
      } else {
         byte[] result = new byte[$this$commonDecodeHex.length() / 2];
         int i = 0;

         for(int var9 = result.length; i < var9; ++i) {
            int d1 = access$decodeHexDigit($this$commonDecodeHex.charAt(i * 2)) << 4;
            int d2 = access$decodeHexDigit($this$commonDecodeHex.charAt(i * 2 + 1));
            result[i] = (byte)(d1 + d2);
         }

         return new ByteString(result);
      }
   }

   public static final void commonWrite(@NotNull ByteString $this$commonWrite, @NotNull Buffer buffer, int offset, int byteCount) {
      Intrinsics.checkNotNullParameter($this$commonWrite, "$this$commonWrite");
      Intrinsics.checkNotNullParameter(buffer, "buffer");
      buffer.write($this$commonWrite.getData$okio(), offset, byteCount);
   }

   private static final int decodeHexDigit(char c) {
      int var10000;
      if ('0' <= c) {
         if ('9' >= c) {
            var10000 = c - 48;
            return var10000;
         }
      }

      if ('a' <= c) {
         if ('f' >= c) {
            var10000 = c - 97 + 10;
            return var10000;
         }
      }

      if ('A' > c) {
         throw (Throwable)(new IllegalArgumentException("Unexpected hex digit: " + c));
      } else if ('F' < c) {
         throw (Throwable)(new IllegalArgumentException("Unexpected hex digit: " + c));
      } else {
         var10000 = c - 65 + 10;
         return var10000;
      }
   }

   @NotNull
   public static final String commonToString(@NotNull ByteString $this$commonToString) {
      int $i$f$commonToString = 0;
      Intrinsics.checkNotNullParameter($this$commonToString, "$this$commonToString");
      byte[] var2 = $this$commonToString.getData$okio();
      boolean var3 = false;
      if (var2.length == 0) {
         return "[size=0]";
      } else {
         int i = access$codePointIndexToCharIndex($this$commonToString.getData$okio(), 64);
         boolean var7;
         String var10000;
         if (i == -1) {
            if ($this$commonToString.getData$okio().length <= 64) {
               var10000 = "[hex=" + $this$commonToString.hex() + ']';
            } else {
               StringBuilder var20 = (new StringBuilder()).append("[size=").append($this$commonToString.getData$okio().length).append(" hex=");
               byte beginIndex$iv = 0;
               int endIndex$iv = 64;
               int $i$f$commonSubstring = false;
               var7 = true;
               boolean var8 = false;
               boolean var9 = false;
               var7 = endIndex$iv <= $this$commonToString.getData$okio().length;
               var8 = false;
               var9 = false;
               boolean var10;
               if (!var7) {
                  var10 = false;
                  String var18 = "endIndex > length(" + $this$commonToString.getData$okio().length + ')';
                  throw (Throwable)(new IllegalArgumentException(var18.toString()));
               }

               int subLen$iv = endIndex$iv - beginIndex$iv;
               var8 = subLen$iv >= 0;
               var9 = false;
               var10 = false;
               if (!var8) {
                  int var11 = false;
                  String var19 = "endIndex < beginIndex";
                  throw (Throwable)(new IllegalArgumentException(var19.toString()));
               }

               ByteString var10001;
               if (endIndex$iv == $this$commonToString.getData$okio().length) {
                  var10001 = $this$commonToString;
               } else {
                  byte[] var17 = $this$commonToString.getData$okio();
                  var9 = false;
                  var10001 = new ByteString(ArraysKt.copyOfRange(var17, beginIndex$iv, endIndex$iv));
               }

               var10000 = var20.append(var10001.hex()).append("…]").toString();
            }

            return var10000;
         } else {
            String text = $this$commonToString.utf8();
            byte var6 = 0;
            var7 = false;
            if (text == null) {
               throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            } else {
               var10000 = text.substring(var6, i);
               Intrinsics.checkNotNullExpressionValue(var10000, "(this as java.lang.Strin…ing(startIndex, endIndex)");
               String safeText = StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(var10000, "\\", "\\\\", false, 4, (Object)null), "\n", "\\n", false, 4, (Object)null), "\r", "\\r", false, 4, (Object)null);
               return i < text.length() ? "[size=" + $this$commonToString.getData$okio().length + " text=" + safeText + "…]" : "[text=" + safeText + ']';
            }
         }
      }
   }

   private static final int codePointIndexToCharIndex(byte[] s, int codePointCount) {
      int charCount = 0;
      int j = 0;
      byte[] $this$processUtf8CodePoints$iv = s;
      byte beginIndex$iv = 0;
      int endIndex$iv = s.length;
      int $i$f$processUtf8CodePoints = false;
      int index$iv = beginIndex$iv;

      label1044:
      while(index$iv < endIndex$iv) {
         byte b0$iv = $this$processUtf8CodePoints$iv[index$iv];
         boolean var11;
         int var12;
         boolean var10000;
         boolean $i$f$isIsoControl;
         if (b0$iv >= 0) {
            var11 = false;
            var12 = j++;
            if (var12 == codePointCount) {
               return charCount;
            }

            if (b0$iv != 10 && b0$iv != 13) {
               label606: {
                  label605: {
                     label1048: {
                        $i$f$isIsoControl = false;
                        if (0 <= b0$iv) {
                           if (31 >= b0$iv) {
                              break label1048;
                           }
                        }

                        if (127 > b0$iv) {
                           break label605;
                        }

                        if (159 < b0$iv) {
                           break label605;
                        }
                     }

                     var10000 = true;
                     break label606;
                  }

                  var10000 = false;
               }

               if (var10000) {
                  return -1;
               }
            }

            if (b0$iv != '�') {
               charCount += b0$iv < 65536 ? 1 : 2;
               ++index$iv;

               while(true) {
                  if (index$iv >= endIndex$iv || $this$processUtf8CodePoints$iv[index$iv] < 0) {
                     continue label1044;
                  }

                  int c = $this$processUtf8CodePoints$iv[index$iv++];
                  var11 = false;
                  var12 = j++;
                  if (var12 == codePointCount) {
                     return charCount;
                  }

                  if (c != 10 && c != 13) {
                     label584: {
                        label1051: {
                           $i$f$isIsoControl = false;
                           if (0 <= c) {
                              if (31 >= c) {
                                 break label1051;
                              }
                           }

                           if (127 <= c) {
                              if (159 >= c) {
                                 break label1051;
                              }
                           }

                           var10000 = false;
                           break label584;
                        }

                        var10000 = true;
                     }

                     if (var10000) {
                        break;
                     }
                  }

                  if (c == '�') {
                     break;
                  }

                  charCount += c < 65536 ? 1 : 2;
               }

               return -1;
            }

            return -1;
         } else {
            int other$iv$iv = 5;
            int $i$f$shr = false;
            byte var10001;
            boolean var18;
            Unit var19;
            byte byte$iv$iv$iv;
            byte b1$iv$iv;
            boolean $i$f$isUtf8Continuation;
            short other$iv$iv$iv$iv;
            boolean $i$f$and;
            boolean $i$f$process4Utf8Bytes;
            char it$iv;
            int var42;
            if (b0$iv >> other$iv$iv == -2) {
               $i$f$process4Utf8Bytes = false;
               if (endIndex$iv <= index$iv + 1) {
                  it$iv = '�';
                  var18 = false;
                  var11 = false;
                  var12 = j++;
                  if (var12 == codePointCount) {
                     return charCount;
                  }

                  if (it$iv != '\n' && it$iv != '\r') {
                     label648: {
                        label1054: {
                           $i$f$isIsoControl = false;
                           if (0 <= it$iv) {
                              if (31 >= it$iv) {
                                 break label1054;
                              }
                           }

                           if (127 <= it$iv) {
                              if (159 >= it$iv) {
                                 break label1054;
                              }
                           }

                           var10000 = false;
                           break label648;
                        }

                        var10000 = true;
                     }

                     if (var10000) {
                        return -1;
                     }
                  }

                  if (it$iv == '�') {
                     return -1;
                  }

                  charCount += it$iv < 65536 ? 1 : 2;
                  var19 = Unit.INSTANCE;
                  var42 = index$iv;
                  var10001 = 1;
               } else {
                  byte$iv$iv$iv = $this$processUtf8CodePoints$iv[index$iv];
                  b1$iv$iv = $this$processUtf8CodePoints$iv[index$iv + 1];
                  $i$f$isUtf8Continuation = false;
                  other$iv$iv$iv$iv = 192;
                  $i$f$and = false;
                  if ((b1$iv$iv & other$iv$iv$iv$iv) != 128) {
                     it$iv = '�';
                     var18 = false;
                     var11 = false;
                     var12 = j++;
                     if (var12 == codePointCount) {
                        return charCount;
                     }

                     if (it$iv != '\n' && it$iv != '\r') {
                        label665: {
                           label1056: {
                              $i$f$isIsoControl = false;
                              if (0 <= it$iv) {
                                 if (31 >= it$iv) {
                                    break label1056;
                                 }
                              }

                              if (127 <= it$iv) {
                                 if (159 >= it$iv) {
                                    break label1056;
                                 }
                              }

                              var10000 = false;
                              break label665;
                           }

                           var10000 = true;
                        }

                        if (var10000) {
                           return -1;
                        }
                     }

                     if (it$iv == '�') {
                        return -1;
                     }

                     charCount += it$iv < 65536 ? 1 : 2;
                     var19 = Unit.INSTANCE;
                     var42 = index$iv;
                     var10001 = 1;
                  } else {
                     int codePoint$iv$iv = 3968 ^ b1$iv$iv ^ byte$iv$iv$iv << 6;
                     if (codePoint$iv$iv < 128) {
                        it$iv = '�';
                        var18 = false;
                        var11 = false;
                        var12 = j++;
                        if (var12 == codePointCount) {
                           return charCount;
                        }

                        if (it$iv != '\n' && it$iv != '\r') {
                           label687: {
                              label1059: {
                                 $i$f$isIsoControl = false;
                                 if (0 <= it$iv) {
                                    if (31 >= it$iv) {
                                       break label1059;
                                    }
                                 }

                                 if (127 <= it$iv) {
                                    if (159 >= it$iv) {
                                       break label1059;
                                    }
                                 }

                                 var10000 = false;
                                 break label687;
                              }

                              var10000 = true;
                           }

                           if (var10000) {
                              return -1;
                           }
                        }

                        if (it$iv == '�') {
                           return -1;
                        }

                        charCount += it$iv < 65536 ? 1 : 2;
                        var19 = Unit.INSTANCE;
                        var42 = index$iv;
                     } else {
                        var18 = false;
                        var11 = false;
                        var12 = j++;
                        if (var12 == codePointCount) {
                           return charCount;
                        }

                        if (codePoint$iv$iv != 10 && codePoint$iv$iv != 13) {
                           label629: {
                              label1060: {
                                 $i$f$isIsoControl = false;
                                 if (0 <= codePoint$iv$iv) {
                                    if (31 >= codePoint$iv$iv) {
                                       break label1060;
                                    }
                                 }

                                 if (127 <= codePoint$iv$iv) {
                                    if (159 >= codePoint$iv$iv) {
                                       break label1060;
                                    }
                                 }

                                 var10000 = false;
                                 break label629;
                              }

                              var10000 = true;
                           }

                           if (var10000) {
                              return -1;
                           }
                        }

                        if (codePoint$iv$iv == 65533) {
                           return -1;
                        }

                        charCount += codePoint$iv$iv < 65536 ? 1 : 2;
                        var19 = Unit.INSTANCE;
                        var42 = index$iv;
                     }

                     var10001 = 2;
                  }
               }

               index$iv = var42 + var10001;
            } else {
               other$iv$iv = 4;
               $i$f$shr = false;
               boolean $i$f$isUtf8Continuation;
               boolean $i$f$and;
               boolean $i$f$isUtf8Continuation;
               byte b2$iv$iv;
               short other$iv$iv$iv$iv;
               boolean $i$f$and;
               short other$iv$iv$iv$iv;
               if (b0$iv >> other$iv$iv == -2) {
                  $i$f$process4Utf8Bytes = false;
                  if (endIndex$iv <= index$iv + 2) {
                     label1242: {
                        it$iv = '�';
                        var18 = false;
                        var11 = false;
                        var12 = j++;
                        if (var12 == codePointCount) {
                           return charCount;
                        }

                        if (it$iv != '\n' && it$iv != '\r') {
                           label746: {
                              label1063: {
                                 $i$f$isIsoControl = false;
                                 if (0 <= it$iv) {
                                    if (31 >= it$iv) {
                                       break label1063;
                                    }
                                 }

                                 if (127 <= it$iv) {
                                    if (159 >= it$iv) {
                                       break label1063;
                                    }
                                 }

                                 var10000 = false;
                                 break label746;
                              }

                              var10000 = true;
                           }

                           if (var10000) {
                              return -1;
                           }
                        }

                        if (it$iv == '�') {
                           return -1;
                        }

                        charCount += it$iv < 65536 ? 1 : 2;
                        var19 = Unit.INSTANCE;
                        var42 = index$iv;
                        if (endIndex$iv > index$iv + 1) {
                           byte$iv$iv$iv = $this$processUtf8CodePoints$iv[index$iv + 1];
                           $i$f$isUtf8Continuation = false;
                           other$iv$iv$iv$iv = 192;
                           $i$f$and = false;
                           if ((byte$iv$iv$iv & other$iv$iv$iv$iv) == 128) {
                              var10001 = 2;
                              break label1242;
                           }
                        }

                        var10001 = 1;
                     }
                  } else {
                     byte$iv$iv$iv = $this$processUtf8CodePoints$iv[index$iv];
                     b1$iv$iv = $this$processUtf8CodePoints$iv[index$iv + 1];
                     $i$f$isUtf8Continuation = false;
                     other$iv$iv$iv$iv = 192;
                     $i$f$and = false;
                     if ((b1$iv$iv & other$iv$iv$iv$iv) != 128) {
                        it$iv = '�';
                        var18 = false;
                        var11 = false;
                        var12 = j++;
                        if (var12 == codePointCount) {
                           return charCount;
                        }

                        if (it$iv != '\n' && it$iv != '\r') {
                           label763: {
                              label1066: {
                                 $i$f$isIsoControl = false;
                                 if (0 <= it$iv) {
                                    if (31 >= it$iv) {
                                       break label1066;
                                    }
                                 }

                                 if (127 <= it$iv) {
                                    if (159 >= it$iv) {
                                       break label1066;
                                    }
                                 }

                                 var10000 = false;
                                 break label763;
                              }

                              var10000 = true;
                           }

                           if (var10000) {
                              return -1;
                           }
                        }

                        if (it$iv == '�') {
                           return -1;
                        }

                        charCount += it$iv < 65536 ? 1 : 2;
                        var19 = Unit.INSTANCE;
                        var42 = index$iv;
                        var10001 = 1;
                     } else {
                        b2$iv$iv = $this$processUtf8CodePoints$iv[index$iv + 2];
                        $i$f$isUtf8Continuation = false;
                        other$iv$iv$iv$iv = 192;
                        $i$f$and = false;
                        if ((b2$iv$iv & other$iv$iv$iv$iv) != 128) {
                           it$iv = '�';
                           var18 = false;
                           var11 = false;
                           var12 = j++;
                           if (var12 == codePointCount) {
                              return charCount;
                           }

                           if (it$iv != '\n' && it$iv != '\r') {
                              label780: {
                                 label1068: {
                                    $i$f$isIsoControl = false;
                                    if (0 <= it$iv) {
                                       if (31 >= it$iv) {
                                          break label1068;
                                       }
                                    }

                                    if (127 <= it$iv) {
                                       if (159 >= it$iv) {
                                          break label1068;
                                       }
                                    }

                                    var10000 = false;
                                    break label780;
                                 }

                                 var10000 = true;
                              }

                              if (var10000) {
                                 return -1;
                              }
                           }

                           if (it$iv == '�') {
                              return -1;
                           }

                           charCount += it$iv < 65536 ? 1 : 2;
                           var19 = Unit.INSTANCE;
                           var42 = index$iv;
                           var10001 = 2;
                        } else {
                           int codePoint$iv$iv = -123008 ^ b2$iv$iv ^ b1$iv$iv << 6 ^ byte$iv$iv$iv << 12;
                           if (codePoint$iv$iv < 2048) {
                              it$iv = '�';
                              var18 = false;
                              var11 = false;
                              var12 = j++;
                              if (var12 == codePointCount) {
                                 return charCount;
                              }

                              if (it$iv != '\n' && it$iv != '\r') {
                                 label726: {
                                    label725: {
                                       label1071: {
                                          $i$f$isIsoControl = false;
                                          if (0 <= it$iv) {
                                             if (31 >= it$iv) {
                                                break label1071;
                                             }
                                          }

                                          if (127 > it$iv) {
                                             break label725;
                                          }

                                          if (159 < it$iv) {
                                             break label725;
                                          }
                                       }

                                       var10000 = true;
                                       break label726;
                                    }

                                    var10000 = false;
                                 }

                                 if (var10000) {
                                    return -1;
                                 }
                              }

                              if (it$iv == '�') {
                                 return -1;
                              }

                              charCount += it$iv < 65536 ? 1 : 2;
                              var19 = Unit.INSTANCE;
                              var42 = index$iv;
                           } else {
                              label1232: {
                                 if (55296 <= codePoint$iv$iv) {
                                    if (57343 >= codePoint$iv$iv) {
                                       it$iv = '�';
                                       var18 = false;
                                       var11 = false;
                                       var12 = j++;
                                       if (var12 == codePointCount) {
                                          return charCount;
                                       }

                                       if (it$iv != '\n' && it$iv != '\r') {
                                          label804: {
                                             label1073: {
                                                $i$f$isIsoControl = false;
                                                if (0 <= it$iv) {
                                                   if (31 >= it$iv) {
                                                      break label1073;
                                                   }
                                                }

                                                if (127 <= it$iv) {
                                                   if (159 >= it$iv) {
                                                      break label1073;
                                                   }
                                                }

                                                var10000 = false;
                                                break label804;
                                             }

                                             var10000 = true;
                                          }

                                          if (var10000) {
                                             return -1;
                                          }
                                       }

                                       if (it$iv != '�') {
                                          charCount += it$iv < 65536 ? 1 : 2;
                                          var19 = Unit.INSTANCE;
                                          var42 = index$iv;
                                          break label1232;
                                       }

                                       return -1;
                                    }
                                 }

                                 var18 = false;
                                 var11 = false;
                                 var12 = j++;
                                 if (var12 == codePointCount) {
                                    return charCount;
                                 }

                                 if (codePoint$iv$iv != 10 && codePoint$iv$iv != 13) {
                                    label825: {
                                       label1074: {
                                          $i$f$isIsoControl = false;
                                          if (0 <= codePoint$iv$iv) {
                                             if (31 >= codePoint$iv$iv) {
                                                break label1074;
                                             }
                                          }

                                          if (127 <= codePoint$iv$iv) {
                                             if (159 >= codePoint$iv$iv) {
                                                break label1074;
                                             }
                                          }

                                          var10000 = false;
                                          break label825;
                                       }

                                       var10000 = true;
                                    }

                                    if (var10000) {
                                       return -1;
                                    }
                                 }

                                 if (codePoint$iv$iv == 65533) {
                                    return -1;
                                 }

                                 charCount += codePoint$iv$iv < 65536 ? 1 : 2;
                                 var19 = Unit.INSTANCE;
                                 var42 = index$iv;
                              }
                           }

                           var10001 = 3;
                        }
                     }
                  }

                  index$iv = var42 + var10001;
               } else {
                  other$iv$iv = 3;
                  $i$f$shr = false;
                  if (b0$iv >> other$iv$iv == -2) {
                     $i$f$process4Utf8Bytes = false;
                     if (endIndex$iv <= index$iv + 3) {
                        label1243: {
                           it$iv = '�';
                           var18 = false;
                           var11 = false;
                           var12 = j++;
                           if (var12 == codePointCount) {
                              return charCount;
                           }

                           if (it$iv != '\n' && it$iv != '\r') {
                              label888: {
                                 label1077: {
                                    $i$f$isIsoControl = false;
                                    if (0 <= it$iv) {
                                       if (31 >= it$iv) {
                                          break label1077;
                                       }
                                    }

                                    if (127 <= it$iv) {
                                       if (159 >= it$iv) {
                                          break label1077;
                                       }
                                    }

                                    var10000 = false;
                                    break label888;
                                 }

                                 var10000 = true;
                              }

                              if (var10000) {
                                 return -1;
                              }
                           }

                           if (it$iv == '�') {
                              return -1;
                           }

                           charCount += it$iv < 65536 ? 1 : 2;
                           var19 = Unit.INSTANCE;
                           var42 = index$iv;
                           if (endIndex$iv > index$iv + 1) {
                              byte$iv$iv$iv = $this$processUtf8CodePoints$iv[index$iv + 1];
                              $i$f$isUtf8Continuation = false;
                              other$iv$iv$iv$iv = 192;
                              $i$f$and = false;
                              if ((byte$iv$iv$iv & other$iv$iv$iv$iv) == 128) {
                                 if (endIndex$iv > index$iv + 2) {
                                    byte$iv$iv$iv = $this$processUtf8CodePoints$iv[index$iv + 2];
                                    $i$f$isUtf8Continuation = false;
                                    other$iv$iv$iv$iv = 192;
                                    $i$f$and = false;
                                    if ((byte$iv$iv$iv & other$iv$iv$iv$iv) == 128) {
                                       var10001 = 3;
                                       break label1243;
                                    }
                                 }

                                 var10001 = 2;
                                 break label1243;
                              }
                           }

                           var10001 = 1;
                        }
                     } else {
                        byte$iv$iv$iv = $this$processUtf8CodePoints$iv[index$iv];
                        b1$iv$iv = $this$processUtf8CodePoints$iv[index$iv + 1];
                        $i$f$isUtf8Continuation = false;
                        other$iv$iv$iv$iv = 192;
                        $i$f$and = false;
                        if ((b1$iv$iv & other$iv$iv$iv$iv) != 128) {
                           it$iv = '�';
                           var18 = false;
                           var11 = false;
                           var12 = j++;
                           if (var12 == codePointCount) {
                              return charCount;
                           }

                           if (it$iv != '\n' && it$iv != '\r') {
                              label905: {
                                 label1080: {
                                    $i$f$isIsoControl = false;
                                    if (0 <= it$iv) {
                                       if (31 >= it$iv) {
                                          break label1080;
                                       }
                                    }

                                    if (127 <= it$iv) {
                                       if (159 >= it$iv) {
                                          break label1080;
                                       }
                                    }

                                    var10000 = false;
                                    break label905;
                                 }

                                 var10000 = true;
                              }

                              if (var10000) {
                                 return -1;
                              }
                           }

                           if (it$iv == '�') {
                              return -1;
                           }

                           charCount += it$iv < 65536 ? 1 : 2;
                           var19 = Unit.INSTANCE;
                           var42 = index$iv;
                           var10001 = 1;
                        } else {
                           b2$iv$iv = $this$processUtf8CodePoints$iv[index$iv + 2];
                           $i$f$isUtf8Continuation = false;
                           other$iv$iv$iv$iv = 192;
                           $i$f$and = false;
                           if ((b2$iv$iv & other$iv$iv$iv$iv) != 128) {
                              it$iv = '�';
                              var18 = false;
                              var11 = false;
                              var12 = j++;
                              if (var12 == codePointCount) {
                                 return charCount;
                              }

                              if (it$iv != '\n' && it$iv != '\r') {
                                 label868: {
                                    label1082: {
                                       $i$f$isIsoControl = false;
                                       if (0 <= it$iv) {
                                          if (31 >= it$iv) {
                                             break label1082;
                                          }
                                       }

                                       if (127 <= it$iv) {
                                          if (159 >= it$iv) {
                                             break label1082;
                                          }
                                       }

                                       var10000 = false;
                                       break label868;
                                    }

                                    var10000 = true;
                                 }

                                 if (var10000) {
                                    return -1;
                                 }
                              }

                              if (it$iv == '�') {
                                 return -1;
                              }

                              charCount += it$iv < 65536 ? 1 : 2;
                              var19 = Unit.INSTANCE;
                              var42 = index$iv;
                              var10001 = 2;
                           } else {
                              byte b3$iv$iv = $this$processUtf8CodePoints$iv[index$iv + 3];
                              $i$f$and = false;
                              int other$iv$iv$iv$iv = 192;
                              int $i$f$and = false;
                              if ((b3$iv$iv & other$iv$iv$iv$iv) != 128) {
                                 it$iv = '�';
                                 var18 = false;
                                 var11 = false;
                                 var12 = j++;
                                 if (var12 == codePointCount) {
                                    return charCount;
                                 }

                                 if (it$iv != '\n' && it$iv != '\r') {
                                    label922: {
                                       label1084: {
                                          $i$f$isIsoControl = false;
                                          if (0 <= it$iv) {
                                             if (31 >= it$iv) {
                                                break label1084;
                                             }
                                          }

                                          if (127 <= it$iv) {
                                             if (159 >= it$iv) {
                                                break label1084;
                                             }
                                          }

                                          var10000 = false;
                                          break label922;
                                       }

                                       var10000 = true;
                                    }

                                    if (var10000) {
                                       return -1;
                                    }
                                 }

                                 if (it$iv == '�') {
                                    return -1;
                                 }

                                 charCount += it$iv < 65536 ? 1 : 2;
                                 var19 = Unit.INSTANCE;
                                 var42 = index$iv;
                                 var10001 = 3;
                              } else {
                                 int codePoint$iv$iv = 3678080 ^ b3$iv$iv ^ b2$iv$iv << 6 ^ b1$iv$iv << 12 ^ byte$iv$iv$iv << 18;
                                 if (codePoint$iv$iv > 1114111) {
                                    it$iv = '�';
                                    var18 = false;
                                    var11 = false;
                                    var12 = j++;
                                    if (var12 == codePointCount) {
                                       return charCount;
                                    }

                                    if (it$iv != '\n' && it$iv != '\r') {
                                       label947: {
                                          label1087: {
                                             $i$f$isIsoControl = false;
                                             if (0 <= it$iv) {
                                                if (31 >= it$iv) {
                                                   break label1087;
                                                }
                                             }

                                             if (127 <= it$iv) {
                                                if (159 >= it$iv) {
                                                   break label1087;
                                                }
                                             }

                                             var10000 = false;
                                             break label947;
                                          }

                                          var10000 = true;
                                       }

                                       if (var10000) {
                                          return -1;
                                       }
                                    }

                                    if (it$iv == '�') {
                                       return -1;
                                    }

                                    charCount += it$iv < 65536 ? 1 : 2;
                                    var19 = Unit.INSTANCE;
                                    var42 = index$iv;
                                 } else {
                                    label1160: {
                                       if (55296 <= codePoint$iv$iv) {
                                          if (57343 >= codePoint$iv$iv) {
                                             it$iv = '�';
                                             var18 = false;
                                             var11 = false;
                                             var12 = j++;
                                             if (var12 == codePointCount) {
                                                return charCount;
                                             }

                                             if (it$iv != '\n' && it$iv != '\r') {
                                                label965: {
                                                   label1089: {
                                                      $i$f$isIsoControl = false;
                                                      if (0 <= it$iv) {
                                                         if (31 >= it$iv) {
                                                            break label1089;
                                                         }
                                                      }

                                                      if (127 <= it$iv) {
                                                         if (159 >= it$iv) {
                                                            break label1089;
                                                         }
                                                      }

                                                      var10000 = false;
                                                      break label965;
                                                   }

                                                   var10000 = true;
                                                }

                                                if (var10000) {
                                                   return -1;
                                                }
                                             }

                                             if (it$iv != '�') {
                                                charCount += it$iv < 65536 ? 1 : 2;
                                                var19 = Unit.INSTANCE;
                                                var42 = index$iv;
                                                break label1160;
                                             }

                                             return -1;
                                          }
                                       }

                                       if (codePoint$iv$iv < 65536) {
                                          it$iv = '�';
                                          var18 = false;
                                          var11 = false;
                                          var12 = j++;
                                          if (var12 == codePointCount) {
                                             return charCount;
                                          }

                                          if (it$iv != '\n' && it$iv != '\r') {
                                             label985: {
                                                label1091: {
                                                   $i$f$isIsoControl = false;
                                                   if (0 <= it$iv) {
                                                      if (31 >= it$iv) {
                                                         break label1091;
                                                      }
                                                   }

                                                   if (127 <= it$iv) {
                                                      if (159 >= it$iv) {
                                                         break label1091;
                                                      }
                                                   }

                                                   var10000 = false;
                                                   break label985;
                                                }

                                                var10000 = true;
                                             }

                                             if (var10000) {
                                                return -1;
                                             }
                                          }

                                          if (it$iv == '�') {
                                             return -1;
                                          }

                                          charCount += it$iv < 65536 ? 1 : 2;
                                          var19 = Unit.INSTANCE;
                                          var42 = index$iv;
                                       } else {
                                          var18 = false;
                                          var11 = false;
                                          var12 = j++;
                                          if (var12 == codePointCount) {
                                             return charCount;
                                          }

                                          if (codePoint$iv$iv != 10 && codePoint$iv$iv != 13) {
                                             label1002: {
                                                label1092: {
                                                   $i$f$isIsoControl = false;
                                                   if (0 <= codePoint$iv$iv) {
                                                      if (31 >= codePoint$iv$iv) {
                                                         break label1092;
                                                      }
                                                   }

                                                   if (127 <= codePoint$iv$iv) {
                                                      if (159 >= codePoint$iv$iv) {
                                                         break label1092;
                                                      }
                                                   }

                                                   var10000 = false;
                                                   break label1002;
                                                }

                                                var10000 = true;
                                             }

                                             if (var10000) {
                                                return -1;
                                             }
                                          }

                                          if (codePoint$iv$iv == 65533) {
                                             return -1;
                                          }

                                          charCount += codePoint$iv$iv < 65536 ? 1 : 2;
                                          var19 = Unit.INSTANCE;
                                          var42 = index$iv;
                                       }
                                    }
                                 }

                                 var10001 = 4;
                              }
                           }
                        }
                     }

                     index$iv = var42 + var10001;
                  } else {
                     int c = '�';
                     var11 = false;
                     var12 = j++;
                     if (var12 == codePointCount) {
                        return charCount;
                     }

                     if (c != '\n' && c != '\r') {
                        label1034: {
                           label1093: {
                              $i$f$isIsoControl = false;
                              if (0 <= c) {
                                 if (31 >= c) {
                                    break label1093;
                                 }
                              }

                              if (127 <= c) {
                                 if (159 >= c) {
                                    break label1093;
                                 }
                              }

                              var10000 = false;
                              break label1034;
                           }

                           var10000 = true;
                        }

                        if (var10000) {
                           return -1;
                        }
                     }

                     if (c == '�') {
                        return -1;
                     }

                     charCount += c < 65536 ? 1 : 2;
                     ++index$iv;
                  }
               }
            }
         }
      }

      return charCount;
   }

   // $FF: synthetic method
   public static final int access$decodeHexDigit(char c) {
      return decodeHexDigit(c);
   }

   // $FF: synthetic method
   public static final int access$codePointIndexToCharIndex(byte[] s, int codePointCount) {
      return codePointIndexToCharIndex(s, codePointCount);
   }
}
