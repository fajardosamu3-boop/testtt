package i;

import i.internal.BufferKt;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import k.Metadata;
import k.jvm.JvmField;
import k.jvm.internal.Intrinsics;
import k.text.CharsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000\u0086\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0005\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\n\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u0005\u001a\u00020\u0006H\u0016J\b\u0010\u000e\u001a\u00020\u000fH\u0016J\b\u0010\u0010\u001a\u00020\rH\u0016J\u0010\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014H\u0016J\u0018\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0012H\u0016J \u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00122\u0006\u0010\u0016\u001a\u00020\u0012H\u0016J\u0010\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020\u0018H\u0016J\u0018\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0012H\u0016J\u0010\u0010\u0019\u001a\u00020\u00122\u0006\u0010\u001a\u001a\u00020\u0018H\u0016J\u0018\u0010\u0019\u001a\u00020\u00122\u0006\u0010\u001a\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0012H\u0016J\b\u0010\u001b\u001a\u00020\u001cH\u0016J\b\u0010\u001d\u001a\u00020\rH\u0016J\b\u0010\u001e\u001a\u00020\u0001H\u0016J\u0018\u0010\u001f\u001a\u00020\r2\u0006\u0010 \u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020\u0018H\u0016J(\u0010\u001f\u001a\u00020\r2\u0006\u0010 \u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020\"H\u0016J\u0010\u0010$\u001a\u00020\"2\u0006\u0010%\u001a\u00020&H\u0016J\u0010\u0010$\u001a\u00020\"2\u0006\u0010%\u001a\u00020'H\u0016J \u0010$\u001a\u00020\"2\u0006\u0010%\u001a\u00020'2\u0006\u0010 \u001a\u00020\"2\u0006\u0010#\u001a\u00020\"H\u0016J\u0018\u0010$\u001a\u00020\u00122\u0006\u0010%\u001a\u00020\u00062\u0006\u0010#\u001a\u00020\u0012H\u0016J\u0010\u0010(\u001a\u00020\u00122\u0006\u0010%\u001a\u00020)H\u0016J\b\u0010*\u001a\u00020\u0014H\u0016J\b\u0010+\u001a\u00020'H\u0016J\u0010\u0010+\u001a\u00020'2\u0006\u0010#\u001a\u00020\u0012H\u0016J\b\u0010,\u001a\u00020\u0018H\u0016J\u0010\u0010,\u001a\u00020\u00182\u0006\u0010#\u001a\u00020\u0012H\u0016J\b\u0010-\u001a\u00020\u0012H\u0016J\u0010\u0010.\u001a\u00020\u000f2\u0006\u0010%\u001a\u00020'H\u0016J\u0018\u0010.\u001a\u00020\u000f2\u0006\u0010%\u001a\u00020\u00062\u0006\u0010#\u001a\u00020\u0012H\u0016J\b\u0010/\u001a\u00020\u0012H\u0016J\b\u00100\u001a\u00020\"H\u0016J\b\u00101\u001a\u00020\"H\u0016J\b\u00102\u001a\u00020\u0012H\u0016J\b\u00103\u001a\u00020\u0012H\u0016J\b\u00104\u001a\u000205H\u0016J\b\u00106\u001a\u000205H\u0016J\u0010\u00107\u001a\u0002082\u0006\u00109\u001a\u00020:H\u0016J\u0018\u00107\u001a\u0002082\u0006\u0010#\u001a\u00020\u00122\u0006\u00109\u001a\u00020:H\u0016J\b\u0010;\u001a\u000208H\u0016J\u0010\u0010;\u001a\u0002082\u0006\u0010#\u001a\u00020\u0012H\u0016J\b\u0010<\u001a\u00020\"H\u0016J\n\u0010=\u001a\u0004\u0018\u000108H\u0016J\b\u0010>\u001a\u000208H\u0016J\u0010\u0010>\u001a\u0002082\u0006\u0010?\u001a\u00020\u0012H\u0016J\u0010\u0010@\u001a\u00020\r2\u0006\u0010#\u001a\u00020\u0012H\u0016J\u0010\u0010A\u001a\u00020\u000f2\u0006\u0010#\u001a\u00020\u0012H\u0016J\u0010\u0010B\u001a\u00020\"2\u0006\u0010C\u001a\u00020DH\u0016J\u0010\u0010E\u001a\u00020\u000f2\u0006\u0010#\u001a\u00020\u0012H\u0016J\b\u0010F\u001a\u00020GH\u0016J\b\u0010H\u001a\u000208H\u0016R\u001b\u0010\u0005\u001a\u00020\u00068Ö\u0002X\u0096\u0004¢\u0006\f\u0012\u0004\b\u0007\u0010\b\u001a\u0004\b\t\u0010\nR\u0010\u0010\u000b\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\f\u001a\u00020\r8\u0006@\u0006X\u0087\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006I"},
   d2 = {"Li/RealBufferedSource;", "Li/BufferedSource;", "source", "Li/Source;", "(Lokio/Source;)V", "buffer", "Li/Buffer;", "getBuffer$annotations", "()V", "getBuffer", "()Lokio/Buffer;", "bufferField", "closed", "", "close", "", "exhausted", "indexOf", "", "b", "", "fromIndex", "toIndex", "bytes", "Li/ByteString;", "indexOfElement", "targetBytes", "inputStream", "Ljava/io/InputStream;", "isOpen", "peek", "rangeEquals", "offset", "bytesOffset", "", "byteCount", "read", "sink", "Ljava/nio/ByteBuffer;", "", "readAll", "Li/Sink;", "readByte", "readByteArray", "readByteString", "readDecimalLong", "readFully", "readHexadecimalUnsignedLong", "readInt", "readIntLe", "readLong", "readLongLe", "readShort", "", "readShortLe", "readString", "", "charset", "Ljava/nio/charset/Charset;", "readUtf8", "readUtf8CodePoint", "readUtf8Line", "readUtf8LineStrict", "limit", "request", "require", "select", "options", "Li/Options;", "skip", "timeout", "Li/Timeout;", "toString", "i"}
)
public final class RealBufferedSource implements BufferedSource {
   @JvmField
   @NotNull
   public final Buffer bufferField;
   @JvmField
   public boolean closed;
   @JvmField
   @NotNull
   public final Source source;

   /** @deprecated */
   // $FF: synthetic method
   public static void getBuffer$annotations() {
   }

   @NotNull
   public Buffer getBuffer() {
      int $i$f$getBuffer = 0;
      return this.bufferField;
   }

   @NotNull
   public Buffer buffer() {
      return this.bufferField;
   }

   public long read(@NotNull Buffer sink, long byteCount) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      int $i$f$commonRead = false;
      boolean var6 = byteCount >= 0L;
      boolean $i$f$getBuffer = false;
      boolean var8 = false;
      boolean $i$f$getBuffer;
      String var15;
      if (!var6) {
         $i$f$getBuffer = false;
         var15 = "byteCount < 0: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var15.toString()));
      } else {
         var6 = !this.closed;
         $i$f$getBuffer = false;
         var8 = false;
         if (!var6) {
            $i$f$getBuffer = false;
            var15 = "closed";
            throw (Throwable)(new IllegalStateException(var15.toString()));
         } else {
            $i$f$getBuffer = false;
            long read$iv;
            long var10000;
            if (this.bufferField.size() == 0L) {
               $i$f$getBuffer = false;
               read$iv = this.source.read(this.bufferField, (long)8192);
               if (read$iv == -1L) {
                  var10000 = -1L;
                  return var10000;
               }
            }

            $i$f$getBuffer = false;
            long var12 = this.bufferField.size();
            boolean var14 = false;
            read$iv = Math.min(byteCount, var12);
            $i$f$getBuffer = false;
            var10000 = this.bufferField.read(sink, read$iv);
            return var10000;
         }
      }
   }

   public boolean exhausted() {
      int $i$f$commonExhausted = false;
      boolean var3 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var5 = false;
      if (!var3) {
         int var6 = false;
         String var7 = "closed";
         throw (Throwable)(new IllegalStateException(var7.toString()));
      } else {
         $i$f$getBuffer = false;
         boolean var10000;
         if (this.bufferField.exhausted()) {
            $i$f$getBuffer = false;
            if (this.source.read(this.bufferField, (long)8192) == -1L) {
               var10000 = true;
               return var10000;
            }
         }

         var10000 = false;
         return var10000;
      }
   }

   public void require(long byteCount) {
      int $i$f$commonRequire = false;
      if (!this.request(byteCount)) {
         throw (Throwable)(new EOFException());
      }
   }

   public boolean request(long byteCount) {
      RealBufferedSource $this$commonRequest$iv = this;
      int $i$f$commonRequest = false;
      boolean var5 = byteCount >= 0L;
      boolean $i$f$getBuffer = false;
      boolean var7 = false;
      boolean var8;
      String var9;
      if (!var5) {
         var8 = false;
         var9 = "byteCount < 0: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var9.toString()));
      } else {
         var5 = !this.closed;
         $i$f$getBuffer = false;
         var7 = false;
         if (!var5) {
            var8 = false;
            var9 = "closed";
            throw (Throwable)(new IllegalStateException(var9.toString()));
         } else {
            boolean var10000;
            while(true) {
               $i$f$getBuffer = false;
               if ($this$commonRequest$iv.bufferField.size() < byteCount) {
                  $i$f$getBuffer = false;
                  if ($this$commonRequest$iv.source.read($this$commonRequest$iv.bufferField, (long)8192) != -1L) {
                     continue;
                  }

                  var10000 = false;
                  break;
               }

               var10000 = true;
               break;
            }

            return var10000;
         }
      }
   }

   public byte readByte() {
      int $i$f$commonReadByte = false;
      this.require(1L);
      int $i$f$getBuffer = false;
      return this.bufferField.readByte();
   }

   @NotNull
   public ByteString readByteString() {
      int $i$f$commonReadByteString = false;
      int $i$f$getBuffer = false;
      this.bufferField.writeAll(this.source);
      $i$f$getBuffer = false;
      return this.bufferField.readByteString();
   }

   @NotNull
   public ByteString readByteString(long byteCount) {
      int $i$f$commonReadByteString = false;
      this.require(byteCount);
      int $i$f$getBuffer = false;
      return this.bufferField.readByteString(byteCount);
   }

   public int select(@NotNull Options options) {
      Intrinsics.checkNotNullParameter(options, "options");
      RealBufferedSource $this$commonSelect$iv = this;
      int $i$f$commonSelect = false;
      boolean var4 = !this.closed;
      boolean var5 = false;
      boolean $i$f$getBuffer = false;
      boolean $i$f$getBuffer;
      if (!var4) {
         $i$f$getBuffer = false;
         String var10 = "closed";
         throw (Throwable)(new IllegalStateException(var10.toString()));
      } else {
         while(true) {
            $i$f$getBuffer = false;
            int index$iv = BufferKt.selectPrefix($this$commonSelect$iv.bufferField, options, true);
            int var10000;
            switch(index$iv) {
            case -2:
               $i$f$getBuffer = false;
               if ($this$commonSelect$iv.source.read($this$commonSelect$iv.bufferField, (long)8192) != -1L) {
                  break;
               }

               var10000 = -1;
               return var10000;
            case -1:
               var10000 = -1;
               return var10000;
            default:
               int selectedSize$iv = options.getByteStrings$okio()[index$iv].size();
               $i$f$getBuffer = false;
               $this$commonSelect$iv.bufferField.skip((long)selectedSize$iv);
               var10000 = index$iv;
               return var10000;
            }
         }
      }
   }

   @NotNull
   public byte[] readByteArray() {
      int $i$f$commonReadByteArray = false;
      int $i$f$getBuffer = false;
      this.bufferField.writeAll(this.source);
      $i$f$getBuffer = false;
      return this.bufferField.readByteArray();
   }

   @NotNull
   public byte[] readByteArray(long byteCount) {
      int $i$f$commonReadByteArray = false;
      this.require(byteCount);
      int $i$f$getBuffer = false;
      return this.bufferField.readByteArray(byteCount);
   }

   public int read(@NotNull byte[] sink) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      return this.read(sink, 0, sink.length);
   }

   public void readFully(@NotNull byte[] sink) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      RealBufferedSource $this$commonReadFully$iv = this;
      boolean var3 = false;

      try {
         $this$commonReadFully$iv.require((long)sink.length);
      } catch (EOFException var9) {
         int offset$iv = 0;

         while(true) {
            int $i$f$getBuffer = false;
            if ($this$commonReadFully$iv.bufferField.size() <= 0L) {
               throw (Throwable)var9;
            }

            int $i$f$getBuffer = false;
            $i$f$getBuffer = false;
            int read$iv = $this$commonReadFully$iv.bufferField.read(sink, offset$iv, (int)$this$commonReadFully$iv.bufferField.size());
            if (read$iv == -1) {
               throw (Throwable)(new AssertionError());
            }

            offset$iv += read$iv;
         }
      }

      int $i$f$getBuffer = false;
      this.bufferField.readFully(sink);
   }

   public int read(@NotNull byte[] sink, int offset, int byteCount) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      int $i$f$commonRead = false;
      -Util.checkOffsetAndCount((long)sink.length, (long)offset, (long)byteCount);
      int $i$f$getBuffer = false;
      boolean $i$f$minOf;
      int var10000;
      if (this.bufferField.size() == 0L) {
         $i$f$minOf = false;
         long read$iv = this.source.read(this.bufferField, (long)8192);
         if (read$iv == -1L) {
            var10000 = -1;
            return var10000;
         }
      }

      int $i$f$getBuffer = false;
      long b$iv$iv = this.bufferField.size();
      $i$f$minOf = false;
      long var14 = (long)byteCount;
      boolean var16 = false;
      int toRead$iv = (int)Math.min(var14, b$iv$iv);
      $i$f$getBuffer = false;
      var10000 = this.bufferField.read(sink, offset, toRead$iv);
      return var10000;
   }

   public int read(@NotNull ByteBuffer sink) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      int $i$f$getBuffer = false;
      if (this.bufferField.size() == 0L) {
         int $i$f$getBuffer = false;
         long read = this.source.read(this.bufferField, (long)8192);
         if (read == -1L) {
            return -1;
         }
      }

      $i$f$getBuffer = false;
      return this.bufferField.read(sink);
   }

   public void readFully(@NotNull Buffer sink, long byteCount) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      RealBufferedSource $this$commonReadFully$iv = this;
      boolean var5 = false;

      try {
         $this$commonReadFully$iv.require(byteCount);
      } catch (EOFException var9) {
         int $i$f$getBuffer = false;
         sink.writeAll((Source)this.bufferField);
         throw (Throwable)var9;
      }

      int $i$f$getBuffer = false;
      this.bufferField.readFully(sink, byteCount);
   }

   public long readAll(@NotNull Sink sink) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      RealBufferedSource $this$commonReadAll$iv = this;
      int $i$f$commonReadAll = false;
      long totalBytesWritten$iv = 0L;

      while(true) {
         int $i$f$getBuffer = false;
         if ($this$commonReadAll$iv.source.read($this$commonReadAll$iv.bufferField, (long)8192) == -1L) {
            $i$f$getBuffer = false;
            if ($this$commonReadAll$iv.bufferField.size() > 0L) {
               $i$f$getBuffer = false;
               totalBytesWritten$iv += $this$commonReadAll$iv.bufferField.size();
               $i$f$getBuffer = false;
               $i$f$getBuffer = false;
               sink.write($this$commonReadAll$iv.bufferField, $this$commonReadAll$iv.bufferField.size());
            }

            return totalBytesWritten$iv;
         }

         int $i$f$getBuffer = false;
         long emitByteCount$iv = $this$commonReadAll$iv.bufferField.completeSegmentByteCount();
         if (emitByteCount$iv > 0L) {
            totalBytesWritten$iv += emitByteCount$iv;
            $i$f$getBuffer = false;
            sink.write($this$commonReadAll$iv.bufferField, emitByteCount$iv);
         }
      }
   }

   @NotNull
   public String readUtf8() {
      int $i$f$commonReadUtf8 = false;
      int $i$f$getBuffer = false;
      this.bufferField.writeAll(this.source);
      $i$f$getBuffer = false;
      return this.bufferField.readUtf8();
   }

   @NotNull
   public String readUtf8(long byteCount) {
      int $i$f$commonReadUtf8 = false;
      this.require(byteCount);
      int $i$f$getBuffer = false;
      return this.bufferField.readUtf8(byteCount);
   }

   @NotNull
   public String readString(@NotNull Charset charset) {
      Intrinsics.checkNotNullParameter(charset, "charset");
      int $i$f$getBuffer = false;
      this.bufferField.writeAll(this.source);
      $i$f$getBuffer = false;
      return this.bufferField.readString(charset);
   }

   @NotNull
   public String readString(long byteCount, @NotNull Charset charset) {
      Intrinsics.checkNotNullParameter(charset, "charset");
      this.require(byteCount);
      int $i$f$getBuffer = false;
      return this.bufferField.readString(byteCount, charset);
   }

   @Nullable
   public String readUtf8Line() {
      int $i$f$commonReadUtf8Line = false;
      long newline$iv = this.indexOf((byte)10);
      String var10000;
      boolean $i$f$getBuffer;
      if (newline$iv == -1L) {
         $i$f$getBuffer = false;
         if (this.bufferField.size() != 0L) {
            $i$f$getBuffer = false;
            var10000 = this.readUtf8(this.bufferField.size());
         } else {
            var10000 = null;
         }
      } else {
         $i$f$getBuffer = false;
         var10000 = BufferKt.readUtf8Line(this.bufferField, newline$iv);
      }

      return var10000;
   }

   @NotNull
   public String readUtf8LineStrict() {
      return this.readUtf8LineStrict(Long.MAX_VALUE);
   }

   @NotNull
   public String readUtf8LineStrict(long limit) {
      int $i$f$commonReadUtf8LineStrict = false;
      boolean var5 = limit >= 0L;
      boolean var6 = false;
      boolean var7 = false;
      if (!var5) {
         int var8 = false;
         String var25 = "limit < 0: " + limit;
         throw (Throwable)(new IllegalArgumentException(var25.toString()));
      } else {
         label37: {
            long scanLength$iv = limit == Long.MAX_VALUE ? Long.MAX_VALUE : limit + 1L;
            long newline$iv = this.indexOf((byte)10, 0L, scanLength$iv);
            boolean $i$f$getBuffer;
            String var10000;
            if (newline$iv != -1L) {
               $i$f$getBuffer = false;
               var10000 = BufferKt.readUtf8Line(this.bufferField, newline$iv);
            } else {
               if (scanLength$iv >= Long.MAX_VALUE || !this.request(scanLength$iv)) {
                  break label37;
               }

               $i$f$getBuffer = false;
               if (this.bufferField.getByte(scanLength$iv - 1L) != (byte)13 || !this.request(scanLength$iv + 1L)) {
                  break label37;
               }

               $i$f$getBuffer = false;
               if (this.bufferField.getByte(scanLength$iv) != (byte)10) {
                  break label37;
               }

               $i$f$getBuffer = false;
               var10000 = BufferKt.readUtf8Line(this.bufferField, scanLength$iv);
            }

            return var10000;
         }

         Buffer data$iv = new Buffer();
         int $i$f$getBuffer = false;
         Buffer var27 = this.bufferField;
         byte a$iv$iv = 32;
         int $i$f$getBuffer = false;
         long b$iv$iv = this.bufferField.size();
         int $i$f$minOf = false;
         long var20 = (long)a$iv$iv;
         boolean var22 = false;
         var27.copyTo(data$iv, 0L, Math.min(var20, b$iv$iv));
         StringBuilder var10002 = (new StringBuilder()).append("\\n not found: limit=");
         $i$f$getBuffer = false;
         long var23 = this.bufferField.size();
         $i$f$getBuffer = false;
         throw (Throwable)(new EOFException(var10002.append(Math.min(var23, limit)).append(" content=").append(data$iv.readByteString().hex()).append("…").toString()));
      }
   }

   public int readUtf8CodePoint() {
      int $i$f$commonReadUtf8CodePoint = false;
      this.require(1L);
      int $i$f$getBuffer = false;
      int b0$iv = this.bufferField.getByte(0L);
      if ((b0$iv & 224) == 192) {
         this.require(2L);
      } else if ((b0$iv & 240) == 224) {
         this.require(3L);
      } else if ((b0$iv & 248) == 240) {
         this.require(4L);
      }

      $i$f$getBuffer = false;
      return this.bufferField.readUtf8CodePoint();
   }

   public short readShort() {
      int $i$f$commonReadShort = false;
      this.require(2L);
      int $i$f$getBuffer = false;
      return this.bufferField.readShort();
   }

   public short readShortLe() {
      int $i$f$commonReadShortLe = false;
      this.require(2L);
      int $i$f$getBuffer = false;
      return this.bufferField.readShortLe();
   }

   public int readInt() {
      int $i$f$commonReadInt = false;
      this.require(4L);
      int $i$f$getBuffer = false;
      return this.bufferField.readInt();
   }

   public int readIntLe() {
      int $i$f$commonReadIntLe = false;
      this.require(4L);
      int $i$f$getBuffer = false;
      return this.bufferField.readIntLe();
   }

   public long readLong() {
      int $i$f$commonReadLong = false;
      this.require(8L);
      int $i$f$getBuffer = false;
      return this.bufferField.readLong();
   }

   public long readLongLe() {
      int $i$f$commonReadLongLe = false;
      this.require(8L);
      int $i$f$getBuffer = false;
      return this.bufferField.readLongLe();
   }

   public long readDecimalLong() {
      RealBufferedSource $this$commonReadDecimalLong$iv = this;
      int $i$f$commonReadDecimalLong = false;
      this.require(1L);

      for(long pos$iv = 0L; $this$commonReadDecimalLong$iv.request(pos$iv + 1L); ++pos$iv) {
         int $i$f$getBuffer = false;
         byte b$iv = $this$commonReadDecimalLong$iv.bufferField.getByte(pos$iv);
         if ((b$iv < (byte)48 || b$iv > (byte)57) && (pos$iv != 0L || b$iv != (byte)45)) {
            if (pos$iv == 0L) {
               StringBuilder var10002 = (new StringBuilder()).append("Expected leading [0-9] or '-' character but was 0x");
               byte var14 = 16;
               boolean var8 = false;
               int var10 = CharsKt.checkRadix(var14);
               boolean var11 = false;
               String var10003 = Integer.toString(b$iv, CharsKt.checkRadix(var10));
               Intrinsics.checkNotNullExpressionValue(var10003, "java.lang.Integer.toStri…(this, checkRadix(radix))");
               throw (Throwable)(new NumberFormatException(var10002.append(var10003).toString()));
            }
            break;
         }
      }

      int $i$f$getBuffer = false;
      return $this$commonReadDecimalLong$iv.bufferField.readDecimalLong();
   }

   public long readHexadecimalUnsignedLong() {
      RealBufferedSource $this$commonReadHexadecimalUnsignedLong$iv = this;
      int $i$f$commonReadHexadecimalUnsignedLong = false;
      this.require(1L);

      for(int pos$iv = 0; $this$commonReadHexadecimalUnsignedLong$iv.request((long)(pos$iv + 1)); ++pos$iv) {
         int $i$f$getBuffer = false;
         byte b$iv = $this$commonReadHexadecimalUnsignedLong$iv.bufferField.getByte((long)pos$iv);
         if ((b$iv < (byte)48 || b$iv > (byte)57) && (b$iv < (byte)97 || b$iv > (byte)102) && (b$iv < (byte)65 || b$iv > (byte)70)) {
            if (pos$iv == 0) {
               StringBuilder var10002 = (new StringBuilder()).append("Expected leading [0-9a-fA-F] character but was 0x");
               byte var11 = 16;
               boolean var7 = false;
               int var9 = CharsKt.checkRadix(var11);
               boolean var10 = false;
               String var10003 = Integer.toString(b$iv, CharsKt.checkRadix(var9));
               Intrinsics.checkNotNullExpressionValue(var10003, "java.lang.Integer.toStri…(this, checkRadix(radix))");
               throw (Throwable)(new NumberFormatException(var10002.append(var10003).toString()));
            }
            break;
         }
      }

      int $i$f$getBuffer = false;
      return $this$commonReadHexadecimalUnsignedLong$iv.bufferField.readHexadecimalUnsignedLong();
   }

   public void skip(long byteCount) {
      RealBufferedSource $this$commonSkip$iv = this;
      int $i$f$commonSkip = false;
      long byteCount$iv = byteCount;
      boolean var7 = !this.closed;
      boolean $i$f$getBuffer = false;
      boolean var9 = false;
      boolean $i$f$getBuffer;
      if (!var7) {
         $i$f$getBuffer = false;
         String var16 = "closed";
         throw (Throwable)(new IllegalStateException(var16.toString()));
      } else {
         while(byteCount$iv > 0L) {
            $i$f$getBuffer = false;
            if ($this$commonSkip$iv.bufferField.size() == 0L) {
               $i$f$getBuffer = false;
               if ($this$commonSkip$iv.source.read($this$commonSkip$iv.bufferField, (long)8192) == -1L) {
                  throw (Throwable)(new EOFException());
               }
            }

            $i$f$getBuffer = false;
            long var11 = $this$commonSkip$iv.bufferField.size();
            boolean var13 = false;
            long toSkip$iv = Math.min(byteCount$iv, var11);
            $i$f$getBuffer = false;
            $this$commonSkip$iv.bufferField.skip(toSkip$iv);
            byteCount$iv -= toSkip$iv;
         }

      }
   }

   public long indexOf(byte b) {
      return this.indexOf(b, 0L, Long.MAX_VALUE);
   }

   public long indexOf(byte b, long fromIndex) {
      return this.indexOf(b, fromIndex, Long.MAX_VALUE);
   }

   public long indexOf(byte b, long fromIndex, long toIndex) {
      RealBufferedSource $this$commonIndexOf$iv = this;
      int $i$f$commonIndexOf = false;
      long fromIndex$iv = fromIndex;
      boolean var8 = !this.closed;
      boolean var9 = false;
      boolean var10 = false;
      boolean $i$f$getBuffer;
      String var23;
      if (!var8) {
         $i$f$getBuffer = false;
         var23 = "closed";
         throw (Throwable)(new IllegalStateException(var23.toString()));
      } else {
         boolean var10000;
         label43: {
            if (0L <= fromIndex) {
               if (toIndex >= fromIndex) {
                  var10000 = true;
                  break label43;
               }
            }

            var10000 = false;
         }

         var8 = var10000;
         var9 = false;
         var10 = false;
         if (!var8) {
            $i$f$getBuffer = false;
            var23 = "fromIndex=" + fromIndex + " toIndex=" + toIndex;
            throw (Throwable)(new IllegalArgumentException(var23.toString()));
         } else {
            long var24;
            while(true) {
               if (fromIndex$iv < toIndex) {
                  $i$f$getBuffer = false;
                  long result$iv = $this$commonIndexOf$iv.bufferField.indexOf(b, fromIndex$iv, toIndex);
                  if (result$iv != -1L) {
                     var24 = result$iv;
                     break;
                  }

                  int $i$f$getBuffer = false;
                  long lastBufferSize$iv = $this$commonIndexOf$iv.bufferField.size();
                  if (lastBufferSize$iv < toIndex) {
                     $i$f$getBuffer = false;
                     if ($this$commonIndexOf$iv.source.read($this$commonIndexOf$iv.bufferField, (long)8192) != -1L) {
                        boolean var20 = false;
                        fromIndex$iv = Math.max(fromIndex$iv, lastBufferSize$iv);
                        continue;
                     }
                  }

                  var24 = -1L;
                  break;
               }

               var24 = -1L;
               break;
            }

            return var24;
         }
      }
   }

   public long indexOf(@NotNull ByteString bytes) {
      Intrinsics.checkNotNullParameter(bytes, "bytes");
      return this.indexOf(bytes, 0L);
   }

   public long indexOf(@NotNull ByteString bytes, long fromIndex) {
      Intrinsics.checkNotNullParameter(bytes, "bytes");
      RealBufferedSource $this$commonIndexOf$iv = this;
      int $i$f$commonIndexOf = false;
      long fromIndex$iv = fromIndex;
      boolean var8 = !this.closed;
      boolean var9 = false;
      boolean var10 = false;
      boolean $i$f$getBuffer;
      if (!var8) {
         $i$f$getBuffer = false;
         String var21 = "closed";
         throw (Throwable)(new IllegalStateException(var21.toString()));
      } else {
         long var10000;
         while(true) {
            $i$f$getBuffer = false;
            long result$iv = $this$commonIndexOf$iv.bufferField.indexOf(bytes, fromIndex$iv);
            if (result$iv != -1L) {
               var10000 = result$iv;
               break;
            }

            int $i$f$getBuffer = false;
            long lastBufferSize$iv = $this$commonIndexOf$iv.bufferField.size();
            $i$f$getBuffer = false;
            if ($this$commonIndexOf$iv.source.read($this$commonIndexOf$iv.bufferField, (long)8192) == -1L) {
               var10000 = -1L;
               break;
            }

            long var18 = lastBufferSize$iv - (long)bytes.size() + 1L;
            boolean var20 = false;
            fromIndex$iv = Math.max(fromIndex$iv, var18);
         }

         return var10000;
      }
   }

   public long indexOfElement(@NotNull ByteString targetBytes) {
      Intrinsics.checkNotNullParameter(targetBytes, "targetBytes");
      return this.indexOfElement(targetBytes, 0L);
   }

   public long indexOfElement(@NotNull ByteString targetBytes, long fromIndex) {
      Intrinsics.checkNotNullParameter(targetBytes, "targetBytes");
      RealBufferedSource $this$commonIndexOfElement$iv = this;
      int $i$f$commonIndexOfElement = false;
      long fromIndex$iv = fromIndex;
      boolean var8 = !this.closed;
      boolean var9 = false;
      boolean var10 = false;
      boolean $i$f$getBuffer;
      if (!var8) {
         $i$f$getBuffer = false;
         String var18 = "closed";
         throw (Throwable)(new IllegalStateException(var18.toString()));
      } else {
         long var10000;
         while(true) {
            $i$f$getBuffer = false;
            long result$iv = $this$commonIndexOfElement$iv.bufferField.indexOfElement(targetBytes, fromIndex$iv);
            if (result$iv != -1L) {
               var10000 = result$iv;
               break;
            }

            int $i$f$getBuffer = false;
            long lastBufferSize$iv = $this$commonIndexOfElement$iv.bufferField.size();
            $i$f$getBuffer = false;
            if ($this$commonIndexOfElement$iv.source.read($this$commonIndexOfElement$iv.bufferField, (long)8192) == -1L) {
               var10000 = -1L;
               break;
            }

            boolean var14 = false;
            fromIndex$iv = Math.max(fromIndex$iv, lastBufferSize$iv);
         }

         return var10000;
      }
   }

   public boolean rangeEquals(long offset, @NotNull ByteString bytes) {
      Intrinsics.checkNotNullParameter(bytes, "bytes");
      return this.rangeEquals(offset, bytes, 0, bytes.size());
   }

   public boolean rangeEquals(long offset, @NotNull ByteString bytes, int bytesOffset, int byteCount) {
      Intrinsics.checkNotNullParameter(bytes, "bytes");
      RealBufferedSource $this$commonRangeEquals$iv = this;
      int $i$f$commonRangeEquals = false;
      boolean var8 = !this.closed;
      boolean var9 = false;
      boolean var10 = false;
      if (!var8) {
         int var11 = false;
         String var18 = "closed";
         throw (Throwable)(new IllegalStateException(var18.toString()));
      } else {
         boolean var10000;
         if (offset >= 0L && bytesOffset >= 0 && byteCount >= 0 && bytes.size() - bytesOffset >= byteCount) {
            int i$iv = 0;
            int var17 = byteCount;

            while(true) {
               if (i$iv >= var17) {
                  var10000 = true;
                  break;
               }

               long bufferOffset$iv = offset + (long)i$iv;
               if (!$this$commonRangeEquals$iv.request(bufferOffset$iv + 1L)) {
                  var10000 = false;
                  break;
               }

               int $i$f$getBuffer = false;
               if ($this$commonRangeEquals$iv.bufferField.getByte(bufferOffset$iv) != bytes.getByte(bytesOffset + i$iv)) {
                  var10000 = false;
                  break;
               }

               ++i$iv;
            }
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   @NotNull
   public BufferedSource peek() {
      int $i$f$commonPeek = false;
      return Okio.buffer((Source)(new PeekSource((BufferedSource)this)));
   }

   @NotNull
   public InputStream inputStream() {
      return (InputStream)(new InputStream() {
         public int read() {
            if (RealBufferedSource.this.closed) {
               throw (Throwable)(new IOException("closed"));
            } else {
               RealBufferedSource this_$iv = RealBufferedSource.this;
               int $i$f$getBuffer = false;
               if (this_$iv.bufferField.size() == 0L) {
                  RealBufferedSource this_$ivx = RealBufferedSource.this;
                  int $i$f$getBufferx = false;
                  long count = RealBufferedSource.this.source.read(this_$ivx.bufferField, (long)8192);
                  if (count == -1L) {
                     return -1;
                  }
               }

               this_$iv = RealBufferedSource.this;
               $i$f$getBuffer = false;
               byte $this$and$iv = this_$iv.bufferField.readByte();
               int other$iv = 255;
               int $i$f$and = false;
               return $this$and$iv & other$iv;
            }
         }

         public int read(@NotNull byte[] data, int offset, int byteCount) {
            Intrinsics.checkNotNullParameter(data, "data");
            if (RealBufferedSource.this.closed) {
               throw (Throwable)(new IOException("closed"));
            } else {
               -Util.checkOffsetAndCount((long)data.length, (long)offset, (long)byteCount);
               RealBufferedSource this_$ivx = RealBufferedSource.this;
               int $i$f$getBufferx = false;
               if (this_$ivx.bufferField.size() == 0L) {
                  RealBufferedSource this_$iv = RealBufferedSource.this;
                  int $i$f$getBuffer = false;
                  long count = RealBufferedSource.this.source.read(this_$iv.bufferField, (long)8192);
                  if (count == -1L) {
                     return -1;
                  }
               }

               this_$ivx = RealBufferedSource.this;
               $i$f$getBufferx = false;
               return this_$ivx.bufferField.read(data, offset, byteCount);
            }
         }

         public int available() {
            if (RealBufferedSource.this.closed) {
               throw (Throwable)(new IOException("closed"));
            } else {
               RealBufferedSource this_$iv = RealBufferedSource.this;
               int $i$f$getBuffer = false;
               long a$iv = this_$iv.bufferField.size();
               int b$iv = Integer.MAX_VALUE;
               int $i$f$minOf = false;
               long var5 = (long)b$iv;
               boolean var7 = false;
               return (int)Math.min(a$iv, var5);
            }
         }

         public void close() {
            RealBufferedSource.this.close();
         }

         @NotNull
         public String toString() {
            return RealBufferedSource.this + ".inputStream()";
         }
      });
   }

   public boolean isOpen() {
      return !this.closed;
   }

   public void close() {
      int $i$f$commonClose = false;
      if (!this.closed) {
         this.closed = true;
         this.source.close();
         int $i$f$getBuffer = false;
         this.bufferField.clear();
      }

   }

   @NotNull
   public Timeout timeout() {
      int $i$f$commonTimeout = false;
      return this.source.timeout();
   }

   @NotNull
   public String toString() {
      int $i$f$commonToString = false;
      return "buffer(" + this.source + ')';
   }

   public RealBufferedSource(@NotNull Source source) {
      Intrinsics.checkNotNullParameter(source, "source");
      super();
      this.source = source;
      this.bufferField = new Buffer();
   }
}
