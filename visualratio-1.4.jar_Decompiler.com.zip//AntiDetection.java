import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class AntiDetection {
   private static final String[] DEBUGGER_PROCESSES = new String[]{"jdb.exe", "gdb.exe", "ida.exe", "ida64.exe", "ollydbg.exe", "x64dbg.exe", "windbg.exe", "immunitydebugger.exe"};
   private static final String[] VM_FILES = new String[]{"vboxguestadditions.iso", "vboxwindowsadditions.exe", "vmwaretools.exe", "vmwareuser.exe", "vmwareservice.exe", "qemu-ga.exe"};
   private static final String[] VM_MAC_ADDRESSES = new String[]{"00:0C:29", "00:1C:14", "00:50:56", "00:05:69", "08:00:27"};
   private static final String[] VM_ENV_VARS = new String[]{"VBOX", "VMWARE", "QEMU", "VIRTUALBOX"};

   public static void performEnvironmentCheck() {
      boolean var0 = isDebuggerAttached();
      boolean var1 = isDebuggerProcessRunning();
      boolean var2 = isRunningInVM();
      boolean var3 = isRunningInSandbox();
      if (var0) {
      }

      if (var1) {
      }

      if (var2) {
      }

      if (var3) {
      }

      if (!var0 && !var1 && !var2 && !var3) {
      }

   }

   public static boolean isDebuggerAttached() {
      try {
         RuntimeMXBean var0 = ManagementFactory.getRuntimeMXBean();
         String var1 = var0.getInputArguments().toString();
         return var1.contains("-agentlib:jdwp") || var1.contains("-Xdebug") || var1.contains("-Xrunjdwp");
      } catch (Exception var2) {
         return false;
      }
   }

   public static boolean isDebuggerProcessRunning() {
      try {
         Process var0 = Runtime.getRuntime().exec(System.getProperty("os.name").toLowerCase().contains("win") ? "tasklist /fo csv" : "ps -ef");
         BufferedReader var1 = new BufferedReader(new InputStreamReader(var0.getInputStream()));

         String var2;
         while((var2 = var1.readLine()) != null) {
            String[] var3 = DEBUGGER_PROCESSES;
            int var4 = var3.length;

            for(int var5 = 0; var5 < var4; ++var5) {
               String var6 = var3[var5];
               if (var2.toLowerCase().contains(var6.toLowerCase())) {
                  return true;
               }
            }
         }
      } catch (Exception var7) {
      }

      return false;
   }

   public static boolean isRunningInVM() {
      try {
         String[] var0 = VM_FILES;
         int var1 = var0.length;
         int var2 = 0;

         label60:
         while(true) {
            if (var2 >= var1) {
               if (!System.getProperty("os.name").toLowerCase().contains("win")) {
                  break;
               }

               Process var8 = Runtime.getRuntime().exec("getmac");
               BufferedReader var10 = new BufferedReader(new InputStreamReader(var8.getInputStream()));

               while(true) {
                  String var12;
                  if ((var12 = var10.readLine()) == null) {
                     break label60;
                  }

                  String[] var13 = VM_MAC_ADDRESSES;
                  int var4 = var13.length;

                  for(int var5 = 0; var5 < var4; ++var5) {
                     String var6 = var13[var5];
                     if (var12.contains(var6)) {
                        return true;
                     }
                  }
               }
            }

            String var3 = var0[var2];
            if ((new File("C:\\" + var3)).exists() || (new File("/usr/bin/" + var3)).exists()) {
               return true;
            }

            ++var2;
         }

         Map var9 = System.getenv();
         String[] var11 = VM_ENV_VARS;
         var2 = var11.length;

         for(int var14 = 0; var14 < var2; ++var14) {
            String var15 = var11[var14];
            Iterator var16 = var9.entrySet().iterator();

            while(var16.hasNext()) {
               Entry var17 = (Entry)var16.next();
               if (((String)var17.getKey()).toUpperCase().contains(var15) || ((String)var17.getValue()).toUpperCase().contains(var15)) {
                  return true;
               }
            }
         }
      } catch (Exception var7) {
      }

      return false;
   }

   public static boolean isRunningInSandbox() {
      try {
         Process var0 = Runtime.getRuntime().exec(System.getProperty("os.name").toLowerCase().contains("win") ? "tasklist /fo csv" : "ps -ef");
         BufferedReader var1 = new BufferedReader(new InputStreamReader(var0.getInputStream()));

         String var3;
         do {
            String var2;
            if ((var2 = var1.readLine()) == null) {
               File[] var11 = File.listRoots();
               File[] var4 = var11;
               int var5 = var11.length;

               int var6;
               for(var6 = 0; var6 < var5; ++var6) {
                  File var7 = var4[var6];
                  long var8 = var7.getTotalSpace();
                  if (var8 < -2147483648L) {
                     return true;
                  }
               }

               long var12 = Runtime.getRuntime().maxMemory();
               if (var12 < 536870912L) {
                  return true;
               }

               var6 = Runtime.getRuntime().availableProcessors();
               if (var6 <= 1) {
                  return true;
               }

               long var13 = ManagementFactory.getRuntimeMXBean().getUptime();
               if (var13 < 300000L) {
                  return true;
               }

               return false;
            }

            var3 = var2.toLowerCase();
         } while(!var3.contains("sandboxie") && !var3.contains("procmon") && !var3.contains("wireshark") && !var3.contains("fiddler") && !var3.contains("processhacker"));

         return true;
      } catch (Exception var10) {
         return false;
      }
   }

   public static boolean isAnalysisEnvironment() {
      return isDebuggerAttached() || isDebuggerProcessRunning() || isRunningInVM() || isRunningInSandbox();
   }
}
