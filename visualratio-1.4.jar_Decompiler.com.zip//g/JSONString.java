package g;

public interface JSONString {
   String toJSONString();
}
