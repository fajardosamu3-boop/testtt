package i;

import java.util.Arrays;
import k.Metadata;
import k.jvm.JvmName;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 2,
   d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0003\u001a\u000e\u0010\u0006\u001a\u0004\u0018\u00010\u0001*\u00020\u0007H\u0000\u001a\u0016\u0010\b\u001a\u00020\u0007*\u00020\u00012\b\b\u0002\u0010\t\u001a\u00020\u0001H\u0000\"\u0014\u0010\u0000\u001a\u00020\u0001X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003\"\u0014\u0010\u0004\u001a\u00020\u0001X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0003¨\u0006\n"},
   d2 = {"BASE64", "", "getBASE64", "()[B", "BASE64_URL_SAFE", "getBASE64_URL_SAFE", "decodeBase64ToArray", "", "encodeBase64", "map", "i"}
)
@JvmName(
   name = "-Base64"
)
public final class -Base64 {
   @NotNull
   private static final byte[] BASE64;
   @NotNull
   private static final byte[] BASE64_URL_SAFE;

   @NotNull
   public static final byte[] getBASE64() {
      return BASE64;
   }

   @NotNull
   public static final byte[] getBASE64_URL_SAFE() {
      return BASE64_URL_SAFE;
   }

   @Nullable
   public static final byte[] decodeBase64ToArray(@NotNull String $this$decodeBase64ToArray) {
      Intrinsics.checkNotNullParameter($this$decodeBase64ToArray, "$this$decodeBase64ToArray");

      int limit;
      for(limit = $this$decodeBase64ToArray.length(); limit > 0; --limit) {
         char c = $this$decodeBase64ToArray.charAt(limit - 1);
         if (c != '=' && c != '\n' && c != '\r' && c != ' ' && c != '\t') {
            break;
         }
      }

      byte[] out = new byte[(int)((long)limit * 6L / 8L)];
      int outCount = 0;
      int inCount = 0;
      int word = 0;
      int lastWordChars = 0;

      for(int var7 = limit; lastWordChars < var7; ++lastWordChars) {
         int bits;
         label102: {
            char c = $this$decodeBase64ToArray.charAt(lastWordChars);
            int bits = false;
            if ('A' <= c) {
               if ('Z' >= c) {
                  bits = c - 65;
                  break label102;
               }
            }

            if ('a' <= c) {
               if ('z' >= c) {
                  bits = c - 71;
                  break label102;
               }
            }

            if ('0' <= c) {
               if ('9' >= c) {
                  bits = c + 4;
                  break label102;
               }
            }

            if (c != '+' && c != '-') {
               if (c != '/' && c != '_') {
                  if (c != '\n' && c != '\r' && c != ' ' && c != '\t') {
                     return null;
                  }
                  continue;
               }

               bits = 63;
            } else {
               bits = 62;
            }
         }

         word = word << 6 | bits;
         ++inCount;
         if (inCount % 4 == 0) {
            out[outCount++] = (byte)(word >> 16);
            out[outCount++] = (byte)(word >> 8);
            out[outCount++] = (byte)word;
         }
      }

      lastWordChars = inCount % 4;
      switch(lastWordChars) {
      case 1:
         return null;
      case 2:
         word <<= 12;
         out[outCount++] = (byte)(word >> 16);
         break;
      case 3:
         word <<= 6;
         out[outCount++] = (byte)(word >> 16);
         out[outCount++] = (byte)(word >> 8);
      }

      if (outCount == out.length) {
         return out;
      } else {
         boolean var12 = false;
         byte[] var10000 = Arrays.copyOf(out, outCount);
         Intrinsics.checkNotNullExpressionValue(var10000, "java.util.Arrays.copyOf(this, newSize)");
         return var10000;
      }
   }

   @NotNull
   public static final String encodeBase64(@NotNull byte[] $this$encodeBase64, @NotNull byte[] map) {
      Intrinsics.checkNotNullParameter($this$encodeBase64, "$this$encodeBase64");
      Intrinsics.checkNotNullParameter(map, "map");
      int length = ($this$encodeBase64.length + 2) / 3 * 4;
      byte[] out = new byte[length];
      int index = 0;
      int end = $this$encodeBase64.length - $this$encodeBase64.length % 3;

      int i;
      byte b0;
      byte b1;
      byte b2;
      for(i = 0; i < end; out[index++] = map[b2 & 63]) {
         b0 = $this$encodeBase64[i++];
         b1 = $this$encodeBase64[i++];
         b2 = $this$encodeBase64[i++];
         out[index++] = map[(b0 & 255) >> 2];
         out[index++] = map[(b0 & 3) << 4 | (b1 & 255) >> 4];
         out[index++] = map[(b1 & 15) << 2 | (b2 & 255) >> 6];
      }

      switch($this$encodeBase64.length - end) {
      case 1:
         b0 = $this$encodeBase64[i];
         out[index++] = map[(b0 & 255) >> 2];
         out[index++] = map[(b0 & 3) << 4];
         out[index++] = (byte)61;
         out[index] = (byte)61;
         break;
      case 2:
         b0 = $this$encodeBase64[i++];
         b1 = $this$encodeBase64[i];
         out[index++] = map[(b0 & 255) >> 2];
         out[index++] = map[(b0 & 3) << 4 | (b1 & 255) >> 4];
         out[index++] = map[(b1 & 15) << 2];
         out[index] = (byte)61;
      }

      return -Platform.toUtf8String(out);
   }

   // $FF: synthetic method
   public static String encodeBase64$default(byte[] var0, byte[] var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = BASE64;
      }

      return encodeBase64(var0, var1);
   }

   static {
      BASE64 = ByteString.Companion.encodeUtf8("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/").getData$okio();
      BASE64_URL_SAFE = ByteString.Companion.encodeUtf8("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_").getData$okio();
   }
}
