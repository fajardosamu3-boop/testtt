import java.awt.Desktop;
import java.awt.Desktop.Action;
import java.net.URI;

public class WebOpen {
   public static String openWebPage(String var0) {
      try {
         if (!var0.startsWith("http://") && !var0.startsWith("https://")) {
            var0 = "https://" + var0;
         }

         if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Action.BROWSE)) {
            Desktop.getDesktop().browse(new URI(var0));
            return "Página web abierta: " + var0;
         } else {
            String var1 = System.getProperty("os.name").toLowerCase();
            Process var2;
            if (var1.contains("win")) {
               var2 = Runtime.getRuntime().exec(new String[]{"cmd", "/c", "start", var0});
            } else if (var1.contains("mac")) {
               var2 = Runtime.getRuntime().exec(new String[]{"open", var0});
            } else {
               var2 = Runtime.getRuntime().exec(new String[]{"xdg-open", var0});
            }

            int var3 = var2.waitFor();
            return var3 == 0 ? "Página web abierta: " + var0 : "Error al abrir página web (código: " + var3 + ")";
         }
      } catch (Exception var4) {
         return "Error al abrir página web: " + var4.getMessage();
      }
   }
}
