package i;

import i.internal.SegmentedByteStringKt;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.MessageDigest;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import k.Metadata;
import k.collections.ArraysKt;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000h\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u0015\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0010\u0005\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0000\u0018\u00002\u00020\u0001B\u001d\b\u0000\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007J\b\u0010\r\u001a\u00020\u000eH\u0016J\b\u0010\u000f\u001a\u00020\u0010H\u0016J\b\u0010\u0011\u001a\u00020\u0010H\u0016J\u0015\u0010\u0012\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u0010H\u0010¢\u0006\u0002\b\u0014J\u0013\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0018H\u0096\u0002J\r\u0010\u0019\u001a\u00020\u001aH\u0010¢\u0006\u0002\b\u001bJ\b\u0010\u001c\u001a\u00020\u001aH\u0016J\b\u0010\u001d\u001a\u00020\u0010H\u0016J\u001d\u0010\u001e\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u00102\u0006\u0010\u001f\u001a\u00020\u0001H\u0010¢\u0006\u0002\b J\u0018\u0010!\u001a\u00020\u001a2\u0006\u0010\u0017\u001a\u00020\u00042\u0006\u0010\"\u001a\u00020\u001aH\u0016J\r\u0010#\u001a\u00020\u0004H\u0010¢\u0006\u0002\b$J\u0015\u0010%\u001a\u00020&2\u0006\u0010'\u001a\u00020\u001aH\u0010¢\u0006\u0002\b(J\u0018\u0010)\u001a\u00020\u001a2\u0006\u0010\u0017\u001a\u00020\u00042\u0006\u0010\"\u001a\u00020\u001aH\u0016J(\u0010*\u001a\u00020\u00162\u0006\u0010+\u001a\u00020\u001a2\u0006\u0010\u0017\u001a\u00020\u00042\u0006\u0010,\u001a\u00020\u001a2\u0006\u0010-\u001a\u00020\u001aH\u0016J(\u0010*\u001a\u00020\u00162\u0006\u0010+\u001a\u00020\u001a2\u0006\u0010\u0017\u001a\u00020\u00012\u0006\u0010,\u001a\u00020\u001a2\u0006\u0010-\u001a\u00020\u001aH\u0016J\u0010\u0010.\u001a\u00020\u00102\u0006\u0010/\u001a\u000200H\u0016J\u0018\u00101\u001a\u00020\u00012\u0006\u00102\u001a\u00020\u001a2\u0006\u00103\u001a\u00020\u001aH\u0016J\b\u00104\u001a\u00020\u0001H\u0016J\b\u00105\u001a\u00020\u0001H\u0016J\b\u00106\u001a\u00020\u0004H\u0016J\b\u00107\u001a\u00020\u0001H\u0002J\b\u00108\u001a\u00020\u0010H\u0016J\u0010\u00109\u001a\u00020:2\u0006\u0010;\u001a\u00020<H\u0016J%\u00109\u001a\u00020:2\u0006\u0010=\u001a\u00020>2\u0006\u0010+\u001a\u00020\u001a2\u0006\u0010-\u001a\u00020\u001aH\u0010¢\u0006\u0002\b?J\b\u0010@\u001a\u00020AH\u0002R\u0014\u0010\u0005\u001a\u00020\u0006X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u001c\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X\u0080\u0004¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\n\u0010\u000b¨\u0006B"},
   d2 = {"Li/SegmentedByteString;", "Li/ByteString;", "segments", "", "", "directory", "", "([[B[I)V", "getDirectory$okio", "()[I", "getSegments$okio", "()[[B", "[[B", "asByteBuffer", "Ljava/nio/ByteBuffer;", "base64", "", "base64Url", "digest", "algorithm", "digest$okio", "equals", "", "other", "", "getSize", "", "getSize$okio", "hashCode", "hex", "hmac", "key", "hmac$okio", "indexOf", "fromIndex", "internalArray", "internalArray$okio", "internalGet", "", "pos", "internalGet$okio", "lastIndexOf", "rangeEquals", "offset", "otherOffset", "byteCount", "string", "charset", "Ljava/nio/charset/Charset;", "substring", "beginIndex", "endIndex", "toAsciiLowercase", "toAsciiUppercase", "toByteArray", "toByteString", "toString", "write", "", "out", "Ljava/io/OutputStream;", "buffer", "Li/Buffer;", "write$okio", "writeReplace", "Ljava/lang/Object;", "i"}
)
public final class SegmentedByteString extends ByteString {
   @NotNull
   private final transient byte[][] segments;
   @NotNull
   private final transient int[] directory;

   @NotNull
   public String string(@NotNull Charset charset) {
      Intrinsics.checkNotNullParameter(charset, "charset");
      return this.toByteString().string(charset);
   }

   @NotNull
   public String base64() {
      return this.toByteString().base64();
   }

   @NotNull
   public String hex() {
      return this.toByteString().hex();
   }

   @NotNull
   public ByteString toAsciiLowercase() {
      return this.toByteString().toAsciiLowercase();
   }

   @NotNull
   public ByteString toAsciiUppercase() {
      return this.toByteString().toAsciiUppercase();
   }

   @NotNull
   public ByteString digest$okio(@NotNull String algorithm) {
      Intrinsics.checkNotNullParameter(algorithm, "algorithm");
      MessageDigest digest = MessageDigest.getInstance(algorithm);
      SegmentedByteString $this$forEachSegment$iv = this;
      int $i$f$forEachSegment = false;
      int segmentCount$iv = ((Object[])this.getSegments$okio()).length;
      int s$iv = 0;

      for(int pos$iv = 0; s$iv < segmentCount$iv; ++s$iv) {
         int segmentPos$iv = $this$forEachSegment$iv.getDirectory$okio()[segmentCount$iv + s$iv];
         int nextSegmentOffset$iv = $this$forEachSegment$iv.getDirectory$okio()[s$iv];
         byte[] var10000 = $this$forEachSegment$iv.getSegments$okio()[s$iv];
         int byteCount = nextSegmentOffset$iv - pos$iv;
         byte[] data = var10000;
         int var13 = false;
         digest.update(data, segmentPos$iv, byteCount);
         pos$iv = nextSegmentOffset$iv;
      }

      byte[] var10002 = digest.digest();
      Intrinsics.checkNotNullExpressionValue(var10002, "digest.digest()");
      return new ByteString(var10002);
   }

   @NotNull
   public ByteString hmac$okio(@NotNull String algorithm, @NotNull ByteString key) {
      Intrinsics.checkNotNullParameter(algorithm, "algorithm");
      Intrinsics.checkNotNullParameter(key, "key");

      try {
         Mac mac = Mac.getInstance(algorithm);
         mac.init((Key)(new SecretKeySpec(key.toByteArray(), algorithm)));
         SegmentedByteString $this$forEachSegment$iv = this;
         int $i$f$forEachSegment = false;
         int segmentCount$iv = ((Object[])this.getSegments$okio()).length;
         int s$iv = 0;

         for(int pos$iv = 0; s$iv < segmentCount$iv; ++s$iv) {
            int segmentPos$iv = $this$forEachSegment$iv.getDirectory$okio()[segmentCount$iv + s$iv];
            int nextSegmentOffset$iv = $this$forEachSegment$iv.getDirectory$okio()[s$iv];
            byte[] var10000 = $this$forEachSegment$iv.getSegments$okio()[s$iv];
            int byteCount = nextSegmentOffset$iv - pos$iv;
            byte[] data = var10000;
            int var14 = false;
            mac.update(data, segmentPos$iv, byteCount);
            pos$iv = nextSegmentOffset$iv;
         }

         byte[] var10002 = mac.doFinal();
         Intrinsics.checkNotNullExpressionValue(var10002, "mac.doFinal()");
         return new ByteString(var10002);
      } catch (InvalidKeyException var15) {
         throw (Throwable)(new IllegalArgumentException((Throwable)var15));
      }
   }

   @NotNull
   public String base64Url() {
      return this.toByteString().base64Url();
   }

   @NotNull
   public ByteString substring(int beginIndex, int endIndex) {
      SegmentedByteString $this$commonSubstring$iv = this;
      int $i$f$commonSubstring = false;
      boolean var5 = beginIndex >= 0;
      boolean var6 = false;
      boolean var7 = false;
      boolean var8;
      String var18;
      if (!var5) {
         var8 = false;
         var18 = "beginIndex=" + beginIndex + " < 0";
         throw (Throwable)(new IllegalArgumentException(var18.toString()));
      } else {
         var5 = endIndex <= this.size();
         var6 = false;
         var7 = false;
         if (!var5) {
            var8 = false;
            var18 = "endIndex=" + endIndex + " > length(" + this.size() + ')';
            throw (Throwable)(new IllegalArgumentException(var18.toString()));
         } else {
            int subLen$iv = endIndex - beginIndex;
            var6 = subLen$iv >= 0;
            var7 = false;
            var8 = false;
            if (!var6) {
               int var22 = false;
               String var20 = "endIndex=" + endIndex + " < beginIndex=" + beginIndex;
               throw (Throwable)(new IllegalArgumentException(var20.toString()));
            } else {
               ByteString var10000;
               if (beginIndex == 0 && endIndex == this.size()) {
                  var10000 = (ByteString)this;
               } else if (beginIndex == endIndex) {
                  var10000 = ByteString.EMPTY;
               } else {
                  int beginSegment$iv = SegmentedByteStringKt.segment(this, beginIndex);
                  int endSegment$iv = SegmentedByteStringKt.segment(this, endIndex - 1);
                  Object[] var9 = (Object[])this.getSegments$okio();
                  int index$iv = endSegment$iv + 1;
                  boolean var11 = false;
                  byte[][] newSegments$iv = (byte[][])ArraysKt.copyOfRange(var9, beginSegment$iv, index$iv);
                  int[] newDirectory$iv = new int[((Object[])newSegments$iv).length * 2];
                  index$iv = 0;
                  int s$iv = beginSegment$iv;
                  int var12 = endSegment$iv;
                  if (beginSegment$iv <= endSegment$iv) {
                     while(true) {
                        int var13 = $this$commonSubstring$iv.getDirectory$okio()[s$iv] - beginIndex;
                        boolean var14 = false;
                        newDirectory$iv[index$iv] = Math.min(var13, subLen$iv);
                        newDirectory$iv[index$iv++ + ((Object[])newSegments$iv).length] = $this$commonSubstring$iv.getDirectory$okio()[s$iv + ((Object[])$this$commonSubstring$iv.getSegments$okio()).length];
                        if (s$iv == var12) {
                           break;
                        }

                        ++s$iv;
                     }
                  }

                  s$iv = beginSegment$iv == 0 ? 0 : $this$commonSubstring$iv.getDirectory$okio()[beginSegment$iv - 1];
                  newDirectory$iv[((Object[])newSegments$iv).length] += beginIndex - s$iv;
                  var10000 = (ByteString)(new SegmentedByteString(newSegments$iv, newDirectory$iv));
               }

               return var10000;
            }
         }
      }
   }

   public byte internalGet$okio(int pos) {
      int $i$f$commonInternalGet = false;
      -Util.checkOffsetAndCount((long)this.getDirectory$okio()[((Object[])this.getSegments$okio()).length - 1], (long)pos, 1L);
      int segment$iv = SegmentedByteStringKt.segment(this, pos);
      int segmentOffset$iv = segment$iv == 0 ? 0 : this.getDirectory$okio()[segment$iv - 1];
      int segmentPos$iv = this.getDirectory$okio()[segment$iv + ((Object[])this.getSegments$okio()).length];
      return this.getSegments$okio()[segment$iv][pos - segmentOffset$iv + segmentPos$iv];
   }

   public int getSize$okio() {
      int $i$f$commonGetSize = false;
      return this.getDirectory$okio()[((Object[])this.getSegments$okio()).length - 1];
   }

   @NotNull
   public byte[] toByteArray() {
      int $i$f$commonToByteArray = false;
      byte[] result$iv = new byte[this.size()];
      int resultPos$iv = 0;
      SegmentedByteString $this$forEachSegment$iv$iv = this;
      int $i$f$forEachSegment = false;
      int segmentCount$iv$iv = ((Object[])this.getSegments$okio()).length;
      int s$iv$iv = 0;

      for(int pos$iv$iv = 0; s$iv$iv < segmentCount$iv$iv; ++s$iv$iv) {
         int segmentPos$iv$iv = $this$forEachSegment$iv$iv.getDirectory$okio()[segmentCount$iv$iv + s$iv$iv];
         int nextSegmentOffset$iv$iv = $this$forEachSegment$iv$iv.getDirectory$okio()[s$iv$iv];
         byte[] var10000 = $this$forEachSegment$iv$iv.getSegments$okio()[s$iv$iv];
         int byteCount$iv = nextSegmentOffset$iv$iv - pos$iv$iv;
         byte[] data$iv = var10000;
         int var15 = false;
         ArraysKt.copyInto(data$iv, result$iv, resultPos$iv, segmentPos$iv$iv, segmentPos$iv$iv + byteCount$iv);
         resultPos$iv += byteCount$iv;
         pos$iv$iv = nextSegmentOffset$iv$iv;
      }

      return result$iv;
   }

   @NotNull
   public ByteBuffer asByteBuffer() {
      ByteBuffer var10000 = ByteBuffer.wrap(this.toByteArray()).asReadOnlyBuffer();
      Intrinsics.checkNotNullExpressionValue(var10000, "ByteBuffer.wrap(toByteArray()).asReadOnlyBuffer()");
      return var10000;
   }

   public void write(@NotNull OutputStream out) throws IOException {
      Intrinsics.checkNotNullParameter(out, "out");
      SegmentedByteString $this$forEachSegment$iv = this;
      int $i$f$forEachSegment = false;
      int segmentCount$iv = ((Object[])this.getSegments$okio()).length;
      int s$iv = 0;

      for(int pos$iv = 0; s$iv < segmentCount$iv; ++s$iv) {
         int segmentPos$iv = $this$forEachSegment$iv.getDirectory$okio()[segmentCount$iv + s$iv];
         int nextSegmentOffset$iv = $this$forEachSegment$iv.getDirectory$okio()[s$iv];
         byte[] var10000 = $this$forEachSegment$iv.getSegments$okio()[s$iv];
         int byteCount = nextSegmentOffset$iv - pos$iv;
         byte[] data = var10000;
         int var12 = false;
         out.write(data, segmentPos$iv, byteCount);
         pos$iv = nextSegmentOffset$iv;
      }

   }

   public void write$okio(@NotNull Buffer buffer, int offset, int byteCount) {
      Intrinsics.checkNotNullParameter(buffer, "buffer");
      int $i$f$commonWrite = false;
      SegmentedByteString $this$forEachSegment$iv$iv = this;
      int endIndex$iv$iv = offset + byteCount;
      int $i$f$forEachSegment = false;
      int s$iv$iv = SegmentedByteStringKt.segment(this, offset);

      for(int pos$iv$iv = offset; pos$iv$iv < endIndex$iv$iv; ++s$iv$iv) {
         int segmentOffset$iv$iv = s$iv$iv == 0 ? 0 : $this$forEachSegment$iv$iv.getDirectory$okio()[s$iv$iv - 1];
         int segmentSize$iv$iv = $this$forEachSegment$iv$iv.getDirectory$okio()[s$iv$iv] - segmentOffset$iv$iv;
         int segmentPos$iv$iv = $this$forEachSegment$iv$iv.getDirectory$okio()[((Object[])$this$forEachSegment$iv$iv.getSegments$okio()).length + s$iv$iv];
         int offset$iv$iv = segmentOffset$iv$iv + segmentSize$iv$iv;
         boolean var15 = false;
         int byteCount$iv$iv = Math.min(endIndex$iv$iv, offset$iv$iv) - pos$iv$iv;
         offset$iv$iv = segmentPos$iv$iv + (pos$iv$iv - segmentOffset$iv$iv);
         byte[] data$iv = $this$forEachSegment$iv$iv.getSegments$okio()[s$iv$iv];
         int var20 = false;
         Segment segment$iv = new Segment(data$iv, offset$iv$iv, offset$iv$iv + byteCount$iv$iv, true, false);
         if (buffer.head == null) {
            segment$iv.prev = segment$iv;
            segment$iv.next = segment$iv.prev;
            buffer.head = segment$iv.next;
         } else {
            Segment var10000 = buffer.head;
            Intrinsics.checkNotNull(var10000);
            var10000 = var10000.prev;
            Intrinsics.checkNotNull(var10000);
            var10000.push(segment$iv);
         }

         pos$iv$iv += byteCount$iv$iv;
      }

      buffer.setSize$okio(buffer.size() + (long)this.size());
   }

   public boolean rangeEquals(int offset, @NotNull ByteString other, int otherOffset, int byteCount) {
      Intrinsics.checkNotNullParameter(other, "other");
      int $i$f$commonRangeEquals = false;
      boolean var10000;
      if (offset >= 0 && offset <= this.size() - byteCount) {
         int otherOffset$iv = otherOffset;
         SegmentedByteString $this$forEachSegment$iv$iv = this;
         int endIndex$iv$iv = offset + byteCount;
         int $i$f$forEachSegment = false;
         int s$iv$iv = SegmentedByteStringKt.segment(this, offset);

         for(int pos$iv$iv = offset; pos$iv$iv < endIndex$iv$iv; ++s$iv$iv) {
            int segmentOffset$iv$iv = s$iv$iv == 0 ? 0 : $this$forEachSegment$iv$iv.getDirectory$okio()[s$iv$iv - 1];
            int segmentSize$iv$iv = $this$forEachSegment$iv$iv.getDirectory$okio()[s$iv$iv] - segmentOffset$iv$iv;
            int segmentPos$iv$iv = $this$forEachSegment$iv$iv.getDirectory$okio()[((Object[])$this$forEachSegment$iv$iv.getSegments$okio()).length + s$iv$iv];
            int offset$iv$iv = segmentOffset$iv$iv + segmentSize$iv$iv;
            boolean var17 = false;
            int byteCount$iv$iv = Math.min(endIndex$iv$iv, offset$iv$iv) - pos$iv$iv;
            offset$iv$iv = segmentPos$iv$iv + (pos$iv$iv - segmentOffset$iv$iv);
            byte[] data$iv = $this$forEachSegment$iv$iv.getSegments$okio()[s$iv$iv];
            int var22 = false;
            if (!other.rangeEquals(otherOffset$iv, data$iv, offset$iv$iv, byteCount$iv$iv)) {
               var10000 = false;
               return var10000;
            }

            otherOffset$iv += byteCount$iv$iv;
            pos$iv$iv += byteCount$iv$iv;
         }

         var10000 = true;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public boolean rangeEquals(int offset, @NotNull byte[] other, int otherOffset, int byteCount) {
      Intrinsics.checkNotNullParameter(other, "other");
      int $i$f$commonRangeEquals = false;
      boolean var10000;
      if (offset >= 0 && offset <= this.size() - byteCount && otherOffset >= 0 && otherOffset <= other.length - byteCount) {
         int otherOffset$iv = otherOffset;
         SegmentedByteString $this$forEachSegment$iv$iv = this;
         int endIndex$iv$iv = offset + byteCount;
         int $i$f$forEachSegment = false;
         int s$iv$iv = SegmentedByteStringKt.segment(this, offset);

         for(int pos$iv$iv = offset; pos$iv$iv < endIndex$iv$iv; ++s$iv$iv) {
            int segmentOffset$iv$iv = s$iv$iv == 0 ? 0 : $this$forEachSegment$iv$iv.getDirectory$okio()[s$iv$iv - 1];
            int segmentSize$iv$iv = $this$forEachSegment$iv$iv.getDirectory$okio()[s$iv$iv] - segmentOffset$iv$iv;
            int segmentPos$iv$iv = $this$forEachSegment$iv$iv.getDirectory$okio()[((Object[])$this$forEachSegment$iv$iv.getSegments$okio()).length + s$iv$iv];
            int offset$iv$iv = segmentOffset$iv$iv + segmentSize$iv$iv;
            boolean var17 = false;
            int byteCount$iv$iv = Math.min(endIndex$iv$iv, offset$iv$iv) - pos$iv$iv;
            offset$iv$iv = segmentPos$iv$iv + (pos$iv$iv - segmentOffset$iv$iv);
            byte[] data$iv = $this$forEachSegment$iv$iv.getSegments$okio()[s$iv$iv];
            int var22 = false;
            if (!-Util.arrayRangeEquals(data$iv, offset$iv$iv, other, otherOffset$iv, byteCount$iv$iv)) {
               var10000 = false;
               return var10000;
            }

            otherOffset$iv += byteCount$iv$iv;
            pos$iv$iv += byteCount$iv$iv;
         }

         var10000 = true;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public int indexOf(@NotNull byte[] other, int fromIndex) {
      Intrinsics.checkNotNullParameter(other, "other");
      return this.toByteString().indexOf(other, fromIndex);
   }

   public int lastIndexOf(@NotNull byte[] other, int fromIndex) {
      Intrinsics.checkNotNullParameter(other, "other");
      return this.toByteString().lastIndexOf(other, fromIndex);
   }

   private final ByteString toByteString() {
      return new ByteString(this.toByteArray());
   }

   @NotNull
   public byte[] internalArray$okio() {
      return this.toByteArray();
   }

   public boolean equals(@Nullable Object other) {
      int $i$f$commonEquals = false;
      return other == this ? true : (other instanceof ByteString ? ((ByteString)other).size() == this.size() && this.rangeEquals(0, (ByteString)((ByteString)other), 0, this.size()) : false);
   }

   public int hashCode() {
      int $i$f$commonHashCode = false;
      int result$iv = this.getHashCode$okio();
      int var10000;
      if (result$iv != 0) {
         var10000 = result$iv;
      } else {
         result$iv = 1;
         SegmentedByteString $this$forEachSegment$iv$iv = this;
         int $i$f$forEachSegment = false;
         int segmentCount$iv$iv = ((Object[])this.getSegments$okio()).length;
         int s$iv$iv = 0;

         for(int pos$iv$iv = 0; s$iv$iv < segmentCount$iv$iv; ++s$iv$iv) {
            int segmentPos$iv$iv = $this$forEachSegment$iv$iv.getDirectory$okio()[segmentCount$iv$iv + s$iv$iv];
            int nextSegmentOffset$iv$iv = $this$forEachSegment$iv$iv.getDirectory$okio()[s$iv$iv];
            byte[] var17 = $this$forEachSegment$iv$iv.getSegments$okio()[s$iv$iv];
            int byteCount$iv = nextSegmentOffset$iv$iv - pos$iv$iv;
            byte[] data$iv = var17;
            int var14 = false;
            int i$iv = segmentPos$iv$iv;

            for(int limit$iv = segmentPos$iv$iv + byteCount$iv; i$iv < limit$iv; ++i$iv) {
               result$iv = 31 * result$iv + data$iv[i$iv];
            }

            pos$iv$iv = nextSegmentOffset$iv$iv;
         }

         this.setHashCode$okio(result$iv);
         var10000 = result$iv;
      }

      return var10000;
   }

   @NotNull
   public String toString() {
      return this.toByteString().toString();
   }

   private final Object writeReplace() {
      ByteString var10000 = this.toByteString();
      if (var10000 == null) {
         throw new NullPointerException("null cannot be cast to non-null type java.lang.Object");
      } else {
         return (Object)var10000;
      }
   }

   @NotNull
   public final byte[][] getSegments$okio() {
      return this.segments;
   }

   @NotNull
   public final int[] getDirectory$okio() {
      return this.directory;
   }

   public SegmentedByteString(@NotNull byte[][] segments, @NotNull int[] directory) {
      Intrinsics.checkNotNullParameter(segments, "segments");
      Intrinsics.checkNotNullParameter(directory, "directory");
      super(ByteString.EMPTY.getData$okio());
      this.segments = segments;
      this.directory = directory;
   }
}
