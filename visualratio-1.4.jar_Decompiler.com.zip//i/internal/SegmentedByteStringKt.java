package i.internal;

import i.-Util;
import i.Buffer;
import i.ByteString;
import i.Segment;
import i.SegmentedByteString;
import k.Metadata;
import k.Unit;
import k.collections.ArraysKt;
import k.jvm.functions.Function3;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 2,
   d1 = {"\u0000R\n\u0000\n\u0002\u0010\b\n\u0002\u0010\u0015\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0005\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a$\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0000\u001a\u0017\u0010\u0006\u001a\u00020\u0007*\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\nH\u0080\b\u001a\r\u0010\u000b\u001a\u00020\u0001*\u00020\bH\u0080\b\u001a\r\u0010\f\u001a\u00020\u0001*\u00020\bH\u0080\b\u001a\u0015\u0010\r\u001a\u00020\u000e*\u00020\b2\u0006\u0010\u000f\u001a\u00020\u0001H\u0080\b\u001a-\u0010\u0010\u001a\u00020\u0007*\u00020\b2\u0006\u0010\u0011\u001a\u00020\u00012\u0006\u0010\t\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00012\u0006\u0010\u0014\u001a\u00020\u0001H\u0080\b\u001a-\u0010\u0010\u001a\u00020\u0007*\u00020\b2\u0006\u0010\u0011\u001a\u00020\u00012\u0006\u0010\t\u001a\u00020\u00152\u0006\u0010\u0013\u001a\u00020\u00012\u0006\u0010\u0014\u001a\u00020\u0001H\u0080\b\u001a\u001d\u0010\u0016\u001a\u00020\u0015*\u00020\b2\u0006\u0010\u0017\u001a\u00020\u00012\u0006\u0010\u0018\u001a\u00020\u0001H\u0080\b\u001a\r\u0010\u0019\u001a\u00020\u0012*\u00020\bH\u0080\b\u001a%\u0010\u001a\u001a\u00020\u001b*\u00020\b2\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u0011\u001a\u00020\u00012\u0006\u0010\u0014\u001a\u00020\u0001H\u0080\b\u001a]\u0010\u001e\u001a\u00020\u001b*\u00020\b2K\u0010\u001f\u001aG\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b!\u0012\b\b\"\u0012\u0004\b\b(#\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b!\u0012\b\b\"\u0012\u0004\b\b(\u0011\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b!\u0012\b\b\"\u0012\u0004\b\b(\u0014\u0012\u0004\u0012\u00020\u001b0 H\u0080\bø\u0001\u0000\u001aj\u0010\u001e\u001a\u00020\u001b*\u00020\b2\u0006\u0010\u0017\u001a\u00020\u00012\u0006\u0010\u0018\u001a\u00020\u00012K\u0010\u001f\u001aG\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b!\u0012\b\b\"\u0012\u0004\b\b(#\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b!\u0012\b\b\"\u0012\u0004\b\b(\u0011\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b!\u0012\b\b\"\u0012\u0004\b\b(\u0014\u0012\u0004\u0012\u00020\u001b0 H\u0082\b\u001a\u0014\u0010$\u001a\u00020\u0001*\u00020\b2\u0006\u0010\u000f\u001a\u00020\u0001H\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006%"},
   d2 = {"binarySearch", "", "", "value", "fromIndex", "toIndex", "commonEquals", "", "Li/SegmentedByteString;", "other", "", "commonGetSize", "commonHashCode", "commonInternalGet", "", "pos", "commonRangeEquals", "offset", "", "otherOffset", "byteCount", "Li/ByteString;", "commonSubstring", "beginIndex", "endIndex", "commonToByteArray", "commonWrite", "", "buffer", "Li/Buffer;", "forEachSegment", "action", "Lk/Function3;", "Lk/ParameterName;", "name", "data", "segment", "i"}
)
public final class SegmentedByteStringKt {
   public static final int binarySearch(@NotNull int[] $this$binarySearch, int value, int fromIndex, int toIndex) {
      Intrinsics.checkNotNullParameter($this$binarySearch, "$this$binarySearch");
      int left = fromIndex;
      int right = toIndex - 1;

      while(left <= right) {
         int mid = left + right >>> 1;
         int midVal = $this$binarySearch[mid];
         if (midVal < value) {
            left = mid + 1;
         } else {
            if (midVal <= value) {
               return mid;
            }

            right = mid - 1;
         }
      }

      return -left - 1;
   }

   public static final int segment(@NotNull SegmentedByteString $this$segment, int pos) {
      Intrinsics.checkNotNullParameter($this$segment, "$this$segment");
      int i = binarySearch($this$segment.getDirectory$okio(), pos + 1, 0, ((Object[])$this$segment.getSegments$okio()).length);
      return i >= 0 ? i : ~i;
   }

   public static final void forEachSegment(@NotNull SegmentedByteString $this$forEachSegment, @NotNull Function3<? super byte[], ? super Integer, ? super Integer, Unit> action) {
      int $i$f$forEachSegment = 0;
      Intrinsics.checkNotNullParameter($this$forEachSegment, "$this$forEachSegment");
      Intrinsics.checkNotNullParameter(action, "action");
      int segmentCount = ((Object[])$this$forEachSegment.getSegments$okio()).length;
      int s = 0;

      for(int pos = 0; s < segmentCount; ++s) {
         int segmentPos = $this$forEachSegment.getDirectory$okio()[segmentCount + s];
         int nextSegmentOffset = $this$forEachSegment.getDirectory$okio()[s];
         action.invoke($this$forEachSegment.getSegments$okio()[s], segmentPos, nextSegmentOffset - pos);
         pos = nextSegmentOffset;
      }

   }

   private static final void forEachSegment(SegmentedByteString $this$forEachSegment, int beginIndex, int endIndex, Function3<? super byte[], ? super Integer, ? super Integer, Unit> action) {
      int $i$f$forEachSegment = 0;
      int s = segment($this$forEachSegment, beginIndex);

      for(int pos = beginIndex; pos < endIndex; ++s) {
         int segmentOffset = s == 0 ? 0 : $this$forEachSegment.getDirectory$okio()[s - 1];
         int segmentSize = $this$forEachSegment.getDirectory$okio()[s] - segmentOffset;
         int segmentPos = $this$forEachSegment.getDirectory$okio()[((Object[])$this$forEachSegment.getSegments$okio()).length + s];
         int offset = segmentOffset + segmentSize;
         boolean var12 = false;
         int byteCount = Math.min(endIndex, offset) - pos;
         offset = segmentPos + (pos - segmentOffset);
         action.invoke($this$forEachSegment.getSegments$okio()[s], offset, byteCount);
         pos += byteCount;
      }

   }

   @NotNull
   public static final ByteString commonSubstring(@NotNull SegmentedByteString $this$commonSubstring, int beginIndex, int endIndex) {
      int $i$f$commonSubstring = 0;
      Intrinsics.checkNotNullParameter($this$commonSubstring, "$this$commonSubstring");
      boolean var4 = beginIndex >= 0;
      boolean var5 = false;
      boolean var6 = false;
      boolean var7;
      String var17;
      if (!var4) {
         var7 = false;
         var17 = "beginIndex=" + beginIndex + " < 0";
         throw (Throwable)(new IllegalArgumentException(var17.toString()));
      } else {
         var4 = endIndex <= $this$commonSubstring.size();
         var5 = false;
         var6 = false;
         if (!var4) {
            var7 = false;
            var17 = "endIndex=" + endIndex + " > length(" + $this$commonSubstring.size() + ')';
            throw (Throwable)(new IllegalArgumentException(var17.toString()));
         } else {
            int subLen = endIndex - beginIndex;
            var5 = subLen >= 0;
            var6 = false;
            var7 = false;
            if (!var5) {
               int var21 = false;
               String var19 = "endIndex=" + endIndex + " < beginIndex=" + beginIndex;
               throw (Throwable)(new IllegalArgumentException(var19.toString()));
            } else if (beginIndex == 0 && endIndex == $this$commonSubstring.size()) {
               return (ByteString)$this$commonSubstring;
            } else if (beginIndex == endIndex) {
               return ByteString.EMPTY;
            } else {
               int beginSegment = segment($this$commonSubstring, beginIndex);
               int endSegment = segment($this$commonSubstring, endIndex - 1);
               Object[] var8 = (Object[])$this$commonSubstring.getSegments$okio();
               int index = endSegment + 1;
               boolean var10 = false;
               byte[][] newSegments = (byte[][])ArraysKt.copyOfRange(var8, beginSegment, index);
               int[] newDirectory = new int[((Object[])newSegments).length * 2];
               index = 0;
               int s = beginSegment;
               int var11 = endSegment;
               if (beginSegment <= endSegment) {
                  while(true) {
                     int var12 = $this$commonSubstring.getDirectory$okio()[s] - beginIndex;
                     boolean var13 = false;
                     newDirectory[index] = Math.min(var12, subLen);
                     newDirectory[index++ + ((Object[])newSegments).length] = $this$commonSubstring.getDirectory$okio()[s + ((Object[])$this$commonSubstring.getSegments$okio()).length];
                     if (s == var11) {
                        break;
                     }

                     ++s;
                  }
               }

               s = beginSegment == 0 ? 0 : $this$commonSubstring.getDirectory$okio()[beginSegment - 1];
               newDirectory[((Object[])newSegments).length] += beginIndex - s;
               return (ByteString)(new SegmentedByteString(newSegments, newDirectory));
            }
         }
      }
   }

   public static final byte commonInternalGet(@NotNull SegmentedByteString $this$commonInternalGet, int pos) {
      int $i$f$commonInternalGet = 0;
      Intrinsics.checkNotNullParameter($this$commonInternalGet, "$this$commonInternalGet");
      -Util.checkOffsetAndCount((long)$this$commonInternalGet.getDirectory$okio()[((Object[])$this$commonInternalGet.getSegments$okio()).length - 1], (long)pos, 1L);
      int segment = segment($this$commonInternalGet, pos);
      int segmentOffset = segment == 0 ? 0 : $this$commonInternalGet.getDirectory$okio()[segment - 1];
      int segmentPos = $this$commonInternalGet.getDirectory$okio()[segment + ((Object[])$this$commonInternalGet.getSegments$okio()).length];
      return $this$commonInternalGet.getSegments$okio()[segment][pos - segmentOffset + segmentPos];
   }

   public static final int commonGetSize(@NotNull SegmentedByteString $this$commonGetSize) {
      int $i$f$commonGetSize = 0;
      Intrinsics.checkNotNullParameter($this$commonGetSize, "$this$commonGetSize");
      return $this$commonGetSize.getDirectory$okio()[((Object[])$this$commonGetSize.getSegments$okio()).length - 1];
   }

   @NotNull
   public static final byte[] commonToByteArray(@NotNull SegmentedByteString $this$commonToByteArray) {
      int $i$f$commonToByteArray = 0;
      Intrinsics.checkNotNullParameter($this$commonToByteArray, "$this$commonToByteArray");
      byte[] result = new byte[$this$commonToByteArray.size()];
      int resultPos = 0;
      SegmentedByteString $this$forEachSegment$iv = $this$commonToByteArray;
      int $i$f$forEachSegment = false;
      int segmentCount$iv = ((Object[])$this$commonToByteArray.getSegments$okio()).length;
      int s$iv = 0;

      for(int pos$iv = 0; s$iv < segmentCount$iv; ++s$iv) {
         int segmentPos$iv = $this$forEachSegment$iv.getDirectory$okio()[segmentCount$iv + s$iv];
         int nextSegmentOffset$iv = $this$forEachSegment$iv.getDirectory$okio()[s$iv];
         byte[] var10000 = $this$forEachSegment$iv.getSegments$okio()[s$iv];
         int byteCount = nextSegmentOffset$iv - pos$iv;
         byte[] data = var10000;
         int var14 = false;
         ArraysKt.copyInto(data, result, resultPos, segmentPos$iv, segmentPos$iv + byteCount);
         resultPos += byteCount;
         pos$iv = nextSegmentOffset$iv;
      }

      return result;
   }

   public static final void commonWrite(@NotNull SegmentedByteString $this$commonWrite, @NotNull Buffer buffer, int offset, int byteCount) {
      int $i$f$commonWrite = 0;
      Intrinsics.checkNotNullParameter($this$commonWrite, "$this$commonWrite");
      Intrinsics.checkNotNullParameter(buffer, "buffer");
      SegmentedByteString $this$forEachSegment$iv = $this$commonWrite;
      int endIndex$iv = offset + byteCount;
      int $i$f$forEachSegment = false;
      int s$iv = segment($this$commonWrite, offset);

      for(int pos$iv = offset; pos$iv < endIndex$iv; ++s$iv) {
         int segmentOffset$iv = s$iv == 0 ? 0 : $this$forEachSegment$iv.getDirectory$okio()[s$iv - 1];
         int segmentSize$iv = $this$forEachSegment$iv.getDirectory$okio()[s$iv] - segmentOffset$iv;
         int segmentPos$iv = $this$forEachSegment$iv.getDirectory$okio()[((Object[])$this$forEachSegment$iv.getSegments$okio()).length + s$iv];
         int offset$iv = segmentOffset$iv + segmentSize$iv;
         boolean var14 = false;
         int byteCount$iv = Math.min(endIndex$iv, offset$iv) - pos$iv;
         offset$iv = segmentPos$iv + (pos$iv - segmentOffset$iv);
         byte[] data = $this$forEachSegment$iv.getSegments$okio()[s$iv];
         int var19 = false;
         Segment segment = new Segment(data, offset$iv, offset$iv + byteCount$iv, true, false);
         if (buffer.head == null) {
            segment.prev = segment;
            segment.next = segment.prev;
            buffer.head = segment.next;
         } else {
            Segment var10000 = buffer.head;
            Intrinsics.checkNotNull(var10000);
            var10000 = var10000.prev;
            Intrinsics.checkNotNull(var10000);
            var10000.push(segment);
         }

         pos$iv += byteCount$iv;
      }

      buffer.setSize$okio(buffer.size() + (long)$this$commonWrite.size());
   }

   public static final boolean commonRangeEquals(@NotNull SegmentedByteString $this$commonRangeEquals, int offset, @NotNull ByteString other, int otherOffset, int byteCount) {
      int $i$f$commonRangeEquals = 0;
      Intrinsics.checkNotNullParameter($this$commonRangeEquals, "$this$commonRangeEquals");
      Intrinsics.checkNotNullParameter(other, "other");
      if (offset >= 0 && offset <= $this$commonRangeEquals.size() - byteCount) {
         int otherOffset = otherOffset;
         SegmentedByteString $this$forEachSegment$iv = $this$commonRangeEquals;
         int endIndex$iv = offset + byteCount;
         int $i$f$forEachSegment = false;
         int s$iv = segment($this$commonRangeEquals, offset);

         for(int pos$iv = offset; pos$iv < endIndex$iv; ++s$iv) {
            int segmentOffset$iv = s$iv == 0 ? 0 : $this$forEachSegment$iv.getDirectory$okio()[s$iv - 1];
            int segmentSize$iv = $this$forEachSegment$iv.getDirectory$okio()[s$iv] - segmentOffset$iv;
            int segmentPos$iv = $this$forEachSegment$iv.getDirectory$okio()[((Object[])$this$forEachSegment$iv.getSegments$okio()).length + s$iv];
            int offset$iv = segmentOffset$iv + segmentSize$iv;
            boolean var16 = false;
            int byteCount$iv = Math.min(endIndex$iv, offset$iv) - pos$iv;
            offset$iv = segmentPos$iv + (pos$iv - segmentOffset$iv);
            byte[] data = $this$forEachSegment$iv.getSegments$okio()[s$iv];
            int var21 = false;
            if (!other.rangeEquals(otherOffset, data, offset$iv, byteCount$iv)) {
               return false;
            }

            otherOffset += byteCount$iv;
            pos$iv += byteCount$iv;
         }

         return true;
      } else {
         return false;
      }
   }

   public static final boolean commonRangeEquals(@NotNull SegmentedByteString $this$commonRangeEquals, int offset, @NotNull byte[] other, int otherOffset, int byteCount) {
      int $i$f$commonRangeEquals = 0;
      Intrinsics.checkNotNullParameter($this$commonRangeEquals, "$this$commonRangeEquals");
      Intrinsics.checkNotNullParameter(other, "other");
      if (offset >= 0 && offset <= $this$commonRangeEquals.size() - byteCount && otherOffset >= 0 && otherOffset <= other.length - byteCount) {
         int otherOffset = otherOffset;
         SegmentedByteString $this$forEachSegment$iv = $this$commonRangeEquals;
         int endIndex$iv = offset + byteCount;
         int $i$f$forEachSegment = false;
         int s$iv = segment($this$commonRangeEquals, offset);

         for(int pos$iv = offset; pos$iv < endIndex$iv; ++s$iv) {
            int segmentOffset$iv = s$iv == 0 ? 0 : $this$forEachSegment$iv.getDirectory$okio()[s$iv - 1];
            int segmentSize$iv = $this$forEachSegment$iv.getDirectory$okio()[s$iv] - segmentOffset$iv;
            int segmentPos$iv = $this$forEachSegment$iv.getDirectory$okio()[((Object[])$this$forEachSegment$iv.getSegments$okio()).length + s$iv];
            int offset$iv = segmentOffset$iv + segmentSize$iv;
            boolean var16 = false;
            int byteCount$iv = Math.min(endIndex$iv, offset$iv) - pos$iv;
            offset$iv = segmentPos$iv + (pos$iv - segmentOffset$iv);
            byte[] data = $this$forEachSegment$iv.getSegments$okio()[s$iv];
            int var21 = false;
            if (!-Util.arrayRangeEquals(data, offset$iv, other, otherOffset, byteCount$iv)) {
               return false;
            }

            otherOffset += byteCount$iv;
            pos$iv += byteCount$iv;
         }

         return true;
      } else {
         return false;
      }
   }

   public static final boolean commonEquals(@NotNull SegmentedByteString $this$commonEquals, @Nullable Object other) {
      int $i$f$commonEquals = 0;
      Intrinsics.checkNotNullParameter($this$commonEquals, "$this$commonEquals");
      return other == $this$commonEquals ? true : (other instanceof ByteString ? ((ByteString)other).size() == $this$commonEquals.size() && $this$commonEquals.rangeEquals(0, (ByteString)((ByteString)other), 0, $this$commonEquals.size()) : false);
   }

   public static final int commonHashCode(@NotNull SegmentedByteString $this$commonHashCode) {
      int $i$f$commonHashCode = 0;
      Intrinsics.checkNotNullParameter($this$commonHashCode, "$this$commonHashCode");
      int result = $this$commonHashCode.getHashCode$okio();
      if (result != 0) {
         return result;
      } else {
         result = 1;
         SegmentedByteString $this$forEachSegment$iv = $this$commonHashCode;
         int $i$f$forEachSegment = false;
         int segmentCount$iv = ((Object[])$this$commonHashCode.getSegments$okio()).length;
         int s$iv = 0;

         for(int pos$iv = 0; s$iv < segmentCount$iv; ++s$iv) {
            int segmentPos$iv = $this$forEachSegment$iv.getDirectory$okio()[segmentCount$iv + s$iv];
            int nextSegmentOffset$iv = $this$forEachSegment$iv.getDirectory$okio()[s$iv];
            byte[] var10000 = $this$forEachSegment$iv.getSegments$okio()[s$iv];
            int byteCount = nextSegmentOffset$iv - pos$iv;
            byte[] data = var10000;
            int var13 = false;
            int i = segmentPos$iv;

            for(int limit = segmentPos$iv + byteCount; i < limit; ++i) {
               result = 31 * result + data[i];
            }

            pos$iv = nextSegmentOffset$iv;
         }

         $this$commonHashCode.setHashCode$okio(result);
         return result;
      }
   }

   // $FF: synthetic method
   public static final void access$forEachSegment(SegmentedByteString $this$access_u24forEachSegment, int beginIndex, int endIndex, Function3 action) {
      forEachSegment($this$access_u24forEachSegment, beginIndex, endIndex, action);
   }
}
