package i;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import k.Metadata;
import k.jvm.JvmName;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0016\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0002\u0010\u0003J\b\u0010\u0006\u001a\u00020\u0001H\u0016J\b\u0010\u0007\u001a\u00020\u0001H\u0016J\b\u0010\b\u001a\u00020\tH\u0016J\u0010\u0010\b\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\tH\u0016J\b\u0010\n\u001a\u00020\u000bH\u0016J\u000e\u0010\u0005\u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0001J\b\u0010\f\u001a\u00020\rH\u0016J\u0018\u0010\u000e\u001a\u00020\u00012\u0006\u0010\u000e\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016J\b\u0010\u0011\u001a\u00020\tH\u0016R\u001c\u0010\u0002\u001a\u00020\u00018\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0002\u0010\u0004\"\u0004\b\u0005\u0010\u0003¨\u0006\u0012"},
   d2 = {"Li/ForwardingTimeout;", "Li/Timeout;", "delegate", "(Lokio/Timeout;)V", "()Lokio/Timeout;", "setDelegate", "clearDeadline", "clearTimeout", "deadlineNanoTime", "", "hasDeadline", "", "throwIfReached", "", "timeout", "unit", "Ljava/util/concurrent/TimeUnit;", "timeoutNanos", "i"}
)
public class ForwardingTimeout extends Timeout {
   @NotNull
   private Timeout delegate;

   @NotNull
   public final ForwardingTimeout setDelegate(@NotNull Timeout delegate) {
      Intrinsics.checkNotNullParameter(delegate, "delegate");
      this.delegate = delegate;
      return this;
   }

   @NotNull
   public Timeout timeout(long timeout, @NotNull TimeUnit unit) {
      Intrinsics.checkNotNullParameter(unit, "unit");
      return this.delegate.timeout(timeout, unit);
   }

   public long timeoutNanos() {
      return this.delegate.timeoutNanos();
   }

   public boolean hasDeadline() {
      return this.delegate.hasDeadline();
   }

   public long deadlineNanoTime() {
      return this.delegate.deadlineNanoTime();
   }

   @NotNull
   public Timeout deadlineNanoTime(long deadlineNanoTime) {
      return this.delegate.deadlineNanoTime(deadlineNanoTime);
   }

   @NotNull
   public Timeout clearTimeout() {
      return this.delegate.clearTimeout();
   }

   @NotNull
   public Timeout clearDeadline() {
      return this.delegate.clearDeadline();
   }

   public void throwIfReached() throws IOException {
      this.delegate.throwIfReached();
   }

   @JvmName(
      name = "delegate"
   )
   @NotNull
   public final Timeout delegate() {
      return this.delegate;
   }

   // $FF: synthetic method
   public final void setDelegate(@NotNull Timeout var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.delegate = var1;
   }

   public ForwardingTimeout(@NotNull Timeout delegate) {
      Intrinsics.checkNotNullParameter(delegate, "delegate");
      super();
      this.delegate = delegate;
   }
}
