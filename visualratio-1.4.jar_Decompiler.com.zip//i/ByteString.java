package i;

import i.internal.ByteStringKt;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import k.Deprecated;
import k.DeprecationLevel;
import k.Metadata;
import k.ReplaceWith;
import k.collections.ArraysKt;
import k.jvm.JvmField;
import k.jvm.JvmName;
import k.jvm.JvmOverloads;
import k.jvm.JvmStatic;
import k.jvm.internal.DefaultConstructorMarker;
import k.jvm.internal.Intrinsics;
import k.text.Charsets;
import k.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u0000p\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0005\n\u0002\b\u001a\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0016\u0018\u0000 Z2\u00020\u00012\b\u0012\u0004\u0012\u00020\u00000\u0002:\u0001ZB\u000f\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005J\b\u0010\u0015\u001a\u00020\u0016H\u0016J\b\u0010\u0017\u001a\u00020\u0010H\u0016J\b\u0010\u0018\u001a\u00020\u0010H\u0016J\u0011\u0010\u0019\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\u0000H\u0096\u0002J\u0015\u0010\u001b\u001a\u00020\u00002\u0006\u0010\u001c\u001a\u00020\u0010H\u0010¢\u0006\u0002\b\u001dJ\u000e\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u0004J\u000e\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u0000J\u0013\u0010!\u001a\u00020\u001f2\b\u0010\u001a\u001a\u0004\u0018\u00010\"H\u0096\u0002J\u0016\u0010#\u001a\u00020$2\u0006\u0010%\u001a\u00020\tH\u0087\u0002¢\u0006\u0002\b&J\u0015\u0010&\u001a\u00020$2\u0006\u0010%\u001a\u00020\tH\u0007¢\u0006\u0002\b'J\r\u0010(\u001a\u00020\tH\u0010¢\u0006\u0002\b)J\b\u0010\b\u001a\u00020\tH\u0016J\b\u0010*\u001a\u00020\u0010H\u0016J\u001d\u0010+\u001a\u00020\u00002\u0006\u0010\u001c\u001a\u00020\u00102\u0006\u0010,\u001a\u00020\u0000H\u0010¢\u0006\u0002\b-J\u0010\u0010.\u001a\u00020\u00002\u0006\u0010,\u001a\u00020\u0000H\u0016J\u0010\u0010/\u001a\u00020\u00002\u0006\u0010,\u001a\u00020\u0000H\u0016J\u0010\u00100\u001a\u00020\u00002\u0006\u0010,\u001a\u00020\u0000H\u0016J\u001a\u00101\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\u00042\b\b\u0002\u00102\u001a\u00020\tH\u0017J\u001a\u00101\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\u00002\b\b\u0002\u00102\u001a\u00020\tH\u0007J\r\u00103\u001a\u00020\u0004H\u0010¢\u0006\u0002\b4J\u0015\u00105\u001a\u00020$2\u0006\u00106\u001a\u00020\tH\u0010¢\u0006\u0002\b7J\u001a\u00108\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\u00042\b\b\u0002\u00102\u001a\u00020\tH\u0017J\u001a\u00108\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\u00002\b\b\u0002\u00102\u001a\u00020\tH\u0007J\b\u00109\u001a\u00020\u0000H\u0016J(\u0010:\u001a\u00020\u001f2\u0006\u0010;\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\u00042\u0006\u0010<\u001a\u00020\t2\u0006\u0010=\u001a\u00020\tH\u0016J(\u0010:\u001a\u00020\u001f2\u0006\u0010;\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\u00002\u0006\u0010<\u001a\u00020\t2\u0006\u0010=\u001a\u00020\tH\u0016J\u0010\u0010>\u001a\u00020?2\u0006\u0010@\u001a\u00020AH\u0002J\b\u0010B\u001a\u00020\u0000H\u0016J\b\u0010C\u001a\u00020\u0000H\u0016J\b\u0010D\u001a\u00020\u0000H\u0016J\r\u0010\u000e\u001a\u00020\tH\u0007¢\u0006\u0002\bEJ\u000e\u0010F\u001a\u00020\u001f2\u0006\u0010G\u001a\u00020\u0004J\u000e\u0010F\u001a\u00020\u001f2\u0006\u0010G\u001a\u00020\u0000J\u0010\u0010H\u001a\u00020\u00102\u0006\u0010I\u001a\u00020JH\u0016J\u001c\u0010K\u001a\u00020\u00002\b\b\u0002\u0010L\u001a\u00020\t2\b\b\u0002\u0010M\u001a\u00020\tH\u0017J\b\u0010N\u001a\u00020\u0000H\u0016J\b\u0010O\u001a\u00020\u0000H\u0016J\b\u0010P\u001a\u00020\u0004H\u0016J\b\u0010Q\u001a\u00020\u0010H\u0016J\b\u0010\u000f\u001a\u00020\u0010H\u0016J\u0010\u0010R\u001a\u00020?2\u0006\u0010S\u001a\u00020TH\u0016J%\u0010R\u001a\u00020?2\u0006\u0010U\u001a\u00020V2\u0006\u0010;\u001a\u00020\t2\u0006\u0010=\u001a\u00020\tH\u0010¢\u0006\u0002\bWJ\u0010\u0010X\u001a\u00020?2\u0006\u0010S\u001a\u00020YH\u0002R\u0014\u0010\u0003\u001a\u00020\u0004X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u001a\u0010\b\u001a\u00020\tX\u0080\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u0011\u0010\u000e\u001a\u00020\t8G¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000bR\u001c\u0010\u000f\u001a\u0004\u0018\u00010\u0010X\u0080\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014¨\u0006["},
   d2 = {"Li/ByteString;", "Ljava/io/Serializable;", "", "data", "", "([B)V", "getData$okio", "()[B", "hashCode", "", "getHashCode$okio", "()I", "setHashCode$okio", "(I)V", "size", "utf8", "", "getUtf8$okio", "()Ljava/lang/String;", "setUtf8$okio", "(Ljava/lang/String;)V", "asByteBuffer", "Ljava/nio/ByteBuffer;", "base64", "base64Url", "compareTo", "other", "digest", "algorithm", "digest$okio", "endsWith", "", "suffix", "equals", "", "get", "", "index", "getByte", "-deprecated_getByte", "getSize", "getSize$okio", "hex", "hmac", "key", "hmac$okio", "hmacSha1", "hmacSha256", "hmacSha512", "indexOf", "fromIndex", "internalArray", "internalArray$okio", "internalGet", "pos", "internalGet$okio", "lastIndexOf", "md5", "rangeEquals", "offset", "otherOffset", "byteCount", "readObject", "", "in", "Ljava/io/ObjectInputStream;", "sha1", "sha256", "sha512", "-deprecated_size", "startsWith", "prefix", "string", "charset", "Ljava/nio/charset/Charset;", "substring", "beginIndex", "endIndex", "toAsciiLowercase", "toAsciiUppercase", "toByteArray", "toString", "write", "out", "Ljava/io/OutputStream;", "buffer", "Li/Buffer;", "write$okio", "writeObject", "Ljava/io/ObjectOutputStream;", "Companion", "i"}
)
public class ByteString implements Serializable, Comparable<ByteString> {
   private transient int hashCode;
   @Nullable
   private transient String utf8;
   @NotNull
   private final byte[] data;
   private static final long serialVersionUID = 1L;
   @JvmField
   @NotNull
   public static final ByteString EMPTY = new ByteString(new byte[0]);
   public static final ByteString.Companion Companion = new ByteString.Companion((DefaultConstructorMarker)null);

   public final int getHashCode$okio() {
      return this.hashCode;
   }

   public final void setHashCode$okio(int var1) {
      this.hashCode = var1;
   }

   @Nullable
   public final String getUtf8$okio() {
      return this.utf8;
   }

   public final void setUtf8$okio(@Nullable String var1) {
      this.utf8 = var1;
   }

   @NotNull
   public String utf8() {
      int $i$f$commonUtf8 = false;
      String result$iv = this.getUtf8$okio();
      if (result$iv == null) {
         result$iv = -Platform.toUtf8String(this.internalArray$okio());
         this.setUtf8$okio(result$iv);
      }

      return result$iv;
   }

   @NotNull
   public String string(@NotNull Charset charset) {
      Intrinsics.checkNotNullParameter(charset, "charset");
      byte[] var2 = this.data;
      boolean var3 = false;
      return new String(var2, charset);
   }

   @NotNull
   public String base64() {
      int $i$f$commonBase64 = false;
      return -Base64.encodeBase64$default(this.getData$okio(), (byte[])null, 1, (Object)null);
   }

   @NotNull
   public ByteString md5() {
      return this.digest$okio("MD5");
   }

   @NotNull
   public ByteString sha1() {
      return this.digest$okio("SHA-1");
   }

   @NotNull
   public ByteString sha256() {
      return this.digest$okio("SHA-256");
   }

   @NotNull
   public ByteString sha512() {
      return this.digest$okio("SHA-512");
   }

   @NotNull
   public ByteString digest$okio(@NotNull String algorithm) {
      Intrinsics.checkNotNullParameter(algorithm, "algorithm");
      byte[] var10002 = MessageDigest.getInstance(algorithm).digest(this.data);
      Intrinsics.checkNotNullExpressionValue(var10002, "MessageDigest.getInstance(algorithm).digest(data)");
      return new ByteString(var10002);
   }

   @NotNull
   public ByteString hmacSha1(@NotNull ByteString key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.hmac$okio("HmacSHA1", key);
   }

   @NotNull
   public ByteString hmacSha256(@NotNull ByteString key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.hmac$okio("HmacSHA256", key);
   }

   @NotNull
   public ByteString hmacSha512(@NotNull ByteString key) {
      Intrinsics.checkNotNullParameter(key, "key");
      return this.hmac$okio("HmacSHA512", key);
   }

   @NotNull
   public ByteString hmac$okio(@NotNull String algorithm, @NotNull ByteString key) {
      Intrinsics.checkNotNullParameter(algorithm, "algorithm");
      Intrinsics.checkNotNullParameter(key, "key");

      try {
         Mac mac = Mac.getInstance(algorithm);
         mac.init((Key)(new SecretKeySpec(key.toByteArray(), algorithm)));
         byte[] var10002 = mac.doFinal(this.data);
         Intrinsics.checkNotNullExpressionValue(var10002, "mac.doFinal(data)");
         return new ByteString(var10002);
      } catch (InvalidKeyException var4) {
         throw (Throwable)(new IllegalArgumentException((Throwable)var4));
      }
   }

   @NotNull
   public String base64Url() {
      int $i$f$commonBase64Url = false;
      return -Base64.encodeBase64(this.getData$okio(), -Base64.getBASE64_URL_SAFE());
   }

   @NotNull
   public String hex() {
      int $i$f$commonHex = false;
      char[] result$iv = new char[this.getData$okio().length * 2];
      int c$iv = 0;
      byte[] var5 = this.getData$okio();
      int var6 = var5.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         byte b$iv = var5[var7];
         int var10001 = c$iv++;
         char[] var10002 = ByteStringKt.getHEX_DIGIT_CHARS();
         int other$iv$iv = 4;
         int $i$f$and = false;
         result$iv[var10001] = var10002[b$iv >> other$iv$iv & 15];
         var10001 = c$iv++;
         var10002 = ByteStringKt.getHEX_DIGIT_CHARS();
         other$iv$iv = 15;
         $i$f$and = false;
         result$iv[var10001] = var10002[b$iv & other$iv$iv];
      }

      boolean var12 = false;
      return new String(result$iv);
   }

   @NotNull
   public ByteString toAsciiLowercase() {
      ByteString $this$commonToAsciiLowercase$iv = this;
      int $i$f$commonToAsciiLowercase = false;

      ByteString var8;
      for(int i$iv = 0; i$iv < $this$commonToAsciiLowercase$iv.getData$okio().length; ++i$iv) {
         byte c$iv = $this$commonToAsciiLowercase$iv.getData$okio()[i$iv];
         if (c$iv >= (byte)65 && c$iv <= (byte)90) {
            byte[] var5 = $this$commonToAsciiLowercase$iv.getData$okio();
            boolean var6 = false;
            byte[] var10000 = Arrays.copyOf(var5, var5.length);
            Intrinsics.checkNotNullExpressionValue(var10000, "java.util.Arrays.copyOf(this, size)");
            byte[] lowercase$iv = var10000;
            lowercase$iv[i$iv++] = (byte)(c$iv - -32);

            while(true) {
               while(i$iv < lowercase$iv.length) {
                  c$iv = lowercase$iv[i$iv];
                  if (c$iv >= (byte)65 && c$iv <= (byte)90) {
                     lowercase$iv[i$iv] = (byte)(c$iv - -32);
                     ++i$iv;
                  } else {
                     ++i$iv;
                  }
               }

               var8 = new ByteString(lowercase$iv);
               return var8;
            }
         }
      }

      var8 = $this$commonToAsciiLowercase$iv;
      return var8;
   }

   @NotNull
   public ByteString toAsciiUppercase() {
      ByteString $this$commonToAsciiUppercase$iv = this;
      int $i$f$commonToAsciiUppercase = false;

      ByteString var8;
      for(int i$iv = 0; i$iv < $this$commonToAsciiUppercase$iv.getData$okio().length; ++i$iv) {
         byte c$iv = $this$commonToAsciiUppercase$iv.getData$okio()[i$iv];
         if (c$iv >= (byte)97 && c$iv <= (byte)122) {
            byte[] var5 = $this$commonToAsciiUppercase$iv.getData$okio();
            boolean var6 = false;
            byte[] var10000 = Arrays.copyOf(var5, var5.length);
            Intrinsics.checkNotNullExpressionValue(var10000, "java.util.Arrays.copyOf(this, size)");
            byte[] lowercase$iv = var10000;
            lowercase$iv[i$iv++] = (byte)(c$iv - 32);

            while(true) {
               while(i$iv < lowercase$iv.length) {
                  c$iv = lowercase$iv[i$iv];
                  if (c$iv >= (byte)97 && c$iv <= (byte)122) {
                     lowercase$iv[i$iv] = (byte)(c$iv - 32);
                     ++i$iv;
                  } else {
                     ++i$iv;
                  }
               }

               var8 = new ByteString(lowercase$iv);
               return var8;
            }
         }
      }

      var8 = $this$commonToAsciiUppercase$iv;
      return var8;
   }

   @JvmOverloads
   @NotNull
   public ByteString substring(int beginIndex, int endIndex) {
      int $i$f$commonSubstring = false;
      boolean var5 = beginIndex >= 0;
      boolean var6 = false;
      boolean var7 = false;
      boolean var8;
      String var12;
      if (!var5) {
         var8 = false;
         var12 = "beginIndex < 0";
         throw (Throwable)(new IllegalArgumentException(var12.toString()));
      } else {
         var5 = endIndex <= this.getData$okio().length;
         var6 = false;
         var7 = false;
         if (!var5) {
            var8 = false;
            var12 = "endIndex > length(" + this.getData$okio().length + ')';
            throw (Throwable)(new IllegalArgumentException(var12.toString()));
         } else {
            int subLen$iv = endIndex - beginIndex;
            var6 = subLen$iv >= 0;
            var7 = false;
            var8 = false;
            if (!var6) {
               int var9 = false;
               String var13 = "endIndex < beginIndex";
               throw (Throwable)(new IllegalArgumentException(var13.toString()));
            } else {
               ByteString var10000;
               if (beginIndex == 0 && endIndex == this.getData$okio().length) {
                  var10000 = this;
               } else {
                  byte[] var11 = this.getData$okio();
                  var7 = false;
                  var10000 = new ByteString(ArraysKt.copyOfRange(var11, beginIndex, endIndex));
               }

               return var10000;
            }
         }
      }
   }

   // $FF: synthetic method
   public static ByteString substring$default(ByteString var0, int var1, int var2, int var3, Object var4) {
      if (var4 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: substring");
      } else {
         if ((var3 & 1) != 0) {
            var1 = 0;
         }

         if ((var3 & 2) != 0) {
            var2 = var0.size();
         }

         return var0.substring(var1, var2);
      }
   }

   @JvmOverloads
   @NotNull
   public final ByteString substring(int beginIndex) {
      return substring$default(this, beginIndex, 0, 2, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final ByteString substring() {
      return substring$default(this, 0, 0, 3, (Object)null);
   }

   public byte internalGet$okio(int pos) {
      int $i$f$commonGetByte = false;
      return this.getData$okio()[pos];
   }

   @JvmName(
      name = "getByte"
   )
   public final byte getByte(int index) {
      return this.internalGet$okio(index);
   }

   @JvmName(
      name = "size"
   )
   public final int size() {
      return this.getSize$okio();
   }

   public int getSize$okio() {
      int $i$f$commonGetSize = false;
      return this.getData$okio().length;
   }

   @NotNull
   public byte[] toByteArray() {
      int $i$f$commonToByteArray = false;
      byte[] var3 = this.getData$okio();
      boolean var4 = false;
      byte[] var10000 = Arrays.copyOf(var3, var3.length);
      Intrinsics.checkNotNullExpressionValue(var10000, "java.util.Arrays.copyOf(this, size)");
      return var10000;
   }

   @NotNull
   public byte[] internalArray$okio() {
      int $i$f$commonInternalArray = false;
      return this.getData$okio();
   }

   @NotNull
   public ByteBuffer asByteBuffer() {
      ByteBuffer var10000 = ByteBuffer.wrap(this.data).asReadOnlyBuffer();
      Intrinsics.checkNotNullExpressionValue(var10000, "ByteBuffer.wrap(data).asReadOnlyBuffer()");
      return var10000;
   }

   public void write(@NotNull OutputStream out) throws IOException {
      Intrinsics.checkNotNullParameter(out, "out");
      out.write(this.data);
   }

   public void write$okio(@NotNull Buffer buffer, int offset, int byteCount) {
      Intrinsics.checkNotNullParameter(buffer, "buffer");
      ByteStringKt.commonWrite(this, buffer, offset, byteCount);
   }

   public boolean rangeEquals(int offset, @NotNull ByteString other, int otherOffset, int byteCount) {
      Intrinsics.checkNotNullParameter(other, "other");
      int $i$f$commonRangeEquals = false;
      return other.rangeEquals(otherOffset, this.getData$okio(), offset, byteCount);
   }

   public boolean rangeEquals(int offset, @NotNull byte[] other, int otherOffset, int byteCount) {
      Intrinsics.checkNotNullParameter(other, "other");
      int $i$f$commonRangeEquals = false;
      return offset >= 0 && offset <= this.getData$okio().length - byteCount && otherOffset >= 0 && otherOffset <= other.length - byteCount && -Util.arrayRangeEquals(this.getData$okio(), offset, other, otherOffset, byteCount);
   }

   public final boolean startsWith(@NotNull ByteString prefix) {
      Intrinsics.checkNotNullParameter(prefix, "prefix");
      int $i$f$commonStartsWith = false;
      return this.rangeEquals(0, (ByteString)prefix, 0, prefix.size());
   }

   public final boolean startsWith(@NotNull byte[] prefix) {
      Intrinsics.checkNotNullParameter(prefix, "prefix");
      int $i$f$commonStartsWith = false;
      return this.rangeEquals(0, (byte[])prefix, 0, prefix.length);
   }

   public final boolean endsWith(@NotNull ByteString suffix) {
      Intrinsics.checkNotNullParameter(suffix, "suffix");
      int $i$f$commonEndsWith = false;
      return this.rangeEquals(this.size() - suffix.size(), (ByteString)suffix, 0, suffix.size());
   }

   public final boolean endsWith(@NotNull byte[] suffix) {
      Intrinsics.checkNotNullParameter(suffix, "suffix");
      int $i$f$commonEndsWith = false;
      return this.rangeEquals(this.size() - suffix.length, (byte[])suffix, 0, suffix.length);
   }

   @JvmOverloads
   public final int indexOf(@NotNull ByteString other, int fromIndex) {
      Intrinsics.checkNotNullParameter(other, "other");
      return this.indexOf(other.internalArray$okio(), fromIndex);
   }

   // $FF: synthetic method
   public static int indexOf$default(ByteString var0, ByteString var1, int var2, int var3, Object var4) {
      if (var4 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: indexOf");
      } else {
         if ((var3 & 2) != 0) {
            var2 = 0;
         }

         return var0.indexOf(var1, var2);
      }
   }

   @JvmOverloads
   public final int indexOf(@NotNull ByteString other) {
      return indexOf$default(this, (ByteString)other, 0, 2, (Object)null);
   }

   @JvmOverloads
   public int indexOf(@NotNull byte[] other, int fromIndex) {
      Intrinsics.checkNotNullParameter(other, "other");
      ByteString $this$commonIndexOf$iv = this;
      int $i$f$commonIndexOf = false;
      int limit$iv = this.getData$okio().length - other.length;
      byte var6 = 0;
      boolean var7 = false;
      int i$iv = Math.max(fromIndex, var6);
      int var9 = limit$iv;
      int var10000;
      if (i$iv <= limit$iv) {
         while(true) {
            if (-Util.arrayRangeEquals($this$commonIndexOf$iv.getData$okio(), i$iv, other, 0, other.length)) {
               var10000 = i$iv;
               return var10000;
            }

            if (i$iv == var9) {
               break;
            }

            ++i$iv;
         }
      }

      var10000 = -1;
      return var10000;
   }

   // $FF: synthetic method
   public static int indexOf$default(ByteString var0, byte[] var1, int var2, int var3, Object var4) {
      if (var4 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: indexOf");
      } else {
         if ((var3 & 2) != 0) {
            var2 = 0;
         }

         return var0.indexOf(var1, var2);
      }
   }

   @JvmOverloads
   public final int indexOf(@NotNull byte[] other) {
      return indexOf$default(this, (byte[])other, 0, 2, (Object)null);
   }

   @JvmOverloads
   public final int lastIndexOf(@NotNull ByteString other, int fromIndex) {
      Intrinsics.checkNotNullParameter(other, "other");
      int $i$f$commonLastIndexOf = false;
      return this.lastIndexOf(other.internalArray$okio(), fromIndex);
   }

   // $FF: synthetic method
   public static int lastIndexOf$default(ByteString var0, ByteString var1, int var2, int var3, Object var4) {
      if (var4 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: lastIndexOf");
      } else {
         if ((var3 & 2) != 0) {
            var2 = var0.size();
         }

         return var0.lastIndexOf(var1, var2);
      }
   }

   @JvmOverloads
   public final int lastIndexOf(@NotNull ByteString other) {
      return lastIndexOf$default(this, (ByteString)other, 0, 2, (Object)null);
   }

   @JvmOverloads
   public int lastIndexOf(@NotNull byte[] other, int fromIndex) {
      Intrinsics.checkNotNullParameter(other, "other");
      ByteString $this$commonLastIndexOf$iv = this;
      int $i$f$commonLastIndexOf = false;
      int limit$iv = this.getData$okio().length - other.length;
      boolean var6 = false;
      int i$iv = Math.min(fromIndex, limit$iv);
      boolean var8 = false;

      int var10000;
      while(true) {
         if (i$iv < 0) {
            var10000 = -1;
            break;
         }

         if (-Util.arrayRangeEquals($this$commonLastIndexOf$iv.getData$okio(), i$iv, other, 0, other.length)) {
            var10000 = i$iv;
            break;
         }

         --i$iv;
      }

      return var10000;
   }

   // $FF: synthetic method
   public static int lastIndexOf$default(ByteString var0, byte[] var1, int var2, int var3, Object var4) {
      if (var4 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: lastIndexOf");
      } else {
         if ((var3 & 2) != 0) {
            var2 = var0.size();
         }

         return var0.lastIndexOf(var1, var2);
      }
   }

   @JvmOverloads
   public final int lastIndexOf(@NotNull byte[] other) {
      return lastIndexOf$default(this, (byte[])other, 0, 2, (Object)null);
   }

   public boolean equals(@Nullable Object other) {
      int $i$f$commonEquals = false;
      return other == this ? true : (other instanceof ByteString ? ((ByteString)other).size() == this.getData$okio().length && ((ByteString)other).rangeEquals(0, (byte[])this.getData$okio(), 0, this.getData$okio().length) : false);
   }

   public int hashCode() {
      int $i$f$commonHashCode = false;
      int result$iv = this.getHashCode$okio();
      int var10000;
      if (result$iv != 0) {
         var10000 = result$iv;
      } else {
         byte[] var4 = this.getData$okio();
         boolean var5 = false;
         int var9 = Arrays.hashCode(var4);
         var5 = false;
         boolean var6 = false;
         int var8 = false;
         this.setHashCode$okio(var9);
         var10000 = var9;
      }

      return var10000;
   }

   public int compareTo(@NotNull ByteString other) {
      Intrinsics.checkNotNullParameter(other, "other");
      ByteString $this$commonCompareTo$iv = this;
      int $i$f$commonCompareTo = false;
      int sizeA$iv = this.size();
      int sizeB$iv = other.size();
      int i$iv = 0;
      boolean var7 = false;
      int size$iv = Math.min(sizeA$iv, sizeB$iv);

      int var10000;
      while(true) {
         if (i$iv < size$iv) {
            byte $this$and$iv$iv = $this$commonCompareTo$iv.getByte(i$iv);
            int other$iv$iv = 255;
            int $i$f$and = false;
            int byteA$iv = $this$and$iv$iv & other$iv$iv;
            byte $this$and$iv$iv = other.getByte(i$iv);
            int other$iv$iv = 255;
            int $i$f$and = false;
            int byteB$iv = $this$and$iv$iv & other$iv$iv;
            if (byteA$iv == byteB$iv) {
               ++i$iv;
               continue;
            }

            var10000 = byteA$iv < byteB$iv ? -1 : 1;
            break;
         }

         var10000 = sizeA$iv == sizeB$iv ? 0 : (sizeA$iv < sizeB$iv ? -1 : 1);
         break;
      }

      return var10000;
   }

   @NotNull
   public String toString() {
      int $i$f$commonToString = false;
      byte[] var3 = this.getData$okio();
      boolean var4 = false;
      String var10000;
      if (var3.length == 0) {
         var10000 = "[size=0]";
      } else {
         int i$iv = ByteStringKt.access$codePointIndexToCharIndex(this.getData$okio(), 64);
         boolean var8;
         if (i$iv == -1) {
            if (this.getData$okio().length <= 64) {
               var10000 = "[hex=" + this.hex() + ']';
            } else {
               StringBuilder var21 = (new StringBuilder()).append("[size=").append(this.getData$okio().length).append(" hex=");
               byte beginIndex$iv$iv = 0;
               int endIndex$iv$iv = 64;
               int $i$f$commonSubstring = false;
               var8 = true;
               boolean var9 = false;
               boolean var10 = false;
               var8 = endIndex$iv$iv <= this.getData$okio().length;
               var9 = false;
               var10 = false;
               boolean var11;
               if (!var8) {
                  var11 = false;
                  String var19 = "endIndex > length(" + this.getData$okio().length + ')';
                  throw (Throwable)(new IllegalArgumentException(var19.toString()));
               }

               int subLen$iv$iv = endIndex$iv$iv - beginIndex$iv$iv;
               var9 = subLen$iv$iv >= 0;
               var10 = false;
               var11 = false;
               if (!var9) {
                  int var12 = false;
                  String var20 = "endIndex < beginIndex";
                  throw (Throwable)(new IllegalArgumentException(var20.toString()));
               }

               ByteString var10001;
               if (endIndex$iv$iv == this.getData$okio().length) {
                  var10001 = this;
               } else {
                  byte[] var18 = this.getData$okio();
                  var10 = false;
                  var10001 = new ByteString(ArraysKt.copyOfRange(var18, beginIndex$iv$iv, endIndex$iv$iv));
               }

               var10000 = var21.append(var10001.hex()).append("…]").toString();
            }
         } else {
            String text$iv = this.utf8();
            byte var16 = 0;
            var8 = false;
            if (text$iv == null) {
               throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }

            var10000 = text$iv.substring(var16, i$iv);
            Intrinsics.checkNotNullExpressionValue(var10000, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            String safeText$iv = StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(var10000, "\\", "\\\\", false, 4, (Object)null), "\n", "\\n", false, 4, (Object)null), "\r", "\\r", false, 4, (Object)null);
            var10000 = i$iv < text$iv.length() ? "[size=" + this.getData$okio().length + " text=" + safeText$iv + "…]" : "[text=" + safeText$iv + ']';
         }
      }

      return var10000;
   }

   private final void readObject(ObjectInputStream in) throws IOException {
      int dataLength = in.readInt();
      ByteString byteString = Companion.read((InputStream)in, dataLength);
      Field field = ByteString.class.getDeclaredField("data");
      Intrinsics.checkNotNullExpressionValue(field, "field");
      field.setAccessible(true);
      field.set(this, byteString.data);
   }

   private final void writeObject(ObjectOutputStream out) throws IOException {
      out.writeInt(this.data.length);
      out.write(this.data);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to operator function",
      replaceWith = @ReplaceWith(
   imports = {},
   expression = "this[index]"
),
      level = DeprecationLevel.ERROR
   )
   @JvmName(
      name = "-deprecated_getByte"
   )
   public final byte _deprecated_getByte/* $FF was: -deprecated_getByte*/(int index) {
      return this.getByte(index);
   }

   /** @deprecated */
   @Deprecated(
      message = "moved to val",
      replaceWith = @ReplaceWith(
   imports = {},
   expression = "size"
),
      level = DeprecationLevel.ERROR
   )
   @JvmName(
      name = "-deprecated_size"
   )
   public final int _deprecated_size/* $FF was: -deprecated_size*/() {
      return this.size();
   }

   @NotNull
   public final byte[] getData$okio() {
      return this.data;
   }

   public ByteString(@NotNull byte[] data) {
      Intrinsics.checkNotNullParameter(data, "data");
      super();
      this.data = data;
   }

   @JvmStatic
   @NotNull
   public static final ByteString of(@NotNull byte... data) {
      return Companion.of(data);
   }

   @JvmStatic
   @JvmName(
      name = "of"
   )
   @NotNull
   public static final ByteString of(@NotNull byte[] $this$toByteString, int offset, int byteCount) {
      return Companion.of($this$toByteString, offset, byteCount);
   }

   @JvmStatic
   @JvmName(
      name = "of"
   )
   @NotNull
   public static final ByteString of(@NotNull ByteBuffer $this$toByteString) {
      return Companion.of($this$toByteString);
   }

   @JvmStatic
   @NotNull
   public static final ByteString encodeUtf8(@NotNull String $this$encodeUtf8) {
      return Companion.encodeUtf8($this$encodeUtf8);
   }

   @JvmStatic
   @JvmName(
      name = "encodeString"
   )
   @NotNull
   public static final ByteString encodeString(@NotNull String $this$encode, @NotNull Charset charset) {
      return Companion.encodeString($this$encode, charset);
   }

   @JvmStatic
   @Nullable
   public static final ByteString decodeBase64(@NotNull String $this$decodeBase64) {
      return Companion.decodeBase64($this$decodeBase64);
   }

   @JvmStatic
   @NotNull
   public static final ByteString decodeHex(@NotNull String $this$decodeHex) {
      return Companion.decodeHex($this$decodeHex);
   }

   @JvmStatic
   @JvmName(
      name = "read"
   )
   @NotNull
   public static final ByteString read(@NotNull InputStream $this$readByteString, int byteCount) throws IOException {
      return Companion.read($this$readByteString, byteCount);
   }

   @Metadata(
      mv = {1, 4, 0},
      bv = {1, 0, 3},
      k = 1,
      d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0002\u0010\u0005\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0017\u0010\u0007\u001a\u0004\u0018\u00010\u00042\u0006\u0010\b\u001a\u00020\tH\u0007¢\u0006\u0002\b\nJ\u0015\u0010\u000b\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\tH\u0007¢\u0006\u0002\b\fJ\u001d\u0010\r\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u000e\u001a\u00020\u000fH\u0007¢\u0006\u0002\b\u0010J\u0015\u0010\u0011\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\tH\u0007¢\u0006\u0002\b\u0012J\u0015\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0014\u001a\u00020\u0015H\u0007¢\u0006\u0002\b\u0016J\u0014\u0010\u0013\u001a\u00020\u00042\n\u0010\u0017\u001a\u00020\u0018\"\u00020\u0019H\u0007J%\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u001a\u001a\u00020\u00182\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001cH\u0007¢\u0006\u0002\b\u0016J\u001d\u0010\u001e\u001a\u00020\u00042\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010\u001d\u001a\u00020\u001cH\u0007¢\u0006\u0002\b!J\u000e\u0010\u0007\u001a\u0004\u0018\u00010\u0004*\u00020\tH\u0007J\f\u0010\u000b\u001a\u00020\u0004*\u00020\tH\u0007J\u001b\u0010\"\u001a\u00020\u0004*\u00020\t2\b\b\u0002\u0010\u000e\u001a\u00020\u000fH\u0007¢\u0006\u0002\b\rJ\f\u0010\u0011\u001a\u00020\u0004*\u00020\tH\u0007J\u0019\u0010#\u001a\u00020\u0004*\u00020 2\u0006\u0010\u001d\u001a\u00020\u001cH\u0007¢\u0006\u0002\b\u001eJ\u0011\u0010$\u001a\u00020\u0004*\u00020\u0015H\u0007¢\u0006\u0002\b\u0013J%\u0010$\u001a\u00020\u0004*\u00020\u00182\b\b\u0002\u0010\u001b\u001a\u00020\u001c2\b\b\u0002\u0010\u001d\u001a\u00020\u001cH\u0007¢\u0006\u0002\b\u0013R\u0010\u0010\u0003\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000¨\u0006%"},
      d2 = {"Li/ByteString$Companion;", "", "()V", "EMPTY", "Li/ByteString;", "serialVersionUID", "", "decodeBase64", "string", "", "-deprecated_decodeBase64", "decodeHex", "-deprecated_decodeHex", "encodeString", "charset", "Ljava/nio/charset/Charset;", "-deprecated_encodeString", "encodeUtf8", "-deprecated_encodeUtf8", "of", "buffer", "Ljava/nio/ByteBuffer;", "-deprecated_of", "data", "", "", "array", "offset", "", "byteCount", "read", "inputstream", "Ljava/io/InputStream;", "-deprecated_read", "encode", "readByteString", "toByteString", "i"}
   )
   public static final class Companion {
      @JvmStatic
      @NotNull
      public final ByteString of(@NotNull byte... data) {
         Intrinsics.checkNotNullParameter(data, "data");
         int $i$f$commonOf = false;
         boolean var4 = false;
         byte[] var10002 = Arrays.copyOf(data, data.length);
         Intrinsics.checkNotNullExpressionValue(var10002, "java.util.Arrays.copyOf(this, size)");
         return new ByteString(var10002);
      }

      @JvmStatic
      @JvmName(
         name = "of"
      )
      @NotNull
      public final ByteString of(@NotNull byte[] $this$toByteString, int offset, int byteCount) {
         Intrinsics.checkNotNullParameter($this$toByteString, "$this$toByteString");
         int $i$f$commonToByteString = false;
         -Util.checkOffsetAndCount((long)$this$toByteString.length, (long)offset, (long)byteCount);
         int var7 = offset + byteCount;
         boolean var8 = false;
         return new ByteString(ArraysKt.copyOfRange($this$toByteString, offset, var7));
      }

      // $FF: synthetic method
      public static ByteString of$default(ByteString.Companion var0, byte[] var1, int var2, int var3, int var4, Object var5) {
         if ((var4 & 1) != 0) {
            var2 = 0;
         }

         if ((var4 & 2) != 0) {
            var3 = var1.length;
         }

         return var0.of(var1, var2, var3);
      }

      @JvmStatic
      @JvmName(
         name = "of"
      )
      @NotNull
      public final ByteString of(@NotNull ByteBuffer $this$toByteString) {
         Intrinsics.checkNotNullParameter($this$toByteString, "$this$toByteString");
         byte[] copy = new byte[$this$toByteString.remaining()];
         $this$toByteString.get(copy);
         return new ByteString(copy);
      }

      @JvmStatic
      @NotNull
      public final ByteString encodeUtf8(@NotNull String $this$encodeUtf8) {
         Intrinsics.checkNotNullParameter($this$encodeUtf8, "$this$encodeUtf8");
         int $i$f$commonEncodeUtf8 = false;
         ByteString byteString$iv = new ByteString(-Platform.asUtf8ToByteArray($this$encodeUtf8));
         byteString$iv.setUtf8$okio($this$encodeUtf8);
         return byteString$iv;
      }

      @JvmStatic
      @JvmName(
         name = "encodeString"
      )
      @NotNull
      public final ByteString encodeString(@NotNull String $this$encode, @NotNull Charset charset) {
         Intrinsics.checkNotNullParameter($this$encode, "$this$encode");
         Intrinsics.checkNotNullParameter(charset, "charset");
         boolean var4 = false;
         byte[] var10002 = $this$encode.getBytes(charset);
         Intrinsics.checkNotNullExpressionValue(var10002, "(this as java.lang.String).getBytes(charset)");
         return new ByteString(var10002);
      }

      // $FF: synthetic method
      public static ByteString encodeString$default(ByteString.Companion var0, String var1, Charset var2, int var3, Object var4) {
         if ((var3 & 1) != 0) {
            var2 = Charsets.UTF_8;
         }

         return var0.encodeString(var1, var2);
      }

      @JvmStatic
      @Nullable
      public final ByteString decodeBase64(@NotNull String $this$decodeBase64) {
         Intrinsics.checkNotNullParameter($this$decodeBase64, "$this$decodeBase64");
         int $i$f$commonDecodeBase64 = false;
         byte[] decoded$iv = -Base64.decodeBase64ToArray($this$decodeBase64);
         return decoded$iv != null ? new ByteString(decoded$iv) : null;
      }

      @JvmStatic
      @NotNull
      public final ByteString decodeHex(@NotNull String $this$decodeHex) {
         Intrinsics.checkNotNullParameter($this$decodeHex, "$this$decodeHex");
         String $this$commonDecodeHex$iv = $this$decodeHex;
         int $i$f$commonDecodeHex = false;
         boolean var4 = $this$decodeHex.length() % 2 == 0;
         boolean var5 = false;
         boolean var6 = false;
         if (!var4) {
            int var13 = false;
            String var12 = "Unexpected hex string: " + $this$decodeHex;
            throw (Throwable)(new IllegalArgumentException(var12.toString()));
         } else {
            byte[] result$iv = new byte[$this$decodeHex.length() / 2];
            int i$iv = 0;

            for(int var11 = result$iv.length; i$iv < var11; ++i$iv) {
               int d1$iv = ByteStringKt.access$decodeHexDigit($this$commonDecodeHex$iv.charAt(i$iv * 2)) << 4;
               int d2$iv = ByteStringKt.access$decodeHexDigit($this$commonDecodeHex$iv.charAt(i$iv * 2 + 1));
               result$iv[i$iv] = (byte)(d1$iv + d2$iv);
            }

            return new ByteString(result$iv);
         }
      }

      @JvmStatic
      @JvmName(
         name = "read"
      )
      @NotNull
      public final ByteString read(@NotNull InputStream $this$readByteString, int byteCount) throws IOException {
         Intrinsics.checkNotNullParameter($this$readByteString, "$this$readByteString");
         boolean var3 = byteCount >= 0;
         boolean var4 = false;
         boolean var5 = false;
         if (!var3) {
            int var6 = false;
            String var10 = "byteCount < 0: " + byteCount;
            throw (Throwable)(new IllegalArgumentException(var10.toString()));
         } else {
            byte[] result = new byte[byteCount];
            int offset = 0;

            int read;
            for(var5 = false; offset < byteCount; offset += read) {
               read = $this$readByteString.read(result, offset, byteCount - offset);
               if (read == -1) {
                  throw (Throwable)(new EOFException());
               }
            }

            return new ByteString(result);
         }
      }

      /** @deprecated */
      @Deprecated(
         message = "moved to extension function",
         replaceWith = @ReplaceWith(
   imports = {"i.ByteString.Companion.decodeBase64"},
   expression = "string.decodeBase64()"
),
         level = DeprecationLevel.ERROR
      )
      @JvmName(
         name = "-deprecated_decodeBase64"
      )
      @Nullable
      public final ByteString _deprecated_decodeBase64/* $FF was: -deprecated_decodeBase64*/(@NotNull String string) {
         Intrinsics.checkNotNullParameter(string, "string");
         return ((ByteString.Companion)this).decodeBase64(string);
      }

      /** @deprecated */
      @Deprecated(
         message = "moved to extension function",
         replaceWith = @ReplaceWith(
   imports = {"i.ByteString.Companion.decodeHex"},
   expression = "string.decodeHex()"
),
         level = DeprecationLevel.ERROR
      )
      @JvmName(
         name = "-deprecated_decodeHex"
      )
      @NotNull
      public final ByteString _deprecated_decodeHex/* $FF was: -deprecated_decodeHex*/(@NotNull String string) {
         Intrinsics.checkNotNullParameter(string, "string");
         return ((ByteString.Companion)this).decodeHex(string);
      }

      /** @deprecated */
      @Deprecated(
         message = "moved to extension function",
         replaceWith = @ReplaceWith(
   imports = {"i.ByteString.Companion.encode"},
   expression = "string.encode(charset)"
),
         level = DeprecationLevel.ERROR
      )
      @JvmName(
         name = "-deprecated_encodeString"
      )
      @NotNull
      public final ByteString _deprecated_encodeString/* $FF was: -deprecated_encodeString*/(@NotNull String string, @NotNull Charset charset) {
         Intrinsics.checkNotNullParameter(string, "string");
         Intrinsics.checkNotNullParameter(charset, "charset");
         return ((ByteString.Companion)this).encodeString(string, charset);
      }

      /** @deprecated */
      @Deprecated(
         message = "moved to extension function",
         replaceWith = @ReplaceWith(
   imports = {"i.ByteString.Companion.encodeUtf8"},
   expression = "string.encodeUtf8()"
),
         level = DeprecationLevel.ERROR
      )
      @JvmName(
         name = "-deprecated_encodeUtf8"
      )
      @NotNull
      public final ByteString _deprecated_encodeUtf8/* $FF was: -deprecated_encodeUtf8*/(@NotNull String string) {
         Intrinsics.checkNotNullParameter(string, "string");
         return ((ByteString.Companion)this).encodeUtf8(string);
      }

      /** @deprecated */
      @Deprecated(
         message = "moved to extension function",
         replaceWith = @ReplaceWith(
   imports = {"i.ByteString.Companion.toByteString"},
   expression = "buffer.toByteString()"
),
         level = DeprecationLevel.ERROR
      )
      @JvmName(
         name = "-deprecated_of"
      )
      @NotNull
      public final ByteString _deprecated_of/* $FF was: -deprecated_of*/(@NotNull ByteBuffer buffer) {
         Intrinsics.checkNotNullParameter(buffer, "buffer");
         return ((ByteString.Companion)this).of(buffer);
      }

      /** @deprecated */
      @Deprecated(
         message = "moved to extension function",
         replaceWith = @ReplaceWith(
   imports = {"i.ByteString.Companion.toByteString"},
   expression = "array.toByteString(offset, byteCount)"
),
         level = DeprecationLevel.ERROR
      )
      @JvmName(
         name = "-deprecated_of"
      )
      @NotNull
      public final ByteString _deprecated_of/* $FF was: -deprecated_of*/(@NotNull byte[] array, int offset, int byteCount) {
         Intrinsics.checkNotNullParameter(array, "array");
         return ((ByteString.Companion)this).of(array, offset, byteCount);
      }

      /** @deprecated */
      @Deprecated(
         message = "moved to extension function",
         replaceWith = @ReplaceWith(
   imports = {"i.ByteString.Companion.readByteString"},
   expression = "inputstream.readByteString(byteCount)"
),
         level = DeprecationLevel.ERROR
      )
      @JvmName(
         name = "-deprecated_read"
      )
      @NotNull
      public final ByteString _deprecated_read/* $FF was: -deprecated_read*/(@NotNull InputStream inputstream, int byteCount) {
         Intrinsics.checkNotNullParameter(inputstream, "inputstream");
         return ((ByteString.Companion)this).read(inputstream, byteCount);
      }

      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
