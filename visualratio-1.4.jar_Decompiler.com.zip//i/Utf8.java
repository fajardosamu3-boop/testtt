package i;

import k.Metadata;
import k.Unit;
import k.jvm.JvmName;
import k.jvm.JvmOverloads;
import k.jvm.functions.Function1;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 2,
   d1 = {"\u0000D\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0005\n\u0000\n\u0002\u0010\f\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\u001a\u0011\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u0001H\u0080\b\u001a\u0011\u0010\u000e\u001a\u00020\f2\u0006\u0010\u000f\u001a\u00020\u0007H\u0080\b\u001a4\u0010\u0010\u001a\u00020\u0001*\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u00012\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u00160\u0015H\u0080\bø\u0001\u0000\u001a4\u0010\u0017\u001a\u00020\u0001*\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u00012\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u00160\u0015H\u0080\bø\u0001\u0000\u001a4\u0010\u0018\u001a\u00020\u0001*\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u00012\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u00160\u0015H\u0080\bø\u0001\u0000\u001a4\u0010\u0019\u001a\u00020\u0016*\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u00012\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00160\u0015H\u0080\bø\u0001\u0000\u001a4\u0010\u001a\u001a\u00020\u0016*\u00020\u001b2\u0006\u0010\u0012\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u00012\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00160\u0015H\u0080\bø\u0001\u0000\u001a4\u0010\u001c\u001a\u00020\u0016*\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u00012\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u00160\u0015H\u0080\bø\u0001\u0000\u001a%\u0010\u001d\u001a\u00020\u001e*\u00020\u001b2\b\b\u0002\u0010\u0012\u001a\u00020\u00012\b\b\u0002\u0010\u0013\u001a\u00020\u0001H\u0007¢\u0006\u0002\b\u001f\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0004\u001a\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0005\u001a\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0006\u001a\u00020\u0007X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\b\u001a\u00020\tX\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\n\u001a\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006 "},
   d2 = {"HIGH_SURROGATE_HEADER", "", "LOG_SURROGATE_HEADER", "MASK_2BYTES", "MASK_3BYTES", "MASK_4BYTES", "REPLACEMENT_BYTE", "", "REPLACEMENT_CHARACTER", "", "REPLACEMENT_CODE_POINT", "isIsoControl", "", "codePoint", "isUtf8Continuation", "byte", "process2Utf8Bytes", "", "beginIndex", "endIndex", "yield", "Lk/Function1;", "", "process3Utf8Bytes", "process4Utf8Bytes", "processUtf16Chars", "processUtf8Bytes", "", "processUtf8CodePoints", "utf8Size", "", "size", "i"}
)
@JvmName(
   name = "Utf8"
)
public final class Utf8 {
   public static final byte REPLACEMENT_BYTE = 63;
   public static final char REPLACEMENT_CHARACTER = '�';
   public static final int REPLACEMENT_CODE_POINT = 65533;
   public static final int HIGH_SURROGATE_HEADER = 55232;
   public static final int LOG_SURROGATE_HEADER = 56320;
   public static final int MASK_2BYTES = 3968;
   public static final int MASK_3BYTES = -123008;
   public static final int MASK_4BYTES = 3678080;

   @JvmOverloads
   @JvmName(
      name = "size"
   )
   public static final long size(@NotNull String $this$utf8Size, int beginIndex, int endIndex) {
      Intrinsics.checkNotNullParameter($this$utf8Size, "$this$utf8Size");
      boolean var3 = beginIndex >= 0;
      boolean var4 = false;
      boolean var5 = false;
      boolean var12;
      String var13;
      if (!var3) {
         var12 = false;
         var13 = "beginIndex < 0: " + beginIndex;
         throw (Throwable)(new IllegalArgumentException(var13.toString()));
      } else {
         var3 = endIndex >= beginIndex;
         var4 = false;
         var5 = false;
         if (!var3) {
            var12 = false;
            var13 = "endIndex < beginIndex: " + endIndex + " < " + beginIndex;
            throw (Throwable)(new IllegalArgumentException(var13.toString()));
         } else {
            var3 = endIndex <= $this$utf8Size.length();
            var4 = false;
            var5 = false;
            if (!var3) {
               var12 = false;
               var13 = "endIndex > string.length: " + endIndex + " > " + $this$utf8Size.length();
               throw (Throwable)(new IllegalArgumentException(var13.toString()));
            } else {
               long result = 0L;
               int i = beginIndex;

               while(true) {
                  while(i < endIndex) {
                     int c = $this$utf8Size.charAt(i);
                     if (c < 128) {
                        ++result;
                        ++i;
                     } else if (c < 2048) {
                        result += (long)2;
                        ++i;
                     } else if (c >= '\ud800' && c <= '\udfff') {
                        int low = i + 1 < endIndex ? $this$utf8Size.charAt(i + 1) : 0;
                        if (c <= '\udbff' && low >= '\udc00' && low <= '\udfff') {
                           result += (long)4;
                           i += 2;
                        } else {
                           ++result;
                           ++i;
                        }
                     } else {
                        result += (long)3;
                        ++i;
                     }
                  }

                  return result;
               }
            }
         }
      }
   }

   // $FF: synthetic method
   public static long size$default(String var0, int var1, int var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = 0;
      }

      if ((var3 & 2) != 0) {
         var2 = var0.length();
      }

      return size(var0, var1, var2);
   }

   @JvmOverloads
   @JvmName(
      name = "size"
   )
   public static final long size(@NotNull String $this$utf8Size, int beginIndex) {
      return size$default($this$utf8Size, beginIndex, 0, 2, (Object)null);
   }

   @JvmOverloads
   @JvmName(
      name = "size"
   )
   public static final long size(@NotNull String $this$utf8Size) {
      return size$default($this$utf8Size, 0, 0, 3, (Object)null);
   }

   public static final boolean isIsoControl(int codePoint) {
      boolean var10000;
      label29: {
         int $i$f$isIsoControl = 0;
         if (0 <= codePoint) {
            if (31 >= codePoint) {
               break label29;
            }
         }

         if (127 <= codePoint) {
            if (159 >= codePoint) {
               break label29;
            }
         }

         var10000 = false;
         return var10000;
      }

      var10000 = true;
      return var10000;
   }

   public static final boolean isUtf8Continuation(byte var0) {
      int $i$f$isUtf8Continuation = 0;
      int other$iv = 192;
      int $i$f$and = false;
      return (var0 & other$iv) == 128;
   }

   public static final void processUtf8Bytes(@NotNull String $this$processUtf8Bytes, int beginIndex, int endIndex, @NotNull Function1<? super Byte, Unit> yield) {
      int $i$f$processUtf8Bytes = 0;
      Intrinsics.checkNotNullParameter($this$processUtf8Bytes, "$this$processUtf8Bytes");
      Intrinsics.checkNotNullParameter(yield, "yield");
      int index = beginIndex;

      while(true) {
         while(index < endIndex) {
            char c = $this$processUtf8Bytes.charAt(index);
            if (Intrinsics.compare(c, 128) < 0) {
               yield.invoke((byte)c);
               ++index;

               while(index < endIndex && Intrinsics.compare($this$processUtf8Bytes.charAt(index), 128) < 0) {
                  yield.invoke((byte)$this$processUtf8Bytes.charAt(index++));
               }
            } else if (Intrinsics.compare(c, 2048) < 0) {
               yield.invoke((byte)(c >> 6 | 192));
               yield.invoke((byte)(c & 63 | 128));
               ++index;
            } else {
               if ('\ud800' <= c) {
                  if ('\udfff' >= c) {
                     if (Intrinsics.compare(c, 56319) <= 0 && endIndex > index + 1) {
                        char var7 = $this$processUtf8Bytes.charAt(index + 1);
                        if ('\udc00' <= var7) {
                           if ('\udfff' >= var7) {
                              int codePoint = (c << 10) + $this$processUtf8Bytes.charAt(index + 1) + -56613888;
                              yield.invoke((byte)(codePoint >> 18 | 240));
                              yield.invoke((byte)(codePoint >> 12 & 63 | 128));
                              yield.invoke((byte)(codePoint >> 6 & 63 | 128));
                              yield.invoke((byte)(codePoint & 63 | 128));
                              index += 2;
                              continue;
                           }
                        }
                     }

                     yield.invoke((byte)63);
                     ++index;
                     continue;
                  }
               }

               yield.invoke((byte)(c >> 12 | 224));
               yield.invoke((byte)(c >> 6 & 63 | 128));
               yield.invoke((byte)(c & 63 | 128));
               ++index;
            }
         }

         return;
      }
   }

   public static final void processUtf8CodePoints(@NotNull byte[] $this$processUtf8CodePoints, int beginIndex, int endIndex, @NotNull Function1<? super Integer, Unit> yield) {
      int $i$f$processUtf8CodePoints = 0;
      Intrinsics.checkNotNullParameter($this$processUtf8CodePoints, "$this$processUtf8CodePoints");
      Intrinsics.checkNotNullParameter(yield, "yield");
      int index = beginIndex;

      while(true) {
         while(index < endIndex) {
            byte b0 = $this$processUtf8CodePoints[index];
            if (b0 >= 0) {
               yield.invoke(Integer.valueOf(b0));
               ++index;

               while(index < endIndex && $this$processUtf8CodePoints[index] >= 0) {
                  yield.invoke(Integer.valueOf($this$processUtf8CodePoints[index++]));
               }
            } else {
               int other$iv = 5;
               int $i$f$shr = false;
               boolean var10;
               byte byte$iv$iv;
               boolean $i$f$isUtf8Continuation;
               int var10000;
               boolean $i$f$and;
               byte var10001;
               Unit var20;
               boolean $i$f$process4Utf8Bytes;
               char it;
               byte b1$iv;
               short other$iv$iv$iv;
               if (b0 >> other$iv == -2) {
                  $i$f$process4Utf8Bytes = false;
                  if (endIndex <= index + 1) {
                     it = '�';
                     var10 = false;
                     yield.invoke(Integer.valueOf(it));
                     var20 = Unit.INSTANCE;
                     var10000 = index;
                     var10001 = 1;
                  } else {
                     byte$iv$iv = $this$processUtf8CodePoints[index];
                     b1$iv = $this$processUtf8CodePoints[index + 1];
                     $i$f$isUtf8Continuation = false;
                     other$iv$iv$iv = 192;
                     $i$f$and = false;
                     if ((b1$iv & other$iv$iv$iv) != 128) {
                        it = '�';
                        var10 = false;
                        yield.invoke(Integer.valueOf(it));
                        var20 = Unit.INSTANCE;
                        var10000 = index;
                        var10001 = 1;
                     } else {
                        int codePoint$iv = 3968 ^ b1$iv ^ byte$iv$iv << 6;
                        if (codePoint$iv < 128) {
                           it = '�';
                           var10 = false;
                           yield.invoke(Integer.valueOf(it));
                           var20 = Unit.INSTANCE;
                           var10000 = index;
                        } else {
                           var10 = false;
                           yield.invoke(codePoint$iv);
                           var20 = Unit.INSTANCE;
                           var10000 = index;
                        }

                        var10001 = 2;
                     }
                  }

                  index = var10000 + var10001;
               } else {
                  other$iv = 4;
                  $i$f$shr = false;
                  boolean $i$f$isUtf8Continuation;
                  short other$iv$iv$iv;
                  boolean $i$f$and;
                  boolean $i$f$and;
                  byte b2$iv;
                  boolean $i$f$isUtf8Continuation;
                  short other$iv$iv$iv;
                  if (b0 >> other$iv == -2) {
                     $i$f$process4Utf8Bytes = false;
                     if (endIndex <= index + 2) {
                        label134: {
                           it = '�';
                           var10 = false;
                           yield.invoke(Integer.valueOf(it));
                           var20 = Unit.INSTANCE;
                           var10000 = index;
                           if (endIndex > index + 1) {
                              byte$iv$iv = $this$processUtf8CodePoints[index + 1];
                              $i$f$isUtf8Continuation = false;
                              other$iv$iv$iv = 192;
                              $i$f$and = false;
                              if ((byte$iv$iv & other$iv$iv$iv) == 128) {
                                 var10001 = 2;
                                 break label134;
                              }
                           }

                           var10001 = 1;
                        }
                     } else {
                        byte$iv$iv = $this$processUtf8CodePoints[index];
                        b1$iv = $this$processUtf8CodePoints[index + 1];
                        $i$f$isUtf8Continuation = false;
                        other$iv$iv$iv = 192;
                        $i$f$and = false;
                        if ((b1$iv & other$iv$iv$iv) != 128) {
                           it = '�';
                           var10 = false;
                           yield.invoke(Integer.valueOf(it));
                           var20 = Unit.INSTANCE;
                           var10000 = index;
                           var10001 = 1;
                        } else {
                           b2$iv = $this$processUtf8CodePoints[index + 2];
                           $i$f$isUtf8Continuation = false;
                           other$iv$iv$iv = 192;
                           $i$f$and = false;
                           if ((b2$iv & other$iv$iv$iv) != 128) {
                              it = '�';
                              var10 = false;
                              yield.invoke(Integer.valueOf(it));
                              var20 = Unit.INSTANCE;
                              var10000 = index;
                              var10001 = 2;
                           } else {
                              int codePoint$iv = -123008 ^ b2$iv ^ b1$iv << 6 ^ byte$iv$iv << 12;
                              if (codePoint$iv < 2048) {
                                 it = '�';
                                 var10 = false;
                                 yield.invoke(Integer.valueOf(it));
                                 var20 = Unit.INSTANCE;
                                 var10000 = index;
                              } else {
                                 label191: {
                                    if (55296 <= codePoint$iv) {
                                       if (57343 >= codePoint$iv) {
                                          it = '�';
                                          var10 = false;
                                          yield.invoke(Integer.valueOf(it));
                                          var20 = Unit.INSTANCE;
                                          var10000 = index;
                                          break label191;
                                       }
                                    }

                                    var10 = false;
                                    yield.invoke(codePoint$iv);
                                    var20 = Unit.INSTANCE;
                                    var10000 = index;
                                 }
                              }

                              var10001 = 3;
                           }
                        }
                     }

                     index = var10000 + var10001;
                  } else {
                     other$iv = 3;
                     $i$f$shr = false;
                     if (b0 >> other$iv != -2) {
                        yield.invoke(65533);
                        ++index;
                     } else {
                        $i$f$process4Utf8Bytes = false;
                        if (endIndex <= index + 3) {
                           label159: {
                              it = '�';
                              var10 = false;
                              yield.invoke(Integer.valueOf(it));
                              var20 = Unit.INSTANCE;
                              var10000 = index;
                              if (endIndex > index + 1) {
                                 byte$iv$iv = $this$processUtf8CodePoints[index + 1];
                                 $i$f$isUtf8Continuation = false;
                                 other$iv$iv$iv = 192;
                                 $i$f$and = false;
                                 if ((byte$iv$iv & other$iv$iv$iv) == 128) {
                                    if (endIndex > index + 2) {
                                       byte$iv$iv = $this$processUtf8CodePoints[index + 2];
                                       $i$f$isUtf8Continuation = false;
                                       other$iv$iv$iv = 192;
                                       $i$f$and = false;
                                       if ((byte$iv$iv & other$iv$iv$iv) == 128) {
                                          var10001 = 3;
                                          break label159;
                                       }
                                    }

                                    var10001 = 2;
                                    break label159;
                                 }
                              }

                              var10001 = 1;
                           }
                        } else {
                           byte$iv$iv = $this$processUtf8CodePoints[index];
                           b1$iv = $this$processUtf8CodePoints[index + 1];
                           $i$f$isUtf8Continuation = false;
                           other$iv$iv$iv = 192;
                           $i$f$and = false;
                           if ((b1$iv & other$iv$iv$iv) != 128) {
                              it = '�';
                              var10 = false;
                              yield.invoke(Integer.valueOf(it));
                              var20 = Unit.INSTANCE;
                              var10000 = index;
                              var10001 = 1;
                           } else {
                              b2$iv = $this$processUtf8CodePoints[index + 2];
                              $i$f$isUtf8Continuation = false;
                              other$iv$iv$iv = 192;
                              $i$f$and = false;
                              if ((b2$iv & other$iv$iv$iv) != 128) {
                                 it = '�';
                                 var10 = false;
                                 yield.invoke(Integer.valueOf(it));
                                 var20 = Unit.INSTANCE;
                                 var10000 = index;
                                 var10001 = 2;
                              } else {
                                 byte b3$iv = $this$processUtf8CodePoints[index + 3];
                                 $i$f$and = false;
                                 int other$iv$iv$iv = 192;
                                 int $i$f$and = false;
                                 if ((b3$iv & other$iv$iv$iv) != 128) {
                                    it = '�';
                                    var10 = false;
                                    yield.invoke(Integer.valueOf(it));
                                    var20 = Unit.INSTANCE;
                                    var10000 = index;
                                    var10001 = 3;
                                 } else {
                                    int codePoint$iv = 3678080 ^ b3$iv ^ b2$iv << 6 ^ b1$iv << 12 ^ byte$iv$iv << 18;
                                    if (codePoint$iv > 1114111) {
                                       it = '�';
                                       var10 = false;
                                       yield.invoke(Integer.valueOf(it));
                                       var20 = Unit.INSTANCE;
                                       var10000 = index;
                                    } else {
                                       label204: {
                                          if (55296 <= codePoint$iv) {
                                             if (57343 >= codePoint$iv) {
                                                it = '�';
                                                var10 = false;
                                                yield.invoke(Integer.valueOf(it));
                                                var20 = Unit.INSTANCE;
                                                var10000 = index;
                                                break label204;
                                             }
                                          }

                                          if (codePoint$iv < 65536) {
                                             it = '�';
                                             var10 = false;
                                             yield.invoke(Integer.valueOf(it));
                                             var20 = Unit.INSTANCE;
                                             var10000 = index;
                                          } else {
                                             var10 = false;
                                             yield.invoke(codePoint$iv);
                                             var20 = Unit.INSTANCE;
                                             var10000 = index;
                                          }
                                       }
                                    }

                                    var10001 = 4;
                                 }
                              }
                           }
                        }

                        index = var10000 + var10001;
                     }
                  }
               }
            }
         }

         return;
      }
   }

   public static final void processUtf16Chars(@NotNull byte[] $this$processUtf16Chars, int beginIndex, int endIndex, @NotNull Function1<? super Character, Unit> yield) {
      int $i$f$processUtf16Chars = 0;
      Intrinsics.checkNotNullParameter($this$processUtf16Chars, "$this$processUtf16Chars");
      Intrinsics.checkNotNullParameter(yield, "yield");
      int index = beginIndex;

      while(true) {
         while(index < endIndex) {
            byte b0 = $this$processUtf16Chars[index];
            if (b0 >= 0) {
               yield.invoke((char)b0);
               ++index;

               while(index < endIndex && $this$processUtf16Chars[index] >= 0) {
                  yield.invoke((char)$this$processUtf16Chars[index++]);
               }
            } else {
               int other$iv = 5;
               int $i$f$shr = false;
               boolean var10;
               byte byte$iv$iv;
               boolean $i$f$isUtf8Continuation;
               int var10000;
               boolean $i$f$and;
               byte var10001;
               Unit var20;
               boolean $i$f$process4Utf8Bytes;
               char codePoint;
               byte b1$iv;
               short other$iv$iv$iv;
               if (b0 >> other$iv == -2) {
                  $i$f$process4Utf8Bytes = false;
                  if (endIndex <= index + 1) {
                     codePoint = '�';
                     var10 = false;
                     yield.invoke((char)codePoint);
                     var20 = Unit.INSTANCE;
                     var10000 = index;
                     var10001 = 1;
                  } else {
                     byte$iv$iv = $this$processUtf16Chars[index];
                     b1$iv = $this$processUtf16Chars[index + 1];
                     $i$f$isUtf8Continuation = false;
                     other$iv$iv$iv = 192;
                     $i$f$and = false;
                     if ((b1$iv & other$iv$iv$iv) != 128) {
                        codePoint = '�';
                        var10 = false;
                        yield.invoke((char)codePoint);
                        var20 = Unit.INSTANCE;
                        var10000 = index;
                        var10001 = 1;
                     } else {
                        int codePoint$iv = 3968 ^ b1$iv ^ byte$iv$iv << 6;
                        if (codePoint$iv < 128) {
                           codePoint = '�';
                           var10 = false;
                           yield.invoke((char)codePoint);
                           var20 = Unit.INSTANCE;
                           var10000 = index;
                        } else {
                           var10 = false;
                           yield.invoke((char)codePoint$iv);
                           var20 = Unit.INSTANCE;
                           var10000 = index;
                        }

                        var10001 = 2;
                     }
                  }

                  index = var10000 + var10001;
               } else {
                  other$iv = 4;
                  $i$f$shr = false;
                  boolean $i$f$isUtf8Continuation;
                  short other$iv$iv$iv;
                  boolean $i$f$and;
                  boolean $i$f$and;
                  byte b2$iv;
                  boolean $i$f$isUtf8Continuation;
                  short other$iv$iv$iv;
                  if (b0 >> other$iv == -2) {
                     $i$f$process4Utf8Bytes = false;
                     if (endIndex <= index + 2) {
                        label173: {
                           codePoint = '�';
                           var10 = false;
                           yield.invoke((char)codePoint);
                           var20 = Unit.INSTANCE;
                           var10000 = index;
                           if (endIndex > index + 1) {
                              byte$iv$iv = $this$processUtf16Chars[index + 1];
                              $i$f$isUtf8Continuation = false;
                              other$iv$iv$iv = 192;
                              $i$f$and = false;
                              if ((byte$iv$iv & other$iv$iv$iv) == 128) {
                                 var10001 = 2;
                                 break label173;
                              }
                           }

                           var10001 = 1;
                        }
                     } else {
                        byte$iv$iv = $this$processUtf16Chars[index];
                        b1$iv = $this$processUtf16Chars[index + 1];
                        $i$f$isUtf8Continuation = false;
                        other$iv$iv$iv = 192;
                        $i$f$and = false;
                        if ((b1$iv & other$iv$iv$iv) != 128) {
                           codePoint = '�';
                           var10 = false;
                           yield.invoke((char)codePoint);
                           var20 = Unit.INSTANCE;
                           var10000 = index;
                           var10001 = 1;
                        } else {
                           b2$iv = $this$processUtf16Chars[index + 2];
                           $i$f$isUtf8Continuation = false;
                           other$iv$iv$iv = 192;
                           $i$f$and = false;
                           if ((b2$iv & other$iv$iv$iv) != 128) {
                              codePoint = '�';
                              var10 = false;
                              yield.invoke((char)codePoint);
                              var20 = Unit.INSTANCE;
                              var10000 = index;
                              var10001 = 2;
                           } else {
                              int codePoint$iv = -123008 ^ b2$iv ^ b1$iv << 6 ^ byte$iv$iv << 12;
                              if (codePoint$iv < 2048) {
                                 codePoint = '�';
                                 var10 = false;
                                 yield.invoke((char)codePoint);
                                 var20 = Unit.INSTANCE;
                                 var10000 = index;
                              } else {
                                 label232: {
                                    if (55296 <= codePoint$iv) {
                                       if (57343 >= codePoint$iv) {
                                          codePoint = '�';
                                          var10 = false;
                                          yield.invoke((char)codePoint);
                                          var20 = Unit.INSTANCE;
                                          var10000 = index;
                                          break label232;
                                       }
                                    }

                                    var10 = false;
                                    yield.invoke((char)codePoint$iv);
                                    var20 = Unit.INSTANCE;
                                    var10000 = index;
                                 }
                              }

                              var10001 = 3;
                           }
                        }
                     }

                     index = var10000 + var10001;
                  } else {
                     other$iv = 3;
                     $i$f$shr = false;
                     if (b0 >> other$iv != -2) {
                        yield.invoke('�');
                        ++index;
                     } else {
                        $i$f$process4Utf8Bytes = false;
                        if (endIndex <= index + 3) {
                           label220: {
                              codePoint = '�';
                              var10 = false;
                              if (codePoint != '�') {
                                 yield.invoke((char)((codePoint >>> 10) + 'ퟀ'));
                                 yield.invoke((char)((codePoint & 1023) + '\udc00'));
                              } else {
                                 yield.invoke('�');
                              }

                              var20 = Unit.INSTANCE;
                              var10000 = index;
                              if (endIndex > index + 1) {
                                 byte$iv$iv = $this$processUtf16Chars[index + 1];
                                 $i$f$isUtf8Continuation = false;
                                 other$iv$iv$iv = 192;
                                 $i$f$and = false;
                                 if ((byte$iv$iv & other$iv$iv$iv) == 128) {
                                    if (endIndex > index + 2) {
                                       byte$iv$iv = $this$processUtf16Chars[index + 2];
                                       $i$f$isUtf8Continuation = false;
                                       other$iv$iv$iv = 192;
                                       $i$f$and = false;
                                       if ((byte$iv$iv & other$iv$iv$iv) == 128) {
                                          var10001 = 3;
                                          break label220;
                                       }
                                    }

                                    var10001 = 2;
                                    break label220;
                                 }
                              }

                              var10001 = 1;
                           }
                        } else {
                           byte$iv$iv = $this$processUtf16Chars[index];
                           b1$iv = $this$processUtf16Chars[index + 1];
                           $i$f$isUtf8Continuation = false;
                           other$iv$iv$iv = 192;
                           $i$f$and = false;
                           if ((b1$iv & other$iv$iv$iv) != 128) {
                              codePoint = '�';
                              var10 = false;
                              if (codePoint != '�') {
                                 yield.invoke((char)((codePoint >>> 10) + 'ퟀ'));
                                 yield.invoke((char)((codePoint & 1023) + '\udc00'));
                              } else {
                                 yield.invoke('�');
                              }

                              var20 = Unit.INSTANCE;
                              var10000 = index;
                              var10001 = 1;
                           } else {
                              b2$iv = $this$processUtf16Chars[index + 2];
                              $i$f$isUtf8Continuation = false;
                              other$iv$iv$iv = 192;
                              $i$f$and = false;
                              if ((b2$iv & other$iv$iv$iv) != 128) {
                                 codePoint = '�';
                                 var10 = false;
                                 if (codePoint != '�') {
                                    yield.invoke((char)((codePoint >>> 10) + 'ퟀ'));
                                    yield.invoke((char)((codePoint & 1023) + '\udc00'));
                                 } else {
                                    yield.invoke('�');
                                 }

                                 var20 = Unit.INSTANCE;
                                 var10000 = index;
                                 var10001 = 2;
                              } else {
                                 byte b3$iv = $this$processUtf16Chars[index + 3];
                                 $i$f$and = false;
                                 int other$iv$iv$iv = 192;
                                 int $i$f$and = false;
                                 if ((b3$iv & other$iv$iv$iv) != 128) {
                                    codePoint = '�';
                                    var10 = false;
                                    if (codePoint != '�') {
                                       yield.invoke((char)((codePoint >>> 10) + 'ퟀ'));
                                       yield.invoke((char)((codePoint & 1023) + '\udc00'));
                                    } else {
                                       yield.invoke('�');
                                    }

                                    var20 = Unit.INSTANCE;
                                    var10000 = index;
                                    var10001 = 3;
                                 } else {
                                    int codePoint$iv = 3678080 ^ b3$iv ^ b2$iv << 6 ^ b1$iv << 12 ^ byte$iv$iv << 18;
                                    if (codePoint$iv > 1114111) {
                                       codePoint = '�';
                                       var10 = false;
                                       if (codePoint != '�') {
                                          yield.invoke((char)((codePoint >>> 10) + 'ퟀ'));
                                          yield.invoke((char)((codePoint & 1023) + '\udc00'));
                                       } else {
                                          yield.invoke('�');
                                       }

                                       var20 = Unit.INSTANCE;
                                       var10000 = index;
                                    } else {
                                       label245: {
                                          if (55296 <= codePoint$iv) {
                                             if (57343 >= codePoint$iv) {
                                                codePoint = '�';
                                                var10 = false;
                                                if (codePoint != '�') {
                                                   yield.invoke((char)((codePoint >>> 10) + 'ퟀ'));
                                                   yield.invoke((char)((codePoint & 1023) + '\udc00'));
                                                } else {
                                                   yield.invoke('�');
                                                }

                                                var20 = Unit.INSTANCE;
                                                var10000 = index;
                                                break label245;
                                             }
                                          }

                                          if (codePoint$iv < 65536) {
                                             codePoint = '�';
                                             var10 = false;
                                             if (codePoint != '�') {
                                                yield.invoke((char)((codePoint >>> 10) + 'ퟀ'));
                                                yield.invoke((char)((codePoint & 1023) + '\udc00'));
                                             } else {
                                                yield.invoke('�');
                                             }

                                             var20 = Unit.INSTANCE;
                                             var10000 = index;
                                          } else {
                                             var10 = false;
                                             if (codePoint$iv != 65533) {
                                                yield.invoke((char)((codePoint$iv >>> 10) + 'ퟀ'));
                                                yield.invoke((char)((codePoint$iv & 1023) + '\udc00'));
                                             } else {
                                                yield.invoke('�');
                                             }

                                             var20 = Unit.INSTANCE;
                                             var10000 = index;
                                          }
                                       }
                                    }

                                    var10001 = 4;
                                 }
                              }
                           }
                        }

                        index = var10000 + var10001;
                     }
                  }
               }
            }
         }

         return;
      }
   }

   public static final int process2Utf8Bytes(@NotNull byte[] $this$process2Utf8Bytes, int beginIndex, int endIndex, @NotNull Function1<? super Integer, Unit> yield) {
      int $i$f$process2Utf8Bytes = 0;
      Intrinsics.checkNotNullParameter($this$process2Utf8Bytes, "$this$process2Utf8Bytes");
      Intrinsics.checkNotNullParameter(yield, "yield");
      if (endIndex <= beginIndex + 1) {
         yield.invoke(65533);
         return 1;
      } else {
         byte b0 = $this$process2Utf8Bytes[beginIndex];
         byte b1 = $this$process2Utf8Bytes[beginIndex + 1];
         int $i$f$isUtf8Continuation = false;
         int other$iv$iv = 192;
         int $i$f$and = false;
         if ((b1 & other$iv$iv) != 128) {
            yield.invoke(65533);
            return 1;
         } else {
            int codePoint = 3968 ^ b1 ^ b0 << 6;
            if (codePoint < 128) {
               yield.invoke(65533);
            } else {
               yield.invoke(codePoint);
            }

            return 2;
         }
      }
   }

   public static final int process3Utf8Bytes(@NotNull byte[] $this$process3Utf8Bytes, int beginIndex, int endIndex, @NotNull Function1<? super Integer, Unit> yield) {
      int $i$f$process3Utf8Bytes = 0;
      Intrinsics.checkNotNullParameter($this$process3Utf8Bytes, "$this$process3Utf8Bytes");
      Intrinsics.checkNotNullParameter(yield, "yield");
      byte b0;
      if (endIndex <= beginIndex + 2) {
         yield.invoke(65533);
         if (endIndex > beginIndex + 1) {
            b0 = $this$process3Utf8Bytes[beginIndex + 1];
            int $i$f$isUtf8Continuation = false;
            int other$iv$iv = 192;
            int $i$f$and = false;
            if ((b0 & other$iv$iv) == 128) {
               return 2;
            }
         }

         return 1;
      } else {
         b0 = $this$process3Utf8Bytes[beginIndex];
         byte b1 = $this$process3Utf8Bytes[beginIndex + 1];
         int $i$f$isUtf8Continuation = false;
         int other$iv$iv = 192;
         int $i$f$and = false;
         if ((b1 & other$iv$iv) != 128) {
            yield.invoke(65533);
            return 1;
         } else {
            byte b2 = $this$process3Utf8Bytes[beginIndex + 2];
            int $i$f$isUtf8Continuation = false;
            int other$iv$iv = 192;
            int $i$f$and = false;
            if ((b2 & other$iv$iv) != 128) {
               yield.invoke(65533);
               return 2;
            } else {
               int codePoint = -123008 ^ b2 ^ b1 << 6 ^ b0 << 12;
               if (codePoint < 2048) {
                  yield.invoke(65533);
               } else {
                  if (55296 <= codePoint) {
                     if (57343 >= codePoint) {
                        yield.invoke(65533);
                        return 3;
                     }
                  }

                  yield.invoke(codePoint);
               }

               return 3;
            }
         }
      }
   }

   public static final int process4Utf8Bytes(@NotNull byte[] $this$process4Utf8Bytes, int beginIndex, int endIndex, @NotNull Function1<? super Integer, Unit> yield) {
      int $i$f$process4Utf8Bytes = 0;
      Intrinsics.checkNotNullParameter($this$process4Utf8Bytes, "$this$process4Utf8Bytes");
      Intrinsics.checkNotNullParameter(yield, "yield");
      byte byte$iv;
      boolean $i$f$and;
      if (endIndex <= beginIndex + 3) {
         yield.invoke(65533);
         if (endIndex > beginIndex + 1) {
            byte$iv = $this$process4Utf8Bytes[beginIndex + 1];
            int $i$f$isUtf8Continuation = false;
            int other$iv$iv = 192;
            $i$f$and = false;
            if ((byte$iv & other$iv$iv) == 128) {
               if (endIndex > beginIndex + 2) {
                  byte$iv = $this$process4Utf8Bytes[beginIndex + 2];
                  $i$f$isUtf8Continuation = false;
                  other$iv$iv = 192;
                  $i$f$and = false;
                  if ((byte$iv & other$iv$iv) == 128) {
                     return 3;
                  }
               }

               return 2;
            }
         }

         return 1;
      } else {
         byte$iv = $this$process4Utf8Bytes[beginIndex];
         byte b1 = $this$process4Utf8Bytes[beginIndex + 1];
         int $i$f$isUtf8Continuation = false;
         int other$iv$iv = 192;
         int $i$f$and = false;
         if ((b1 & other$iv$iv) != 128) {
            yield.invoke(65533);
            return 1;
         } else {
            byte b2 = $this$process4Utf8Bytes[beginIndex + 2];
            int $i$f$isUtf8Continuation = false;
            int other$iv$iv = 192;
            int $i$f$and = false;
            if ((b2 & other$iv$iv) != 128) {
               yield.invoke(65533);
               return 2;
            } else {
               byte b3 = $this$process4Utf8Bytes[beginIndex + 3];
               $i$f$and = false;
               int other$iv$iv = 192;
               int $i$f$and = false;
               if ((b3 & other$iv$iv) != 128) {
                  yield.invoke(65533);
                  return 3;
               } else {
                  int codePoint = 3678080 ^ b3 ^ b2 << 6 ^ b1 << 12 ^ byte$iv << 18;
                  if (codePoint > 1114111) {
                     yield.invoke(65533);
                  } else {
                     if (55296 <= codePoint) {
                        if (57343 >= codePoint) {
                           yield.invoke(65533);
                           return 4;
                        }
                     }

                     if (codePoint < 65536) {
                        yield.invoke(65533);
                     } else {
                        yield.invoke(codePoint);
                     }
                  }

                  return 4;
               }
            }
         }
      }
   }
}
