package com.fasterxml.jackson.databind.util;

public interface Named {
   String getName();
}
