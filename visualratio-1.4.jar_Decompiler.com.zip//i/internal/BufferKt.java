package i.internal;

import i.-Platform;
import i.-Util;
import i.Buffer;
import i.ByteString;
import i.Options;
import i.Segment;
import i.SegmentPool;
import i.SegmentedByteString;
import i.Sink;
import i.Source;
import java.io.EOFException;
import k.Metadata;
import k.collections.ArraysKt;
import k.jvm.functions.Function2;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 2,
   d1 = {"\u0000v\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0005\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\n\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a0\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\b2\u0006\u0010\u000e\u001a\u00020\u00012\u0006\u0010\u000f\u001a\u00020\b2\u0006\u0010\u0010\u001a\u00020\bH\u0000\u001a\r\u0010\u0011\u001a\u00020\u0012*\u00020\u0013H\u0080\b\u001a\r\u0010\u0014\u001a\u00020\u0005*\u00020\u0013H\u0080\b\u001a\r\u0010\u0015\u001a\u00020\u0013*\u00020\u0013H\u0080\b\u001a%\u0010\u0016\u001a\u00020\u0013*\u00020\u00132\u0006\u0010\u0017\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u0005H\u0080\b\u001a\u0017\u0010\u001a\u001a\u00020\n*\u00020\u00132\b\u0010\u001b\u001a\u0004\u0018\u00010\u001cH\u0080\b\u001a\u0015\u0010\u001d\u001a\u00020\u001e*\u00020\u00132\u0006\u0010\u001f\u001a\u00020\u0005H\u0080\b\u001a\r\u0010 \u001a\u00020\b*\u00020\u0013H\u0080\b\u001a%\u0010!\u001a\u00020\u0005*\u00020\u00132\u0006\u0010\"\u001a\u00020\u001e2\u0006\u0010#\u001a\u00020\u00052\u0006\u0010$\u001a\u00020\u0005H\u0080\b\u001a\u001d\u0010!\u001a\u00020\u0005*\u00020\u00132\u0006\u0010\u000e\u001a\u00020%2\u0006\u0010#\u001a\u00020\u0005H\u0080\b\u001a\u001d\u0010&\u001a\u00020\u0005*\u00020\u00132\u0006\u0010'\u001a\u00020%2\u0006\u0010#\u001a\u00020\u0005H\u0080\b\u001a-\u0010(\u001a\u00020\n*\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u000e\u001a\u00020%2\u0006\u0010\u000f\u001a\u00020\b2\u0006\u0010\u0019\u001a\u00020\bH\u0080\b\u001a\u0015\u0010)\u001a\u00020\b*\u00020\u00132\u0006\u0010*\u001a\u00020\u0001H\u0080\b\u001a%\u0010)\u001a\u00020\b*\u00020\u00132\u0006\u0010*\u001a\u00020\u00012\u0006\u0010\u0018\u001a\u00020\b2\u0006\u0010\u0019\u001a\u00020\bH\u0080\b\u001a\u001d\u0010)\u001a\u00020\u0005*\u00020\u00132\u0006\u0010*\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0005H\u0080\b\u001a\u0015\u0010+\u001a\u00020\u0005*\u00020\u00132\u0006\u0010*\u001a\u00020,H\u0080\b\u001a\r\u0010-\u001a\u00020\u001e*\u00020\u0013H\u0080\b\u001a\r\u0010.\u001a\u00020\u0001*\u00020\u0013H\u0080\b\u001a\u0015\u0010.\u001a\u00020\u0001*\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0005H\u0080\b\u001a\r\u0010/\u001a\u00020%*\u00020\u0013H\u0080\b\u001a\u0015\u0010/\u001a\u00020%*\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0005H\u0080\b\u001a\r\u00100\u001a\u00020\u0005*\u00020\u0013H\u0080\b\u001a\u0015\u00101\u001a\u00020\u0012*\u00020\u00132\u0006\u0010*\u001a\u00020\u0001H\u0080\b\u001a\u001d\u00101\u001a\u00020\u0012*\u00020\u00132\u0006\u0010*\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0005H\u0080\b\u001a\r\u00102\u001a\u00020\u0005*\u00020\u0013H\u0080\b\u001a\r\u00103\u001a\u00020\b*\u00020\u0013H\u0080\b\u001a\r\u00104\u001a\u00020\u0005*\u00020\u0013H\u0080\b\u001a\r\u00105\u001a\u000206*\u00020\u0013H\u0080\b\u001a\u0015\u00107\u001a\u000208*\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0005H\u0080\b\u001a\r\u00109\u001a\u00020\b*\u00020\u0013H\u0080\b\u001a\u000f\u0010:\u001a\u0004\u0018\u000108*\u00020\u0013H\u0080\b\u001a\u0015\u0010;\u001a\u000208*\u00020\u00132\u0006\u0010<\u001a\u00020\u0005H\u0080\b\u001a\u0015\u0010=\u001a\u00020\b*\u00020\u00132\u0006\u0010>\u001a\u00020?H\u0080\b\u001a\u0015\u0010@\u001a\u00020\u0012*\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0005H\u0080\b\u001a\r\u0010A\u001a\u00020%*\u00020\u0013H\u0080\b\u001a\u0015\u0010A\u001a\u00020%*\u00020\u00132\u0006\u0010\u0019\u001a\u00020\bH\u0080\b\u001a\u0015\u0010B\u001a\u00020\f*\u00020\u00132\u0006\u0010C\u001a\u00020\bH\u0080\b\u001a\u0015\u0010D\u001a\u00020\u0013*\u00020\u00132\u0006\u0010E\u001a\u00020\u0001H\u0080\b\u001a%\u0010D\u001a\u00020\u0013*\u00020\u00132\u0006\u0010E\u001a\u00020\u00012\u0006\u0010\u0018\u001a\u00020\b2\u0006\u0010\u0019\u001a\u00020\bH\u0080\b\u001a\u001d\u0010D\u001a\u00020\u0012*\u00020\u00132\u0006\u0010E\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0005H\u0080\b\u001a)\u0010D\u001a\u00020\u0013*\u00020\u00132\u0006\u0010F\u001a\u00020%2\b\b\u0002\u0010\u0018\u001a\u00020\b2\b\b\u0002\u0010\u0019\u001a\u00020\bH\u0080\b\u001a\u001d\u0010D\u001a\u00020\u0013*\u00020\u00132\u0006\u0010E\u001a\u00020G2\u0006\u0010\u0019\u001a\u00020\u0005H\u0080\b\u001a\u0015\u0010H\u001a\u00020\u0005*\u00020\u00132\u0006\u0010E\u001a\u00020GH\u0080\b\u001a\u0015\u0010I\u001a\u00020\u0013*\u00020\u00132\u0006\u0010\"\u001a\u00020\bH\u0080\b\u001a\u0015\u0010J\u001a\u00020\u0013*\u00020\u00132\u0006\u0010K\u001a\u00020\u0005H\u0080\b\u001a\u0015\u0010L\u001a\u00020\u0013*\u00020\u00132\u0006\u0010K\u001a\u00020\u0005H\u0080\b\u001a\u0015\u0010M\u001a\u00020\u0013*\u00020\u00132\u0006\u0010N\u001a\u00020\bH\u0080\b\u001a\u0015\u0010O\u001a\u00020\u0013*\u00020\u00132\u0006\u0010K\u001a\u00020\u0005H\u0080\b\u001a\u0015\u0010P\u001a\u00020\u0013*\u00020\u00132\u0006\u0010Q\u001a\u00020\bH\u0080\b\u001a%\u0010R\u001a\u00020\u0013*\u00020\u00132\u0006\u0010S\u001a\u0002082\u0006\u0010T\u001a\u00020\b2\u0006\u0010U\u001a\u00020\bH\u0080\b\u001a\u0015\u0010V\u001a\u00020\u0013*\u00020\u00132\u0006\u0010W\u001a\u00020\bH\u0080\b\u001a\u0014\u0010X\u001a\u000208*\u00020\u00132\u0006\u0010Y\u001a\u00020\u0005H\u0000\u001a?\u0010Z\u001a\u0002H[\"\u0004\b\u0000\u0010[*\u00020\u00132\u0006\u0010#\u001a\u00020\u00052\u001a\u0010\\\u001a\u0016\u0012\u0006\u0012\u0004\u0018\u00010\f\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u0002H[0]H\u0080\bø\u0001\u0000¢\u0006\u0002\u0010^\u001a\u001e\u0010_\u001a\u00020\b*\u00020\u00132\u0006\u0010>\u001a\u00020?2\b\b\u0002\u0010`\u001a\u00020\nH\u0000\"\u0014\u0010\u0000\u001a\u00020\u0001X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003\"\u000e\u0010\u0004\u001a\u00020\u0005X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0006\u001a\u00020\u0005X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0007\u001a\u00020\bX\u0080T¢\u0006\u0002\n\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006a"},
   d2 = {"HEX_DIGIT_BYTES", "", "getHEX_DIGIT_BYTES", "()[B", "OVERFLOW_DIGIT_START", "", "OVERFLOW_ZONE", "SEGMENTING_THRESHOLD", "", "rangeEquals", "", "segment", "Li/Segment;", "segmentPos", "bytes", "bytesOffset", "bytesLimit", "commonClear", "", "Li/Buffer;", "commonCompleteSegmentByteCount", "commonCopy", "commonCopyTo", "out", "offset", "byteCount", "commonEquals", "other", "", "commonGet", "", "pos", "commonHashCode", "commonIndexOf", "b", "fromIndex", "toIndex", "Li/ByteString;", "commonIndexOfElement", "targetBytes", "commonRangeEquals", "commonRead", "sink", "commonReadAll", "Li/Sink;", "commonReadByte", "commonReadByteArray", "commonReadByteString", "commonReadDecimalLong", "commonReadFully", "commonReadHexadecimalUnsignedLong", "commonReadInt", "commonReadLong", "commonReadShort", "", "commonReadUtf8", "", "commonReadUtf8CodePoint", "commonReadUtf8Line", "commonReadUtf8LineStrict", "limit", "commonSelect", "options", "Li/Options;", "commonSkip", "commonSnapshot", "commonWritableSegment", "minimumCapacity", "commonWrite", "source", "byteString", "Li/Source;", "commonWriteAll", "commonWriteByte", "commonWriteDecimalLong", "v", "commonWriteHexadecimalUnsignedLong", "commonWriteInt", "i", "commonWriteLong", "commonWriteShort", "s", "commonWriteUtf8", "string", "beginIndex", "endIndex", "commonWriteUtf8CodePoint", "codePoint", "readUtf8Line", "newline", "seek", "T", "lambda", "Lk/Function2;", "(Lokio/Buffer;JLkotlin/jvm/functions/Function2;)Ljava/lang/Object;", "selectPrefix", "selectTruncated", "i"}
)
public final class BufferKt {
   @NotNull
   private static final byte[] HEX_DIGIT_BYTES = -Platform.asUtf8ToByteArray("0123456789abcdef");
   public static final int SEGMENTING_THRESHOLD = 4096;
   public static final long OVERFLOW_ZONE = -922337203685477580L;
   public static final long OVERFLOW_DIGIT_START = -7L;

   @NotNull
   public static final byte[] getHEX_DIGIT_BYTES() {
      return HEX_DIGIT_BYTES;
   }

   public static final boolean rangeEquals(@NotNull Segment segment, int segmentPos, @NotNull byte[] bytes, int bytesOffset, int bytesLimit) {
      Intrinsics.checkNotNullParameter(segment, "segment");
      Intrinsics.checkNotNullParameter(bytes, "bytes");
      Segment segment = segment;
      int segmentPos = segmentPos;
      int segmentLimit = segment.limit;
      byte[] data = segment.data;

      for(int i = bytesOffset; i < bytesLimit; ++i) {
         if (segmentPos == segmentLimit) {
            Segment var10000 = segment.next;
            Intrinsics.checkNotNull(var10000);
            segment = var10000;
            data = segment.data;
            segmentPos = segment.pos;
            segmentLimit = segment.limit;
         }

         if (data[segmentPos] != bytes[i]) {
            return false;
         }

         ++segmentPos;
      }

      return true;
   }

   @NotNull
   public static final String readUtf8Line(@NotNull Buffer $this$readUtf8Line, long newline) {
      Intrinsics.checkNotNullParameter($this$readUtf8Line, "$this$readUtf8Line");
      String var10000;
      String result;
      if (newline > 0L && $this$readUtf8Line.getByte(newline - 1L) == (byte)13) {
         result = $this$readUtf8Line.readUtf8(newline - 1L);
         $this$readUtf8Line.skip(2L);
         var10000 = result;
      } else {
         result = $this$readUtf8Line.readUtf8(newline);
         $this$readUtf8Line.skip(1L);
         var10000 = result;
      }

      return var10000;
   }

   public static final <T> T seek(@NotNull Buffer $this$seek, long fromIndex, @NotNull Function2<? super Segment, ? super Long, ? extends T> lambda) {
      int $i$f$seek = 0;
      Intrinsics.checkNotNullParameter($this$seek, "$this$seek");
      Intrinsics.checkNotNullParameter(lambda, "lambda");
      Segment var10000 = $this$seek.head;
      if (var10000 == null) {
         return lambda.invoke((Object)null, -1L);
      } else {
         Segment s = var10000;
         long offset;
         if ($this$seek.size() - fromIndex < fromIndex) {
            for(offset = $this$seek.size(); offset > fromIndex; offset -= (long)(s.limit - s.pos)) {
               var10000 = s.prev;
               Intrinsics.checkNotNull(var10000);
               s = var10000;
            }

            return lambda.invoke(s, offset);
         } else {
            offset = 0L;

            while(true) {
               long nextOffset = offset + (long)(s.limit - s.pos);
               if (nextOffset > fromIndex) {
                  return lambda.invoke(s, offset);
               }

               var10000 = s.next;
               Intrinsics.checkNotNull(var10000);
               s = var10000;
               offset = nextOffset;
            }
         }
      }
   }

   public static final int selectPrefix(@NotNull Buffer $this$selectPrefix, @NotNull Options options, boolean selectTruncated) {
      Intrinsics.checkNotNullParameter($this$selectPrefix, "$this$selectPrefix");
      Intrinsics.checkNotNullParameter(options, "options");
      Segment var10000 = $this$selectPrefix.head;
      if (var10000 == null) {
         return selectTruncated ? -2 : -1;
      } else {
         Segment head = var10000;
         Segment s = head;
         byte[] data = head.data;
         int pos = head.pos;
         int limit = head.limit;
         int[] trie = options.getTrie$okio();
         int triePos = 0;
         int prefixIndex = -1;

         while(true) {
            int scanOrSelect = trie[triePos++];
            int possiblePrefixIndex = trie[triePos++];
            if (possiblePrefixIndex != -1) {
               prefixIndex = possiblePrefixIndex;
            }

            int nextStep;
            label104: {
               int nextStep = false;
               if (s != null) {
                  int trieLimit;
                  int selectLimit;
                  if (scanOrSelect >= 0) {
                     byte $this$and$iv = data[pos++];
                     int other$iv = 255;
                     int $i$f$and = false;
                     trieLimit = $this$and$iv & other$iv;

                     for(selectLimit = triePos + scanOrSelect; triePos != selectLimit; ++triePos) {
                        if (trieLimit == trie[triePos]) {
                           nextStep = trie[triePos + scanOrSelect];
                           if (pos == limit) {
                              var10000 = s.next;
                              Intrinsics.checkNotNull(var10000);
                              s = var10000;
                              pos = s.pos;
                              data = s.data;
                              limit = s.limit;
                              if (s == head) {
                                 s = (Segment)null;
                              }
                           }
                           break label104;
                        }
                     }

                     return prefixIndex;
                  }

                  int scanByteCount = -1 * scanOrSelect;
                  trieLimit = triePos + scanByteCount;

                  while(true) {
                     byte $this$and$iv = data[pos++];
                     int other$iv = 255;
                     int $i$f$and = false;
                     selectLimit = $this$and$iv & other$iv;
                     if (selectLimit != trie[triePos++]) {
                        return prefixIndex;
                     }

                     boolean scanComplete = triePos == trieLimit;
                     if (pos == limit) {
                        Intrinsics.checkNotNull(s);
                        var10000 = s.next;
                        Intrinsics.checkNotNull(var10000);
                        s = var10000;
                        pos = s.pos;
                        data = s.data;
                        limit = s.limit;
                        if (s == head) {
                           if (!scanComplete) {
                              break;
                           }

                           s = (Segment)null;
                        }
                     }

                     if (scanComplete) {
                        nextStep = trie[triePos];
                        break label104;
                     }
                  }
               }

               if (selectTruncated) {
                  return -2;
               }

               return prefixIndex;
            }

            if (nextStep >= 0) {
               return nextStep;
            }

            triePos = -nextStep;
         }
      }
   }

   // $FF: synthetic method
   public static int selectPrefix$default(Buffer var0, Options var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return selectPrefix(var0, var1, var2);
   }

   @NotNull
   public static final Buffer commonCopyTo(@NotNull Buffer $this$commonCopyTo, @NotNull Buffer out, long offset, long byteCount) {
      int $i$f$commonCopyTo = 0;
      Intrinsics.checkNotNullParameter($this$commonCopyTo, "$this$commonCopyTo");
      Intrinsics.checkNotNullParameter(out, "out");
      long offset = offset;
      long byteCount = byteCount;
      -Util.checkOffsetAndCount($this$commonCopyTo.size(), offset, byteCount);
      if (byteCount == 0L) {
         return $this$commonCopyTo;
      } else {
         out.setSize$okio(out.size() + byteCount);
         Segment s = $this$commonCopyTo.head;

         while(true) {
            Intrinsics.checkNotNull(s);
            if (offset < (long)(s.limit - s.pos)) {
               while(byteCount > 0L) {
                  Intrinsics.checkNotNull(s);
                  Segment copy = s.sharedCopy();
                  copy.pos += (int)offset;
                  int var13 = copy.pos + (int)byteCount;
                  int var14 = copy.limit;
                  boolean var15 = false;
                  copy.limit = Math.min(var13, var14);
                  if (out.head == null) {
                     copy.prev = copy;
                     copy.next = copy.prev;
                     out.head = copy.next;
                  } else {
                     Segment var10000 = out.head;
                     Intrinsics.checkNotNull(var10000);
                     var10000 = var10000.prev;
                     Intrinsics.checkNotNull(var10000);
                     var10000.push(copy);
                  }

                  byteCount -= (long)(copy.limit - copy.pos);
                  offset = 0L;
                  s = s.next;
               }

               return $this$commonCopyTo;
            }

            offset -= (long)(s.limit - s.pos);
            s = s.next;
         }
      }
   }

   public static final long commonCompleteSegmentByteCount(@NotNull Buffer $this$commonCompleteSegmentByteCount) {
      int $i$f$commonCompleteSegmentByteCount = 0;
      Intrinsics.checkNotNullParameter($this$commonCompleteSegmentByteCount, "$this$commonCompleteSegmentByteCount");
      long result = $this$commonCompleteSegmentByteCount.size();
      if (result == 0L) {
         return 0L;
      } else {
         Segment var10000 = $this$commonCompleteSegmentByteCount.head;
         Intrinsics.checkNotNull(var10000);
         var10000 = var10000.prev;
         Intrinsics.checkNotNull(var10000);
         Segment tail = var10000;
         if (tail.limit < 8192 && tail.owner) {
            result -= (long)(tail.limit - tail.pos);
         }

         return result;
      }
   }

   public static final byte commonReadByte(@NotNull Buffer $this$commonReadByte) {
      int $i$f$commonReadByte = 0;
      Intrinsics.checkNotNullParameter($this$commonReadByte, "$this$commonReadByte");
      if ($this$commonReadByte.size() == 0L) {
         throw (Throwable)(new EOFException());
      } else {
         Segment var10000 = $this$commonReadByte.head;
         Intrinsics.checkNotNull(var10000);
         Segment segment = var10000;
         int pos = segment.pos;
         int limit = segment.limit;
         byte[] data = segment.data;
         byte b = data[pos++];
         $this$commonReadByte.setSize$okio($this$commonReadByte.size() - 1L);
         if (pos == limit) {
            $this$commonReadByte.head = segment.pop();
            SegmentPool.recycle(segment);
         } else {
            segment.pos = pos;
         }

         return b;
      }
   }

   public static final short commonReadShort(@NotNull Buffer $this$commonReadShort) {
      int $i$f$commonReadShort = 0;
      Intrinsics.checkNotNullParameter($this$commonReadShort, "$this$commonReadShort");
      if ($this$commonReadShort.size() < 2L) {
         throw (Throwable)(new EOFException());
      } else {
         Segment var10000 = $this$commonReadShort.head;
         Intrinsics.checkNotNull(var10000);
         Segment segment = var10000;
         int pos = segment.pos;
         int limit = segment.limit;
         int var14;
         if (limit - pos < 2) {
            byte $this$and$iv = $this$commonReadShort.readByte();
            int other$iv = 255;
            int $i$f$and = false;
            var14 = ($this$and$iv & other$iv) << 8;
            $this$and$iv = $this$commonReadShort.readByte();
            other$iv = 255;
            $i$f$and = false;
            int s = var14 | $this$and$iv & other$iv;
            return (short)s;
         } else {
            byte[] data = segment.data;
            byte $this$and$iv = data[pos++];
            int other$iv = 255;
            int $i$f$and = false;
            var14 = ($this$and$iv & other$iv) << 8;
            $this$and$iv = data[pos++];
            other$iv = 255;
            $i$f$and = false;
            int s = var14 | $this$and$iv & other$iv;
            $this$commonReadShort.setSize$okio($this$commonReadShort.size() - 2L);
            if (pos == limit) {
               $this$commonReadShort.head = segment.pop();
               SegmentPool.recycle(segment);
            } else {
               segment.pos = pos;
            }

            return (short)s;
         }
      }
   }

   public static final int commonReadInt(@NotNull Buffer $this$commonReadInt) {
      int $i$f$commonReadInt = 0;
      Intrinsics.checkNotNullParameter($this$commonReadInt, "$this$commonReadInt");
      if ($this$commonReadInt.size() < 4L) {
         throw (Throwable)(new EOFException());
      } else {
         Segment var10000 = $this$commonReadInt.head;
         Intrinsics.checkNotNull(var10000);
         Segment segment = var10000;
         int pos = segment.pos;
         int limit = segment.limit;
         int var13;
         if ((long)(limit - pos) < 4L) {
            byte $this$and$iv = $this$commonReadInt.readByte();
            int other$iv = 255;
            int $i$f$and = false;
            var13 = ($this$and$iv & other$iv) << 24;
            $this$and$iv = $this$commonReadInt.readByte();
            other$iv = 255;
            $i$f$and = false;
            var13 |= ($this$and$iv & other$iv) << 16;
            $this$and$iv = $this$commonReadInt.readByte();
            other$iv = 255;
            $i$f$and = false;
            var13 |= ($this$and$iv & other$iv) << 8;
            $this$and$iv = $this$commonReadInt.readByte();
            other$iv = 255;
            $i$f$and = false;
            return var13 | $this$and$iv & other$iv;
         } else {
            byte[] data = segment.data;
            byte $this$and$iv = data[pos++];
            int other$iv = 255;
            int $i$f$and = false;
            var13 = ($this$and$iv & other$iv) << 24;
            $this$and$iv = data[pos++];
            other$iv = 255;
            $i$f$and = false;
            var13 |= ($this$and$iv & other$iv) << 16;
            $this$and$iv = data[pos++];
            other$iv = 255;
            $i$f$and = false;
            var13 |= ($this$and$iv & other$iv) << 8;
            $this$and$iv = data[pos++];
            other$iv = 255;
            $i$f$and = false;
            int i = var13 | $this$and$iv & other$iv;
            $this$commonReadInt.setSize$okio($this$commonReadInt.size() - 4L);
            if (pos == limit) {
               $this$commonReadInt.head = segment.pop();
               SegmentPool.recycle(segment);
            } else {
               segment.pos = pos;
            }

            return i;
         }
      }
   }

   public static final long commonReadLong(@NotNull Buffer $this$commonReadLong) {
      int $i$f$commonReadLong = 0;
      Intrinsics.checkNotNullParameter($this$commonReadLong, "$this$commonReadLong");
      if ($this$commonReadLong.size() < 8L) {
         throw (Throwable)(new EOFException());
      } else {
         Segment var10000 = $this$commonReadLong.head;
         Intrinsics.checkNotNull(var10000);
         Segment segment = var10000;
         int pos = segment.pos;
         int limit = segment.limit;
         long v;
         long var14;
         if ((long)(limit - pos) < 8L) {
            int $this$and$iv = $this$commonReadLong.readInt();
            v = 4294967295L;
            int $i$f$and = false;
            var14 = ((long)$this$and$iv & v) << 32;
            $this$and$iv = $this$commonReadLong.readInt();
            v = 4294967295L;
            $i$f$and = false;
            return var14 | (long)$this$and$iv & v;
         } else {
            byte[] data = segment.data;
            byte $this$and$iv = data[pos++];
            long other$iv = 255L;
            int $i$f$and = false;
            var14 = ((long)$this$and$iv & other$iv) << 56;
            $this$and$iv = data[pos++];
            other$iv = 255L;
            $i$f$and = false;
            var14 |= ((long)$this$and$iv & other$iv) << 48;
            $this$and$iv = data[pos++];
            other$iv = 255L;
            $i$f$and = false;
            var14 |= ((long)$this$and$iv & other$iv) << 40;
            $this$and$iv = data[pos++];
            other$iv = 255L;
            $i$f$and = false;
            var14 |= ((long)$this$and$iv & other$iv) << 32;
            $this$and$iv = data[pos++];
            other$iv = 255L;
            $i$f$and = false;
            var14 |= ((long)$this$and$iv & other$iv) << 24;
            $this$and$iv = data[pos++];
            other$iv = 255L;
            $i$f$and = false;
            var14 |= ((long)$this$and$iv & other$iv) << 16;
            $this$and$iv = data[pos++];
            other$iv = 255L;
            $i$f$and = false;
            var14 |= ((long)$this$and$iv & other$iv) << 8;
            $this$and$iv = data[pos++];
            other$iv = 255L;
            $i$f$and = false;
            v = var14 | (long)$this$and$iv & other$iv;
            $this$commonReadLong.setSize$okio($this$commonReadLong.size() - 8L);
            if (pos == limit) {
               $this$commonReadLong.head = segment.pop();
               SegmentPool.recycle(segment);
            } else {
               segment.pos = pos;
            }

            return v;
         }
      }
   }

   public static final byte commonGet(@NotNull Buffer $this$commonGet, long pos) {
      int $i$f$commonGet = 0;
      Intrinsics.checkNotNullParameter($this$commonGet, "$this$commonGet");
      -Util.checkOffsetAndCount($this$commonGet.size(), pos, 1L);
      int $i$f$seek = false;
      Segment var10000 = $this$commonGet.head;
      long nextOffset$iv;
      if (var10000 == null) {
         nextOffset$iv = -1L;
         Segment s = (Segment)null;
         int var9 = false;
         Intrinsics.checkNotNull(s);
         return s.data[(int)((long)s.pos + pos - nextOffset$iv)];
      } else {
         Segment s$iv = var10000;
         long offset$iv;
         if ($this$commonGet.size() - pos < pos) {
            for(offset$iv = $this$commonGet.size(); offset$iv > pos; offset$iv -= (long)(s$iv.limit - s$iv.pos)) {
               var10000 = s$iv.prev;
               Intrinsics.checkNotNull(var10000);
               s$iv = var10000;
            }

            int var16 = false;
            Intrinsics.checkNotNull(s$iv);
            return s$iv.data[(int)((long)s$iv.pos + pos - offset$iv)];
         } else {
            offset$iv = 0L;

            while(true) {
               nextOffset$iv = offset$iv + (long)(s$iv.limit - s$iv.pos);
               if (nextOffset$iv > pos) {
                  int var19 = false;
                  Intrinsics.checkNotNull(s$iv);
                  return s$iv.data[(int)((long)s$iv.pos + pos - offset$iv)];
               }

               var10000 = s$iv.next;
               Intrinsics.checkNotNull(var10000);
               s$iv = var10000;
               offset$iv = nextOffset$iv;
            }
         }
      }
   }

   public static final void commonClear(@NotNull Buffer $this$commonClear) {
      int $i$f$commonClear = 0;
      Intrinsics.checkNotNullParameter($this$commonClear, "$this$commonClear");
      $this$commonClear.skip($this$commonClear.size());
   }

   public static final void commonSkip(@NotNull Buffer $this$commonSkip, long byteCount) {
      int $i$f$commonSkip = 0;
      Intrinsics.checkNotNullParameter($this$commonSkip, "$this$commonSkip");
      long byteCount = byteCount;

      while(byteCount > 0L) {
         Segment var10000 = $this$commonSkip.head;
         if (var10000 == null) {
            throw (Throwable)(new EOFException());
         }

         Segment head = var10000;
         int b$iv = head.limit - head.pos;
         int $i$f$minOf = false;
         long var10 = (long)b$iv;
         boolean var12 = false;
         int toSkip = (int)Math.min(byteCount, var10);
         $this$commonSkip.setSize$okio($this$commonSkip.size() - (long)toSkip);
         byteCount -= (long)toSkip;
         head.pos += toSkip;
         if (head.pos == head.limit) {
            $this$commonSkip.head = head.pop();
            SegmentPool.recycle(head);
         }
      }

   }

   @NotNull
   public static final Buffer commonWrite(@NotNull Buffer $this$commonWrite, @NotNull ByteString byteString, int offset, int byteCount) {
      int $i$f$commonWrite = 0;
      Intrinsics.checkNotNullParameter($this$commonWrite, "$this$commonWrite");
      Intrinsics.checkNotNullParameter(byteString, "byteString");
      byteString.write$okio($this$commonWrite, offset, byteCount);
      return $this$commonWrite;
   }

   // $FF: synthetic method
   public static Buffer commonWrite$default(Buffer $this$commonWrite, ByteString byteString, int offset, int byteCount, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         offset = 0;
      }

      if ((var4 & 4) != 0) {
         byteCount = byteString.size();
      }

      int $i$f$commonWrite = false;
      Intrinsics.checkNotNullParameter($this$commonWrite, "$this$commonWrite");
      Intrinsics.checkNotNullParameter(byteString, "byteString");
      byteString.write$okio($this$commonWrite, offset, byteCount);
      return $this$commonWrite;
   }

   @NotNull
   public static final Buffer commonWriteDecimalLong(@NotNull Buffer $this$commonWriteDecimalLong, long v) {
      int $i$f$commonWriteDecimalLong = 0;
      Intrinsics.checkNotNullParameter($this$commonWriteDecimalLong, "$this$commonWriteDecimalLong");
      long v = v;
      if (v == 0L) {
         return $this$commonWriteDecimalLong.writeByte(48);
      } else {
         boolean negative = false;
         if (v < 0L) {
            v = -v;
            if (v < 0L) {
               return $this$commonWriteDecimalLong.writeUtf8("-9223372036854775808");
            }

            negative = true;
         }

         int width = v < 100000000L ? (v < 10000L ? (v < 100L ? (v < 10L ? 1 : 2) : (v < 1000L ? 3 : 4)) : (v < 1000000L ? (v < 100000L ? 5 : 6) : (v < 10000000L ? 7 : 8))) : (v < 1000000000000L ? (v < 10000000000L ? (v < 1000000000L ? 9 : 10) : (v < 100000000000L ? 11 : 12)) : (v < 1000000000000000L ? (v < 10000000000000L ? 13 : (v < 100000000000000L ? 14 : 15)) : (v < 100000000000000000L ? (v < 10000000000000000L ? 16 : 17) : (v < 1000000000000000000L ? 18 : 19))));
         if (negative) {
            ++width;
         }

         Segment tail = $this$commonWriteDecimalLong.writableSegment$okio(width);
         byte[] data = tail.data;

         int pos;
         for(pos = tail.limit + width; v != 0L; v /= (long)10) {
            int digit = (int)(v % (long)10);
            --pos;
            data[pos] = getHEX_DIGIT_BYTES()[digit];
         }

         if (negative) {
            --pos;
            data[pos] = (byte)45;
         }

         tail.limit += width;
         $this$commonWriteDecimalLong.setSize$okio($this$commonWriteDecimalLong.size() + (long)width);
         return $this$commonWriteDecimalLong;
      }
   }

   @NotNull
   public static final Buffer commonWriteHexadecimalUnsignedLong(@NotNull Buffer $this$commonWriteHexadecimalUnsignedLong, long v) {
      int $i$f$commonWriteHexadecimalUnsignedLong = 0;
      Intrinsics.checkNotNullParameter($this$commonWriteHexadecimalUnsignedLong, "$this$commonWriteHexadecimalUnsignedLong");
      long v = v;
      if (v == 0L) {
         return $this$commonWriteHexadecimalUnsignedLong.writeByte(48);
      } else {
         long x = v | v >>> 1;
         x |= x >>> 2;
         x |= x >>> 4;
         x |= x >>> 8;
         x |= x >>> 16;
         x |= x >>> 32;
         x -= x >>> 1 & 6148914691236517205L;
         x = (x >>> 2 & 3689348814741910323L) + (x & 3689348814741910323L);
         x = (x >>> 4) + x & 1085102592571150095L;
         x += x >>> 8;
         x += x >>> 16;
         x = (x & 63L) + (x >>> 32 & 63L);
         int width = (int)((x + (long)3) / (long)4);
         Segment tail = $this$commonWriteHexadecimalUnsignedLong.writableSegment$okio(width);
         byte[] data = tail.data;
         int pos = tail.limit + width - 1;

         for(int start = tail.limit; pos >= start; --pos) {
            data[pos] = getHEX_DIGIT_BYTES()[(int)(v & 15L)];
            v >>>= 4;
         }

         tail.limit += width;
         $this$commonWriteHexadecimalUnsignedLong.setSize$okio($this$commonWriteHexadecimalUnsignedLong.size() + (long)width);
         return $this$commonWriteHexadecimalUnsignedLong;
      }
   }

   @NotNull
   public static final Segment commonWritableSegment(@NotNull Buffer $this$commonWritableSegment, int minimumCapacity) {
      int $i$f$commonWritableSegment = 0;
      Intrinsics.checkNotNullParameter($this$commonWritableSegment, "$this$commonWritableSegment");
      boolean var3 = minimumCapacity >= 1 && minimumCapacity <= 8192;
      boolean var4 = false;
      boolean var5 = false;
      if (!var3) {
         int var6 = false;
         String var8 = "unexpected capacity";
         throw (Throwable)(new IllegalArgumentException(var8.toString()));
      } else {
         Segment tail;
         if ($this$commonWritableSegment.head == null) {
            tail = SegmentPool.take();
            $this$commonWritableSegment.head = tail;
            tail.prev = tail;
            tail.next = tail;
            return tail;
         } else {
            Segment var10000 = $this$commonWritableSegment.head;
            Intrinsics.checkNotNull(var10000);
            tail = var10000.prev;
            Intrinsics.checkNotNull(tail);
            if (tail.limit + minimumCapacity > 8192 || !tail.owner) {
               tail = tail.push(SegmentPool.take());
            }

            return tail;
         }
      }
   }

   @NotNull
   public static final Buffer commonWrite(@NotNull Buffer $this$commonWrite, @NotNull byte[] source) {
      int $i$f$commonWrite = 0;
      Intrinsics.checkNotNullParameter($this$commonWrite, "$this$commonWrite");
      Intrinsics.checkNotNullParameter(source, "source");
      return $this$commonWrite.write((byte[])source, 0, source.length);
   }

   @NotNull
   public static final Buffer commonWrite(@NotNull Buffer $this$commonWrite, @NotNull byte[] source, int offset, int byteCount) {
      int $i$f$commonWrite = 0;
      Intrinsics.checkNotNullParameter($this$commonWrite, "$this$commonWrite");
      Intrinsics.checkNotNullParameter(source, "source");
      int offset = offset;
      -Util.checkOffsetAndCount((long)source.length, (long)offset, (long)byteCount);

      Segment tail;
      int toCopy;
      for(int limit = offset + byteCount; offset < limit; tail.limit += toCopy) {
         tail = $this$commonWrite.writableSegment$okio(1);
         int var9 = limit - offset;
         int var10 = 8192 - tail.limit;
         boolean var11 = false;
         toCopy = Math.min(var9, var10);
         ArraysKt.copyInto(source, tail.data, tail.limit, offset, offset + toCopy);
         offset += toCopy;
      }

      $this$commonWrite.setSize$okio($this$commonWrite.size() + (long)byteCount);
      return $this$commonWrite;
   }

   @NotNull
   public static final byte[] commonReadByteArray(@NotNull Buffer $this$commonReadByteArray) {
      int $i$f$commonReadByteArray = 0;
      Intrinsics.checkNotNullParameter($this$commonReadByteArray, "$this$commonReadByteArray");
      return $this$commonReadByteArray.readByteArray($this$commonReadByteArray.size());
   }

   @NotNull
   public static final byte[] commonReadByteArray(@NotNull Buffer $this$commonReadByteArray, long byteCount) {
      int $i$f$commonReadByteArray = 0;
      Intrinsics.checkNotNullParameter($this$commonReadByteArray, "$this$commonReadByteArray");
      boolean var4 = byteCount >= 0L && byteCount <= (long)Integer.MAX_VALUE;
      boolean var5 = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var9 = "byteCount: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var9.toString()));
      } else if ($this$commonReadByteArray.size() < byteCount) {
         throw (Throwable)(new EOFException());
      } else {
         byte[] result = new byte[(int)byteCount];
         $this$commonReadByteArray.readFully(result);
         return result;
      }
   }

   public static final int commonRead(@NotNull Buffer $this$commonRead, @NotNull byte[] sink) {
      int $i$f$commonRead = 0;
      Intrinsics.checkNotNullParameter($this$commonRead, "$this$commonRead");
      Intrinsics.checkNotNullParameter(sink, "sink");
      return $this$commonRead.read(sink, 0, sink.length);
   }

   public static final void commonReadFully(@NotNull Buffer $this$commonReadFully, @NotNull byte[] sink) {
      int $i$f$commonReadFully = 0;
      Intrinsics.checkNotNullParameter($this$commonReadFully, "$this$commonReadFully");
      Intrinsics.checkNotNullParameter(sink, "sink");

      int read;
      for(int offset = 0; offset < sink.length; offset += read) {
         read = $this$commonReadFully.read(sink, offset, sink.length - offset);
         if (read == -1) {
            throw (Throwable)(new EOFException());
         }
      }

   }

   public static final int commonRead(@NotNull Buffer $this$commonRead, @NotNull byte[] sink, int offset, int byteCount) {
      int $i$f$commonRead = 0;
      Intrinsics.checkNotNullParameter($this$commonRead, "$this$commonRead");
      Intrinsics.checkNotNullParameter(sink, "sink");
      -Util.checkOffsetAndCount((long)sink.length, (long)offset, (long)byteCount);
      Segment var10000 = $this$commonRead.head;
      if (var10000 != null) {
         Segment s = var10000;
         int var7 = s.limit - s.pos;
         boolean var8 = false;
         int toCopy = Math.min(byteCount, var7);
         ArraysKt.copyInto(s.data, sink, offset, s.pos, s.pos + toCopy);
         s.pos += toCopy;
         $this$commonRead.setSize$okio($this$commonRead.size() - (long)toCopy);
         if (s.pos == s.limit) {
            $this$commonRead.head = s.pop();
            SegmentPool.recycle(s);
         }

         return toCopy;
      } else {
         return -1;
      }
   }

   public static final long commonReadDecimalLong(@NotNull Buffer $this$commonReadDecimalLong) {
      int $i$f$commonReadDecimalLong = 0;
      Intrinsics.checkNotNullParameter($this$commonReadDecimalLong, "$this$commonReadDecimalLong");
      if ($this$commonReadDecimalLong.size() == 0L) {
         throw (Throwable)(new EOFException());
      } else {
         long value = 0L;
         int seen = 0;
         boolean negative = false;
         boolean done = false;
         long overflowDigit = -7L;

         while(true) {
            Segment var10000 = $this$commonReadDecimalLong.head;
            Intrinsics.checkNotNull(var10000);
            Segment segment = var10000;
            byte[] data = segment.data;
            int pos = segment.pos;
            int limit = segment.limit;

            while(true) {
               label72: {
                  if (pos < limit) {
                     byte b = data[pos];
                     if (b >= (byte)48 && b <= (byte)57) {
                        int digit = (byte)48 - b;
                        if (value < -922337203685477580L || value == -922337203685477580L && (long)digit < overflowDigit) {
                           Buffer buffer = (new Buffer()).writeDecimalLong(value).writeByte(b);
                           if (!negative) {
                              buffer.readByte();
                           }

                           throw (Throwable)(new NumberFormatException("Number too large: " + buffer.readUtf8()));
                        }

                        value *= 10L;
                        value += (long)digit;
                        break label72;
                     }

                     if (b == (byte)45 && seen == 0) {
                        negative = true;
                        --overflowDigit;
                        break label72;
                     }

                     if (seen == 0) {
                        throw (Throwable)(new NumberFormatException("Expected leading [0-9] or '-' character but was 0x" + -Util.toHexString(b)));
                     }

                     done = true;
                  }

                  if (pos == limit) {
                     $this$commonReadDecimalLong.head = segment.pop();
                     SegmentPool.recycle(segment);
                  } else {
                     segment.pos = pos;
                  }

                  if (!done && $this$commonReadDecimalLong.head != null) {
                     break;
                  }

                  $this$commonReadDecimalLong.setSize$okio($this$commonReadDecimalLong.size() - (long)seen);
                  return negative ? value : -value;
               }

               ++pos;
               ++seen;
            }
         }
      }
   }

   public static final long commonReadHexadecimalUnsignedLong(@NotNull Buffer $this$commonReadHexadecimalUnsignedLong) {
      int $i$f$commonReadHexadecimalUnsignedLong = 0;
      Intrinsics.checkNotNullParameter($this$commonReadHexadecimalUnsignedLong, "$this$commonReadHexadecimalUnsignedLong");
      if ($this$commonReadHexadecimalUnsignedLong.size() == 0L) {
         throw (Throwable)(new EOFException());
      } else {
         long value = 0L;
         int seen = 0;
         boolean done = false;

         do {
            Segment var10000 = $this$commonReadHexadecimalUnsignedLong.head;
            Intrinsics.checkNotNull(var10000);
            Segment segment = var10000;
            byte[] data = segment.data;
            int pos = segment.pos;

            int limit;
            for(limit = segment.limit; pos < limit; ++seen) {
               int digit = false;
               byte b = data[pos];
               int digit;
               if (b >= (byte)48 && b <= (byte)57) {
                  digit = b - (byte)48;
               } else if (b >= (byte)97 && b <= (byte)102) {
                  digit = b - (byte)97 + 10;
               } else {
                  if (b < (byte)65 || b > (byte)70) {
                     if (seen == 0) {
                        throw (Throwable)(new NumberFormatException("Expected leading [0-9a-fA-F] character but was 0x" + -Util.toHexString(b)));
                     }

                     done = true;
                     break;
                  }

                  digit = b - (byte)65 + 10;
               }

               if ((value & -1152921504606846976L) != 0L) {
                  Buffer buffer = (new Buffer()).writeHexadecimalUnsignedLong(value).writeByte(b);
                  throw (Throwable)(new NumberFormatException("Number too large: " + buffer.readUtf8()));
               }

               value <<= 4;
               value |= (long)digit;
               ++pos;
            }

            if (pos == limit) {
               $this$commonReadHexadecimalUnsignedLong.head = segment.pop();
               SegmentPool.recycle(segment);
            } else {
               segment.pos = pos;
            }
         } while(!done && $this$commonReadHexadecimalUnsignedLong.head != null);

         $this$commonReadHexadecimalUnsignedLong.setSize$okio($this$commonReadHexadecimalUnsignedLong.size() - (long)seen);
         return value;
      }
   }

   @NotNull
   public static final ByteString commonReadByteString(@NotNull Buffer $this$commonReadByteString) {
      int $i$f$commonReadByteString = 0;
      Intrinsics.checkNotNullParameter($this$commonReadByteString, "$this$commonReadByteString");
      return $this$commonReadByteString.readByteString($this$commonReadByteString.size());
   }

   @NotNull
   public static final ByteString commonReadByteString(@NotNull Buffer $this$commonReadByteString, long byteCount) {
      int $i$f$commonReadByteString = 0;
      Intrinsics.checkNotNullParameter($this$commonReadByteString, "$this$commonReadByteString");
      boolean var4 = byteCount >= 0L && byteCount <= (long)Integer.MAX_VALUE;
      boolean var5 = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var10 = "byteCount: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var10.toString()));
      } else if ($this$commonReadByteString.size() < byteCount) {
         throw (Throwable)(new EOFException());
      } else if (byteCount >= (long)4096) {
         ByteString var9 = $this$commonReadByteString.snapshot((int)byteCount);
         var5 = false;
         var6 = false;
         int var8 = false;
         $this$commonReadByteString.skip(byteCount);
         return var9;
      } else {
         return new ByteString($this$commonReadByteString.readByteArray(byteCount));
      }
   }

   public static final int commonSelect(@NotNull Buffer $this$commonSelect, @NotNull Options options) {
      int $i$f$commonSelect = 0;
      Intrinsics.checkNotNullParameter($this$commonSelect, "$this$commonSelect");
      Intrinsics.checkNotNullParameter(options, "options");
      int index = selectPrefix$default($this$commonSelect, options, false, 2, (Object)null);
      if (index == -1) {
         return -1;
      } else {
         int selectedSize = options.getByteStrings$okio()[index].size();
         $this$commonSelect.skip((long)selectedSize);
         return index;
      }
   }

   public static final void commonReadFully(@NotNull Buffer $this$commonReadFully, @NotNull Buffer sink, long byteCount) {
      int $i$f$commonReadFully = 0;
      Intrinsics.checkNotNullParameter($this$commonReadFully, "$this$commonReadFully");
      Intrinsics.checkNotNullParameter(sink, "sink");
      if ($this$commonReadFully.size() < byteCount) {
         sink.write($this$commonReadFully, $this$commonReadFully.size());
         throw (Throwable)(new EOFException());
      } else {
         sink.write($this$commonReadFully, byteCount);
      }
   }

   public static final long commonReadAll(@NotNull Buffer $this$commonReadAll, @NotNull Sink sink) {
      int $i$f$commonReadAll = 0;
      Intrinsics.checkNotNullParameter($this$commonReadAll, "$this$commonReadAll");
      Intrinsics.checkNotNullParameter(sink, "sink");
      long byteCount = $this$commonReadAll.size();
      if (byteCount > 0L) {
         sink.write($this$commonReadAll, byteCount);
      }

      return byteCount;
   }

   @NotNull
   public static final String commonReadUtf8(@NotNull Buffer $this$commonReadUtf8, long byteCount) {
      int $i$f$commonReadUtf8 = 0;
      Intrinsics.checkNotNullParameter($this$commonReadUtf8, "$this$commonReadUtf8");
      boolean var4 = byteCount >= 0L && byteCount <= (long)Integer.MAX_VALUE;
      boolean var5 = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var10 = "byteCount: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var10.toString()));
      } else if ($this$commonReadUtf8.size() < byteCount) {
         throw (Throwable)(new EOFException());
      } else if (byteCount == 0L) {
         return "";
      } else {
         Segment var10000 = $this$commonReadUtf8.head;
         Intrinsics.checkNotNull(var10000);
         Segment s = var10000;
         if ((long)s.pos + byteCount > (long)s.limit) {
            return _Utf8Kt.commonToUtf8String$default($this$commonReadUtf8.readByteArray(byteCount), 0, 0, 3, (Object)null);
         } else {
            String result = _Utf8Kt.commonToUtf8String(s.data, s.pos, s.pos + (int)byteCount);
            s.pos += (int)byteCount;
            $this$commonReadUtf8.setSize$okio($this$commonReadUtf8.size() - byteCount);
            if (s.pos == s.limit) {
               $this$commonReadUtf8.head = s.pop();
               SegmentPool.recycle(s);
            }

            return result;
         }
      }
   }

   @Nullable
   public static final String commonReadUtf8Line(@NotNull Buffer $this$commonReadUtf8Line) {
      int $i$f$commonReadUtf8Line = 0;
      Intrinsics.checkNotNullParameter($this$commonReadUtf8Line, "$this$commonReadUtf8Line");
      long newline = $this$commonReadUtf8Line.indexOf((byte)10);
      return newline != -1L ? readUtf8Line($this$commonReadUtf8Line, newline) : ($this$commonReadUtf8Line.size() != 0L ? $this$commonReadUtf8Line.readUtf8($this$commonReadUtf8Line.size()) : null);
   }

   @NotNull
   public static final String commonReadUtf8LineStrict(@NotNull Buffer $this$commonReadUtf8LineStrict, long limit) {
      int $i$f$commonReadUtf8LineStrict = 0;
      Intrinsics.checkNotNullParameter($this$commonReadUtf8LineStrict, "$this$commonReadUtf8LineStrict");
      boolean var4 = limit >= 0L;
      boolean var5 = false;
      boolean var6 = false;
      if (!var4) {
         int var7 = false;
         String var18 = "limit < 0: " + limit;
         throw (Throwable)(new IllegalArgumentException(var18.toString()));
      } else {
         long scanLength = limit == Long.MAX_VALUE ? Long.MAX_VALUE : limit + 1L;
         long newline = $this$commonReadUtf8LineStrict.indexOf((byte)10, 0L, scanLength);
         if (newline != -1L) {
            return readUtf8Line($this$commonReadUtf8LineStrict, newline);
         } else if (scanLength < $this$commonReadUtf8LineStrict.size() && $this$commonReadUtf8LineStrict.getByte(scanLength - 1L) == (byte)13 && $this$commonReadUtf8LineStrict.getByte(scanLength) == (byte)10) {
            return readUtf8Line($this$commonReadUtf8LineStrict, scanLength);
         } else {
            Buffer data = new Buffer();
            byte a$iv = 32;
            long b$iv = $this$commonReadUtf8LineStrict.size();
            int $i$f$minOf = false;
            long var13 = (long)a$iv;
            boolean var15 = false;
            $this$commonReadUtf8LineStrict.copyTo(data, 0L, Math.min(var13, b$iv));
            StringBuilder var10002 = (new StringBuilder()).append("\\n not found: limit=");
            long var19 = $this$commonReadUtf8LineStrict.size();
            boolean var11 = false;
            throw (Throwable)(new EOFException(var10002.append(Math.min(var19, limit)).append(" content=").append(data.readByteString().hex()).append('…').toString()));
         }
      }
   }

   public static final int commonReadUtf8CodePoint(@NotNull Buffer $this$commonReadUtf8CodePoint) {
      int $i$f$commonReadUtf8CodePoint = 0;
      Intrinsics.checkNotNullParameter($this$commonReadUtf8CodePoint, "$this$commonReadUtf8CodePoint");
      if ($this$commonReadUtf8CodePoint.size() == 0L) {
         throw (Throwable)(new EOFException());
      } else {
         byte b0 = $this$commonReadUtf8CodePoint.getByte(0L);
         int codePoint = false;
         int byteCount = false;
         int min = false;
         int other$iv = 128;
         int $i$f$and = false;
         int codePoint;
         byte byteCount;
         int min;
         byte other$iv;
         if ((b0 & other$iv) == 0) {
            other$iv = 127;
            $i$f$and = false;
            codePoint = b0 & other$iv;
            byteCount = 1;
            min = 0;
         } else {
            other$iv = 224;
            $i$f$and = false;
            if ((b0 & other$iv) == 192) {
               other$iv = 31;
               $i$f$and = false;
               codePoint = b0 & other$iv;
               byteCount = 2;
               min = 128;
            } else {
               other$iv = 240;
               $i$f$and = false;
               if ((b0 & other$iv) == 224) {
                  other$iv = 15;
                  $i$f$and = false;
                  codePoint = b0 & other$iv;
                  byteCount = 3;
                  min = 2048;
               } else {
                  other$iv = 248;
                  $i$f$and = false;
                  if ((b0 & other$iv) != 240) {
                     $this$commonReadUtf8CodePoint.skip(1L);
                     return 65533;
                  }

                  other$iv = 7;
                  $i$f$and = false;
                  codePoint = b0 & other$iv;
                  byteCount = 4;
                  min = 65536;
               }
            }
         }

         if ($this$commonReadUtf8CodePoint.size() < (long)byteCount) {
            throw (Throwable)(new EOFException("size < " + byteCount + ": " + $this$commonReadUtf8CodePoint.size() + " (to read code point prefixed 0x" + -Util.toHexString(b0) + ')'));
         } else {
            int i = 1;

            for(other$iv = byteCount; i < other$iv; ++i) {
               byte b = $this$commonReadUtf8CodePoint.getByte((long)i);
               int other$iv = 192;
               int $i$f$and = false;
               if ((b & other$iv) != 128) {
                  $this$commonReadUtf8CodePoint.skip((long)i);
                  return 65533;
               }

               codePoint <<= 6;
               int other$iv = 63;
               $i$f$and = false;
               codePoint |= b & other$iv;
            }

            $this$commonReadUtf8CodePoint.skip((long)byteCount);
            int var10000;
            if (codePoint > 1114111) {
               var10000 = 65533;
            } else {
               if (55296 <= codePoint) {
                  if (57343 >= codePoint) {
                     var10000 = 65533;
                     return var10000;
                  }
               }

               var10000 = codePoint < min ? '�' : codePoint;
            }

            return var10000;
         }
      }
   }

   @NotNull
   public static final Buffer commonWriteUtf8(@NotNull Buffer $this$commonWriteUtf8, @NotNull String string, int beginIndex, int endIndex) {
      int $i$f$commonWriteUtf8 = 0;
      Intrinsics.checkNotNullParameter($this$commonWriteUtf8, "$this$commonWriteUtf8");
      Intrinsics.checkNotNullParameter(string, "string");
      boolean var5 = beginIndex >= 0;
      boolean var6 = false;
      boolean var7 = false;
      boolean var18;
      String var19;
      if (!var5) {
         var18 = false;
         var19 = "beginIndex < 0: " + beginIndex;
         throw (Throwable)(new IllegalArgumentException(var19.toString()));
      } else {
         var5 = endIndex >= beginIndex;
         var6 = false;
         var7 = false;
         if (!var5) {
            var18 = false;
            var19 = "endIndex < beginIndex: " + endIndex + " < " + beginIndex;
            throw (Throwable)(new IllegalArgumentException(var19.toString()));
         } else {
            var5 = endIndex <= string.length();
            var6 = false;
            var7 = false;
            if (!var5) {
               var18 = false;
               var19 = "endIndex > string.length: " + endIndex + " > " + string.length();
               throw (Throwable)(new IllegalArgumentException(var19.toString()));
            } else {
               int i = beginIndex;

               while(true) {
                  while(i < endIndex) {
                     int c = string.charAt(i);
                     Segment tail;
                     if (c < 128) {
                        tail = $this$commonWriteUtf8.writableSegment$okio(1);
                        byte[] data = tail.data;
                        int segmentOffset = tail.limit - i;
                        int runSize = 8192 - segmentOffset;
                        boolean var12 = false;
                        int runLimit = Math.min(endIndex, runSize);

                        for(data[segmentOffset + i++] = (byte)c; i < runLimit; data[segmentOffset + i++] = (byte)c) {
                           c = string.charAt(i);
                           if (c >= 128) {
                              break;
                           }
                        }

                        runSize = i + segmentOffset - tail.limit;
                        tail.limit += runSize;
                        $this$commonWriteUtf8.setSize$okio($this$commonWriteUtf8.size() + (long)runSize);
                     } else if (c < 2048) {
                        tail = $this$commonWriteUtf8.writableSegment$okio(2);
                        tail.data[tail.limit] = (byte)(c >> 6 | 192);
                        tail.data[tail.limit + 1] = (byte)(c & 63 | 128);
                        tail.limit += 2;
                        $this$commonWriteUtf8.setSize$okio($this$commonWriteUtf8.size() + 2L);
                        ++i;
                     } else if (c >= '\ud800' && c <= '\udfff') {
                        int low = i + 1 < endIndex ? string.charAt(i + 1) : 0;
                        if (c <= '\udbff') {
                           if ('\udc00' <= low) {
                              if ('\udfff' >= low) {
                                 int codePoint = 65536 + ((c & 1023) << 10 | low & 1023);
                                 Segment tail = $this$commonWriteUtf8.writableSegment$okio(4);
                                 tail.data[tail.limit] = (byte)(codePoint >> 18 | 240);
                                 tail.data[tail.limit + 1] = (byte)(codePoint >> 12 & 63 | 128);
                                 tail.data[tail.limit + 2] = (byte)(codePoint >> 6 & 63 | 128);
                                 tail.data[tail.limit + 3] = (byte)(codePoint & 63 | 128);
                                 tail.limit += 4;
                                 $this$commonWriteUtf8.setSize$okio($this$commonWriteUtf8.size() + 4L);
                                 i += 2;
                                 continue;
                              }
                           }
                        }

                        $this$commonWriteUtf8.writeByte(63);
                        ++i;
                     } else {
                        tail = $this$commonWriteUtf8.writableSegment$okio(3);
                        tail.data[tail.limit] = (byte)(c >> 12 | 224);
                        tail.data[tail.limit + 1] = (byte)(c >> 6 & 63 | 128);
                        tail.data[tail.limit + 2] = (byte)(c & 63 | 128);
                        tail.limit += 3;
                        $this$commonWriteUtf8.setSize$okio($this$commonWriteUtf8.size() + 3L);
                        ++i;
                     }
                  }

                  return $this$commonWriteUtf8;
               }
            }
         }
      }
   }

   @NotNull
   public static final Buffer commonWriteUtf8CodePoint(@NotNull Buffer $this$commonWriteUtf8CodePoint, int codePoint) {
      int $i$f$commonWriteUtf8CodePoint = 0;
      Intrinsics.checkNotNullParameter($this$commonWriteUtf8CodePoint, "$this$commonWriteUtf8CodePoint");
      if (codePoint < 128) {
         $this$commonWriteUtf8CodePoint.writeByte(codePoint);
      } else {
         Segment tail;
         if (codePoint < 2048) {
            tail = $this$commonWriteUtf8CodePoint.writableSegment$okio(2);
            tail.data[tail.limit] = (byte)(codePoint >> 6 | 192);
            tail.data[tail.limit + 1] = (byte)(codePoint & 63 | 128);
            tail.limit += 2;
            $this$commonWriteUtf8CodePoint.setSize$okio($this$commonWriteUtf8CodePoint.size() + 2L);
         } else {
            if (55296 <= codePoint) {
               if (57343 >= codePoint) {
                  $this$commonWriteUtf8CodePoint.writeByte(63);
                  return $this$commonWriteUtf8CodePoint;
               }
            }

            if (codePoint < 65536) {
               tail = $this$commonWriteUtf8CodePoint.writableSegment$okio(3);
               tail.data[tail.limit] = (byte)(codePoint >> 12 | 224);
               tail.data[tail.limit + 1] = (byte)(codePoint >> 6 & 63 | 128);
               tail.data[tail.limit + 2] = (byte)(codePoint & 63 | 128);
               tail.limit += 3;
               $this$commonWriteUtf8CodePoint.setSize$okio($this$commonWriteUtf8CodePoint.size() + 3L);
            } else {
               if (codePoint > 1114111) {
                  throw (Throwable)(new IllegalArgumentException("Unexpected code point: 0x" + -Util.toHexString(codePoint)));
               }

               tail = $this$commonWriteUtf8CodePoint.writableSegment$okio(4);
               tail.data[tail.limit] = (byte)(codePoint >> 18 | 240);
               tail.data[tail.limit + 1] = (byte)(codePoint >> 12 & 63 | 128);
               tail.data[tail.limit + 2] = (byte)(codePoint >> 6 & 63 | 128);
               tail.data[tail.limit + 3] = (byte)(codePoint & 63 | 128);
               tail.limit += 4;
               $this$commonWriteUtf8CodePoint.setSize$okio($this$commonWriteUtf8CodePoint.size() + 4L);
            }
         }
      }

      return $this$commonWriteUtf8CodePoint;
   }

   public static final long commonWriteAll(@NotNull Buffer $this$commonWriteAll, @NotNull Source source) {
      int $i$f$commonWriteAll = 0;
      Intrinsics.checkNotNullParameter($this$commonWriteAll, "$this$commonWriteAll");
      Intrinsics.checkNotNullParameter(source, "source");
      long totalBytesRead = 0L;

      while(true) {
         long readCount = source.read($this$commonWriteAll, (long)8192);
         if (readCount == -1L) {
            return totalBytesRead;
         }

         totalBytesRead += readCount;
      }
   }

   @NotNull
   public static final Buffer commonWrite(@NotNull Buffer $this$commonWrite, @NotNull Source source, long byteCount) {
      int $i$f$commonWrite = 0;
      Intrinsics.checkNotNullParameter($this$commonWrite, "$this$commonWrite");
      Intrinsics.checkNotNullParameter(source, "source");

      long read;
      for(long byteCount = byteCount; byteCount > 0L; byteCount -= read) {
         read = source.read($this$commonWrite, byteCount);
         if (read == -1L) {
            throw (Throwable)(new EOFException());
         }
      }

      return $this$commonWrite;
   }

   @NotNull
   public static final Buffer commonWriteByte(@NotNull Buffer $this$commonWriteByte, int b) {
      int $i$f$commonWriteByte = 0;
      Intrinsics.checkNotNullParameter($this$commonWriteByte, "$this$commonWriteByte");
      Segment tail = $this$commonWriteByte.writableSegment$okio(1);
      byte[] var10000 = tail.data;
      int var4;
      tail.limit = (var4 = tail.limit) + 1;
      var10000[var4] = (byte)b;
      $this$commonWriteByte.setSize$okio($this$commonWriteByte.size() + 1L);
      return $this$commonWriteByte;
   }

   @NotNull
   public static final Buffer commonWriteShort(@NotNull Buffer $this$commonWriteShort, int s) {
      int $i$f$commonWriteShort = 0;
      Intrinsics.checkNotNullParameter($this$commonWriteShort, "$this$commonWriteShort");
      Segment tail = $this$commonWriteShort.writableSegment$okio(2);
      byte[] data = tail.data;
      int limit = tail.limit;
      data[limit++] = (byte)(s >>> 8 & 255);
      data[limit++] = (byte)(s & 255);
      tail.limit = limit;
      $this$commonWriteShort.setSize$okio($this$commonWriteShort.size() + 2L);
      return $this$commonWriteShort;
   }

   @NotNull
   public static final Buffer commonWriteInt(@NotNull Buffer $this$commonWriteInt, int i) {
      int $i$f$commonWriteInt = 0;
      Intrinsics.checkNotNullParameter($this$commonWriteInt, "$this$commonWriteInt");
      Segment tail = $this$commonWriteInt.writableSegment$okio(4);
      byte[] data = tail.data;
      int limit = tail.limit;
      data[limit++] = (byte)(i >>> 24 & 255);
      data[limit++] = (byte)(i >>> 16 & 255);
      data[limit++] = (byte)(i >>> 8 & 255);
      data[limit++] = (byte)(i & 255);
      tail.limit = limit;
      $this$commonWriteInt.setSize$okio($this$commonWriteInt.size() + 4L);
      return $this$commonWriteInt;
   }

   @NotNull
   public static final Buffer commonWriteLong(@NotNull Buffer $this$commonWriteLong, long v) {
      int $i$f$commonWriteLong = 0;
      Intrinsics.checkNotNullParameter($this$commonWriteLong, "$this$commonWriteLong");
      Segment tail = $this$commonWriteLong.writableSegment$okio(8);
      byte[] data = tail.data;
      int limit = tail.limit;
      data[limit++] = (byte)((int)(v >>> 56 & 255L));
      data[limit++] = (byte)((int)(v >>> 48 & 255L));
      data[limit++] = (byte)((int)(v >>> 40 & 255L));
      data[limit++] = (byte)((int)(v >>> 32 & 255L));
      data[limit++] = (byte)((int)(v >>> 24 & 255L));
      data[limit++] = (byte)((int)(v >>> 16 & 255L));
      data[limit++] = (byte)((int)(v >>> 8 & 255L));
      data[limit++] = (byte)((int)(v & 255L));
      tail.limit = limit;
      $this$commonWriteLong.setSize$okio($this$commonWriteLong.size() + 8L);
      return $this$commonWriteLong;
   }

   public static final void commonWrite(@NotNull Buffer $this$commonWrite, @NotNull Buffer source, long byteCount) {
      int $i$f$commonWrite = 0;
      Intrinsics.checkNotNullParameter($this$commonWrite, "$this$commonWrite");
      Intrinsics.checkNotNullParameter(source, "source");
      long byteCount = byteCount;
      boolean var7 = source != $this$commonWrite;
      boolean var8 = false;
      boolean var9 = false;
      if (!var7) {
         int var14 = false;
         String var13 = "source == this";
         throw (Throwable)(new IllegalArgumentException(var13.toString()));
      } else {
         -Util.checkOffsetAndCount(source.size(), 0L, byteCount);

         while(byteCount > 0L) {
            Segment var10001 = source.head;
            Intrinsics.checkNotNull(var10001);
            int var15 = var10001.limit;
            Segment var10002 = source.head;
            Intrinsics.checkNotNull(var10002);
            Segment tail;
            Segment var10000;
            if (byteCount < (long)(var15 - var10002.pos)) {
               if ($this$commonWrite.head != null) {
                  var10000 = $this$commonWrite.head;
                  Intrinsics.checkNotNull(var10000);
                  var10000 = var10000.prev;
               } else {
                  var10000 = null;
               }

               tail = var10000;
               if (tail != null && tail.owner && byteCount + (long)tail.limit - (long)(tail.shared ? 0 : tail.pos) <= (long)8192) {
                  var10000 = source.head;
                  Intrinsics.checkNotNull(var10000);
                  var10000.writeTo(tail, (int)byteCount);
                  source.setSize$okio(source.size() - byteCount);
                  $this$commonWrite.setSize$okio($this$commonWrite.size() + byteCount);
                  return;
               }

               var10001 = source.head;
               Intrinsics.checkNotNull(var10001);
               source.head = var10001.split((int)byteCount);
            }

            tail = source.head;
            Intrinsics.checkNotNull(tail);
            long movedByteCount = (long)(tail.limit - tail.pos);
            source.head = tail.pop();
            if ($this$commonWrite.head == null) {
               $this$commonWrite.head = tail;
               tail.prev = tail;
               tail.next = tail.prev;
            } else {
               var10000 = $this$commonWrite.head;
               Intrinsics.checkNotNull(var10000);
               Segment tail = var10000.prev;
               Intrinsics.checkNotNull(tail);
               tail = tail.push(tail);
               tail.compact();
            }

            source.setSize$okio(source.size() - movedByteCount);
            $this$commonWrite.setSize$okio($this$commonWrite.size() + movedByteCount);
            byteCount -= movedByteCount;
         }

      }
   }

   public static final long commonRead(@NotNull Buffer $this$commonRead, @NotNull Buffer sink, long byteCount) {
      int $i$f$commonRead = 0;
      Intrinsics.checkNotNullParameter($this$commonRead, "$this$commonRead");
      Intrinsics.checkNotNullParameter(sink, "sink");
      long byteCount = byteCount;
      boolean var5 = byteCount >= 0L;
      boolean var6 = false;
      boolean var7 = false;
      if (!var5) {
         int var8 = false;
         String var11 = "byteCount < 0: " + byteCount;
         throw (Throwable)(new IllegalArgumentException(var11.toString()));
      } else if ($this$commonRead.size() == 0L) {
         return -1L;
      } else {
         if (byteCount > $this$commonRead.size()) {
            byteCount = $this$commonRead.size();
         }

         sink.write($this$commonRead, byteCount);
         return byteCount;
      }
   }

   public static final long commonIndexOf(@NotNull Buffer $this$commonIndexOf, byte b, long fromIndex, long toIndex) {
      boolean var10000;
      long fromIndex;
      long toIndex;
      label103: {
         int $i$f$commonIndexOf = 0;
         Intrinsics.checkNotNullParameter($this$commonIndexOf, "$this$commonIndexOf");
         fromIndex = fromIndex;
         toIndex = toIndex;
         if (0L <= fromIndex) {
            if (toIndex >= fromIndex) {
               var10000 = true;
               break label103;
            }
         }

         var10000 = false;
      }

      boolean var7 = var10000;
      boolean var8 = false;
      boolean var9 = false;
      boolean $i$f$seek;
      if (!var7) {
         $i$f$seek = false;
         String var48 = "size=" + $this$commonIndexOf.size() + " fromIndex=" + fromIndex + " toIndex=" + toIndex;
         throw (Throwable)(new IllegalArgumentException(var48.toString()));
      } else {
         if (toIndex > $this$commonIndexOf.size()) {
            toIndex = $this$commonIndexOf.size();
         }

         if (fromIndex == toIndex) {
            return -1L;
         } else {
            long fromIndex$iv = fromIndex;
            $i$f$seek = false;
            Segment var49 = $this$commonIndexOf.head;
            boolean var14;
            if (var49 == null) {
               long var11 = -1L;
               Segment s = (Segment)null;
               var14 = false;
               return -1L;
            } else {
               Segment s$iv = var49;
               long var21;
               long offset$iv;
               if ($this$commonIndexOf.size() - fromIndex < fromIndex) {
                  for(offset$iv = $this$commonIndexOf.size(); offset$iv > fromIndex$iv; offset$iv -= (long)(s$iv.limit - s$iv.pos)) {
                     var49 = s$iv.prev;
                     Intrinsics.checkNotNull(var49);
                     s$iv = var49;
                  }

                  var14 = false;
                  if (s$iv == null) {
                     return -1L;
                  } else {
                     Segment s = s$iv;

                     for(long offset = offset$iv; offset < toIndex; s = var49) {
                        byte[] data = s.data;
                        long var19 = (long)s.limit;
                        var21 = (long)s.pos + toIndex - offset;
                        boolean var23 = false;
                        int limit = (int)Math.min(var19, var21);

                        for(int pos = (int)((long)s.pos + fromIndex - offset); pos < limit; ++pos) {
                           if (data[pos] == b) {
                              return (long)(pos - s.pos) + offset;
                           }
                        }

                        offset += (long)(s.limit - s.pos);
                        fromIndex = offset;
                        var49 = s.next;
                        Intrinsics.checkNotNull(var49);
                     }

                     return -1L;
                  }
               } else {
                  offset$iv = 0L;

                  while(true) {
                     long nextOffset$iv = offset$iv + (long)(s$iv.limit - s$iv.pos);
                     if (nextOffset$iv > fromIndex$iv) {
                        int var34 = false;
                        if (s$iv == null) {
                           return -1L;
                        } else {
                           Segment s = s$iv;

                           for(long offset = offset$iv; offset < toIndex; s = var49) {
                              byte[] data = s.data;
                              var21 = (long)s.limit;
                              long var39 = (long)s.pos + toIndex - offset;
                              boolean var25 = false;
                              int limit = (int)Math.min(var21, var39);

                              for(int pos = (int)((long)s.pos + fromIndex - offset); pos < limit; ++pos) {
                                 if (data[pos] == b) {
                                    return (long)(pos - s.pos) + offset;
                                 }
                              }

                              offset += (long)(s.limit - s.pos);
                              fromIndex = offset;
                              var49 = s.next;
                              Intrinsics.checkNotNull(var49);
                           }

                           return -1L;
                        }
                     }

                     var49 = s$iv.next;
                     Intrinsics.checkNotNull(var49);
                     s$iv = var49;
                     offset$iv = nextOffset$iv;
                  }
               }
            }
         }
      }
   }

   public static final long commonIndexOf(@NotNull Buffer $this$commonIndexOf, @NotNull ByteString bytes, long fromIndex) {
      int $i$f$commonIndexOf = 0;
      Intrinsics.checkNotNullParameter($this$commonIndexOf, "$this$commonIndexOf");
      Intrinsics.checkNotNullParameter(bytes, "bytes");
      long fromIndex = fromIndex;
      boolean var5 = bytes.size() > 0;
      boolean var6 = false;
      boolean var7 = false;
      boolean $i$f$seek;
      String var59;
      if (!var5) {
         $i$f$seek = false;
         var59 = "bytes is empty";
         throw (Throwable)(new IllegalArgumentException(var59.toString()));
      } else {
         var5 = fromIndex >= 0L;
         var6 = false;
         var7 = false;
         if (!var5) {
            $i$f$seek = false;
            var59 = "fromIndex < 0: " + fromIndex;
            throw (Throwable)(new IllegalArgumentException(var59.toString()));
         } else {
            long fromIndex$iv = fromIndex;
            $i$f$seek = false;
            Segment var10000 = $this$commonIndexOf.head;
            boolean var12;
            if (var10000 == null) {
               long var9 = -1L;
               Segment s = (Segment)null;
               var12 = false;
               return -1L;
            } else {
               Segment s$iv = var10000;
               long offset$iv;
               if ($this$commonIndexOf.size() - fromIndex < fromIndex) {
                  for(offset$iv = $this$commonIndexOf.size(); offset$iv > fromIndex$iv; offset$iv -= (long)(s$iv.limit - s$iv.pos)) {
                     var10000 = s$iv.prev;
                     Intrinsics.checkNotNull(var10000);
                     s$iv = var10000;
                  }

                  var12 = false;
                  if (s$iv == null) {
                     return -1L;
                  } else {
                     Segment s = s$iv;
                     long offset = offset$iv;
                     byte[] targetByteArray = bytes.internalArray$okio();
                     byte b0 = targetByteArray[0];
                     int bytesSize = bytes.size();

                     for(long resultLimit = $this$commonIndexOf.size() - (long)bytesSize + 1L; offset < resultLimit; s = var10000) {
                        byte[] data = s.data;
                        int pos = s.limit;
                        long b$iv = (long)s.pos + resultLimit - offset;
                        int $i$f$minOf = false;
                        long var26 = (long)pos;
                        boolean var28 = false;
                        int segmentLimit = (int)Math.min(var26, b$iv);
                        pos = (int)((long)s.pos + fromIndex - offset);

                        for(int var61 = segmentLimit; pos < var61; ++pos) {
                           if (data[pos] == b0 && rangeEquals(s, pos + 1, targetByteArray, 1, bytesSize)) {
                              return (long)(pos - s.pos) + offset;
                           }
                        }

                        offset += (long)(s.limit - s.pos);
                        fromIndex = offset;
                        var10000 = s.next;
                        Intrinsics.checkNotNull(var10000);
                     }

                     return -1L;
                  }
               } else {
                  offset$iv = 0L;

                  while(true) {
                     long nextOffset$iv = offset$iv + (long)(s$iv.limit - s$iv.pos);
                     if (nextOffset$iv > fromIndex$iv) {
                        int var39 = false;
                        if (s$iv == null) {
                           return -1L;
                        } else {
                           Segment s = s$iv;
                           long offset = offset$iv;
                           byte[] targetByteArray = bytes.internalArray$okio();
                           byte b0 = targetByteArray[0];
                           int bytesSize = bytes.size();

                           for(long resultLimit = $this$commonIndexOf.size() - (long)bytesSize + 1L; offset < resultLimit; s = var10000) {
                              byte[] data = s.data;
                              int pos = s.limit;
                              long b$iv = (long)s.pos + resultLimit - offset;
                              int $i$f$minOf = false;
                              long var52 = (long)pos;
                              boolean var30 = false;
                              int segmentLimit = (int)Math.min(var52, b$iv);
                              pos = (int)((long)s.pos + fromIndex - offset);

                              for(int var55 = segmentLimit; pos < var55; ++pos) {
                                 if (data[pos] == b0 && rangeEquals(s, pos + 1, targetByteArray, 1, bytesSize)) {
                                    return (long)(pos - s.pos) + offset;
                                 }
                              }

                              offset += (long)(s.limit - s.pos);
                              fromIndex = offset;
                              var10000 = s.next;
                              Intrinsics.checkNotNull(var10000);
                           }

                           return -1L;
                        }
                     }

                     var10000 = s$iv.next;
                     Intrinsics.checkNotNull(var10000);
                     s$iv = var10000;
                     offset$iv = nextOffset$iv;
                  }
               }
            }
         }
      }
   }

   public static final long commonIndexOfElement(@NotNull Buffer $this$commonIndexOfElement, @NotNull ByteString targetBytes, long fromIndex) {
      int $i$f$commonIndexOfElement = 0;
      Intrinsics.checkNotNullParameter($this$commonIndexOfElement, "$this$commonIndexOfElement");
      Intrinsics.checkNotNullParameter(targetBytes, "targetBytes");
      long fromIndex = fromIndex;
      boolean var5 = fromIndex >= 0L;
      boolean var6 = false;
      boolean var7 = false;
      boolean $i$f$seek;
      if (!var5) {
         $i$f$seek = false;
         String var42 = "fromIndex < 0: " + fromIndex;
         throw (Throwable)(new IllegalArgumentException(var42.toString()));
      } else {
         long fromIndex$iv = fromIndex;
         $i$f$seek = false;
         Segment var10000 = $this$commonIndexOfElement.head;
         boolean var12;
         if (var10000 == null) {
            long var9 = -1L;
            Segment s = (Segment)null;
            var12 = false;
            return -1L;
         } else {
            Segment s$iv = var10000;
            long offset$iv;
            byte[] targetByteArray;
            int pos;
            if ($this$commonIndexOfElement.size() - fromIndex < fromIndex) {
               for(offset$iv = $this$commonIndexOfElement.size(); offset$iv > fromIndex$iv; offset$iv -= (long)(s$iv.limit - s$iv.pos)) {
                  var10000 = s$iv.prev;
                  Intrinsics.checkNotNull(var10000);
                  s$iv = var10000;
               }

               var12 = false;
               if (s$iv == null) {
                  return -1L;
               } else {
                  Segment s = s$iv;
                  long offset = offset$iv;
                  int pos;
                  byte t;
                  if (targetBytes.size() != 2) {
                     for(byte[] targetByteArray = targetBytes.internalArray$okio(); offset < $this$commonIndexOfElement.size(); s = var10000) {
                        byte[] data = s.data;
                        int pos = (int)((long)s.pos + fromIndex - offset);

                        for(pos = s.limit; pos < pos; ++pos) {
                           int b = data[pos];
                           byte[] var53 = targetByteArray;
                           int var54 = targetByteArray.length;

                           for(int var55 = 0; var55 < var54; ++var55) {
                              t = var53[var55];
                              if (b == t) {
                                 return (long)(pos - s.pos) + offset;
                              }
                           }
                        }

                        offset += (long)(s.limit - s.pos);
                        fromIndex = offset;
                        var10000 = s.next;
                        Intrinsics.checkNotNull(var10000);
                     }
                  } else {
                     byte b0 = targetBytes.getByte(0);

                     for(byte b1 = targetBytes.getByte(1); offset < $this$commonIndexOfElement.size(); s = var10000) {
                        targetByteArray = s.data;
                        pos = (int)((long)s.pos + fromIndex - offset);

                        for(pos = s.limit; pos < pos; ++pos) {
                           t = targetByteArray[pos];
                           if (t == b0 || t == b1) {
                              return (long)(pos - s.pos) + offset;
                           }
                        }

                        offset += (long)(s.limit - s.pos);
                        fromIndex = offset;
                        var10000 = s.next;
                        Intrinsics.checkNotNull(var10000);
                     }
                  }

                  return -1L;
               }
            } else {
               offset$iv = 0L;

               while(true) {
                  long nextOffset$iv = offset$iv + (long)(s$iv.limit - s$iv.pos);
                  if (nextOffset$iv > fromIndex$iv) {
                     int var33 = false;
                     if (s$iv == null) {
                        return -1L;
                     } else {
                        Segment s = s$iv;
                        long offset = offset$iv;
                        int pos;
                        byte t;
                        if (targetBytes.size() != 2) {
                           for(targetByteArray = targetBytes.internalArray$okio(); offset < $this$commonIndexOfElement.size(); s = var10000) {
                              byte[] data = s.data;
                              pos = (int)((long)s.pos + fromIndex - offset);

                              for(pos = s.limit; pos < pos; ++pos) {
                                 int b = data[pos];
                                 byte[] var24 = targetByteArray;
                                 int var37 = targetByteArray.length;

                                 for(int var38 = 0; var38 < var37; ++var38) {
                                    t = var24[var38];
                                    if (b == t) {
                                       return (long)(pos - s.pos) + offset;
                                    }
                                 }
                              }

                              offset += (long)(s.limit - s.pos);
                              fromIndex = offset;
                              var10000 = s.next;
                              Intrinsics.checkNotNull(var10000);
                           }
                        } else {
                           byte b0 = targetBytes.getByte(0);

                           for(byte b1 = targetBytes.getByte(1); offset < $this$commonIndexOfElement.size(); s = var10000) {
                              byte[] data = s.data;
                              pos = (int)((long)s.pos + fromIndex - offset);

                              for(int limit = s.limit; pos < limit; ++pos) {
                                 t = data[pos];
                                 if (t == b0 || t == b1) {
                                    return (long)(pos - s.pos) + offset;
                                 }
                              }

                              offset += (long)(s.limit - s.pos);
                              fromIndex = offset;
                              var10000 = s.next;
                              Intrinsics.checkNotNull(var10000);
                           }
                        }

                        return -1L;
                     }
                  }

                  var10000 = s$iv.next;
                  Intrinsics.checkNotNull(var10000);
                  s$iv = var10000;
                  offset$iv = nextOffset$iv;
               }
            }
         }
      }
   }

   public static final boolean commonRangeEquals(@NotNull Buffer $this$commonRangeEquals, long offset, @NotNull ByteString bytes, int bytesOffset, int byteCount) {
      int $i$f$commonRangeEquals = 0;
      Intrinsics.checkNotNullParameter($this$commonRangeEquals, "$this$commonRangeEquals");
      Intrinsics.checkNotNullParameter(bytes, "bytes");
      if (offset >= 0L && bytesOffset >= 0 && byteCount >= 0 && $this$commonRangeEquals.size() - offset >= (long)byteCount && bytes.size() - bytesOffset >= byteCount) {
         int i = 0;

         for(int var8 = byteCount; i < var8; ++i) {
            if ($this$commonRangeEquals.getByte(offset + (long)i) != bytes.getByte(bytesOffset + i)) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public static final boolean commonEquals(@NotNull Buffer $this$commonEquals, @Nullable Object other) {
      int $i$f$commonEquals = 0;
      Intrinsics.checkNotNullParameter($this$commonEquals, "$this$commonEquals");
      if ($this$commonEquals == other) {
         return true;
      } else if (!(other instanceof Buffer)) {
         return false;
      } else if ($this$commonEquals.size() != ((Buffer)other).size()) {
         return false;
      } else if ($this$commonEquals.size() == 0L) {
         return true;
      } else {
         Segment var10000 = $this$commonEquals.head;
         Intrinsics.checkNotNull(var10000);
         Segment sa = var10000;
         var10000 = ((Buffer)other).head;
         Intrinsics.checkNotNull(var10000);
         Segment sb = var10000;
         int posA = sa.pos;
         int posB = sb.pos;
         long pos = 0L;

         for(long count = 0L; pos < $this$commonEquals.size(); pos += count) {
            int var11 = sa.limit - posA;
            int var12 = sb.limit - posB;
            boolean var13 = false;
            count = (long)Math.min(var11, var12);
            long i = 0L;

            for(long var16 = count; i < var16; ++i) {
               if (sa.data[posA++] != sb.data[posB++]) {
                  return false;
               }
            }

            if (posA == sa.limit) {
               var10000 = sa.next;
               Intrinsics.checkNotNull(var10000);
               sa = var10000;
               posA = sa.pos;
            }

            if (posB == sb.limit) {
               var10000 = sb.next;
               Intrinsics.checkNotNull(var10000);
               sb = var10000;
               posB = sb.pos;
            }
         }

         return true;
      }
   }

   public static final int commonHashCode(@NotNull Buffer $this$commonHashCode) {
      int $i$f$commonHashCode = 0;
      Intrinsics.checkNotNullParameter($this$commonHashCode, "$this$commonHashCode");
      Segment var10000 = $this$commonHashCode.head;
      if (var10000 == null) {
         return 0;
      } else {
         Segment s = var10000;
         int result = 1;

         do {
            int pos = s.pos;

            for(int limit = s.limit; pos < limit; ++pos) {
               result = 31 * result + s.data[pos];
            }

            var10000 = s.next;
            Intrinsics.checkNotNull(var10000);
            s = var10000;
         } while(s != $this$commonHashCode.head);

         return result;
      }
   }

   @NotNull
   public static final Buffer commonCopy(@NotNull Buffer $this$commonCopy) {
      int $i$f$commonCopy = 0;
      Intrinsics.checkNotNullParameter($this$commonCopy, "$this$commonCopy");
      Buffer result = new Buffer();
      if ($this$commonCopy.size() == 0L) {
         return result;
      } else {
         Segment var10000 = $this$commonCopy.head;
         Intrinsics.checkNotNull(var10000);
         Segment head = var10000;
         Segment headCopy = head.sharedCopy();
         result.head = headCopy;
         headCopy.prev = result.head;
         headCopy.next = headCopy.prev;

         for(Segment s = head.next; s != head; s = s.next) {
            var10000 = headCopy.prev;
            Intrinsics.checkNotNull(var10000);
            Intrinsics.checkNotNull(s);
            var10000.push(s.sharedCopy());
         }

         result.setSize$okio($this$commonCopy.size());
         return result;
      }
   }

   @NotNull
   public static final ByteString commonSnapshot(@NotNull Buffer $this$commonSnapshot) {
      int $i$f$commonSnapshot = 0;
      Intrinsics.checkNotNullParameter($this$commonSnapshot, "$this$commonSnapshot");
      boolean var2 = $this$commonSnapshot.size() <= (long)Integer.MAX_VALUE;
      boolean var3 = false;
      boolean var4 = false;
      if (!var2) {
         int var5 = false;
         String var6 = "size > Int.MAX_VALUE: " + $this$commonSnapshot.size();
         throw (Throwable)(new IllegalStateException(var6.toString()));
      } else {
         return $this$commonSnapshot.snapshot((int)$this$commonSnapshot.size());
      }
   }

   @NotNull
   public static final ByteString commonSnapshot(@NotNull Buffer $this$commonSnapshot, int byteCount) {
      int $i$f$commonSnapshot = 0;
      Intrinsics.checkNotNullParameter($this$commonSnapshot, "$this$commonSnapshot");
      if (byteCount == 0) {
         return ByteString.EMPTY;
      } else {
         -Util.checkOffsetAndCount($this$commonSnapshot.size(), 0L, (long)byteCount);
         int offset = 0;
         int segmentCount = 0;

         Segment s;
         for(s = $this$commonSnapshot.head; offset < byteCount; s = s.next) {
            Intrinsics.checkNotNull(s);
            if (s.limit == s.pos) {
               throw (Throwable)(new AssertionError("s.limit == s.pos"));
            }

            offset += s.limit - s.pos;
            ++segmentCount;
         }

         byte[][] segments = new byte[segmentCount][];
         int[] directory = new int[segmentCount * 2];
         offset = 0;
         segmentCount = 0;

         for(s = $this$commonSnapshot.head; offset < byteCount; s = s.next) {
            Intrinsics.checkNotNull(s);
            segments[segmentCount] = s.data;
            offset += s.limit - s.pos;
            boolean var8 = false;
            directory[segmentCount] = Math.min(offset, byteCount);
            directory[segmentCount + ((Object[])segments).length] = s.pos;
            s.shared = true;
            ++segmentCount;
         }

         return (ByteString)(new SegmentedByteString((byte[][])segments, directory));
      }
   }
}
