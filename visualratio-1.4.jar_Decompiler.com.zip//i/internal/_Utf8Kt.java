package i.internal;

import java.util.Arrays;
import k.Metadata;
import k.Unit;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 2,
   d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0012\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\u001a\n\u0010\u0000\u001a\u00020\u0001*\u00020\u0002\u001a\u001e\u0010\u0003\u001a\u00020\u0002*\u00020\u00012\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0005¨\u0006\u0007"},
   d2 = {"commonAsUtf8ToByteArray", "", "", "commonToUtf8String", "beginIndex", "", "endIndex", "i"}
)
public final class _Utf8Kt {
   @NotNull
   public static final String commonToUtf8String(@NotNull byte[] $this$commonToUtf8String, int beginIndex, int endIndex) {
      Intrinsics.checkNotNullParameter($this$commonToUtf8String, "$this$commonToUtf8String");
      if (beginIndex >= 0 && endIndex <= $this$commonToUtf8String.length && beginIndex <= endIndex) {
         char[] chars = new char[endIndex - beginIndex];
         int length = 0;
         byte[] $this$processUtf16Chars$iv = $this$commonToUtf8String;
         int $i$f$processUtf16Chars = false;
         int index$iv = beginIndex;

         while(true) {
            while(index$iv < endIndex) {
               byte b0$iv = $this$processUtf16Chars$iv[index$iv];
               char c;
               boolean var10;
               int var11;
               if (b0$iv >= 0) {
                  c = (char)b0$iv;
                  var10 = false;
                  var11 = length++;
                  chars[var11] = c;
                  ++index$iv;

                  while(index$iv < endIndex && $this$processUtf16Chars$iv[index$iv] >= 0) {
                     c = (char)$this$processUtf16Chars$iv[index$iv++];
                     var10 = false;
                     var11 = length++;
                     chars[var11] = c;
                  }
               } else {
                  int other$iv$iv = 5;
                  int $i$f$shr = false;
                  boolean var16;
                  int var10000;
                  Unit var17;
                  byte var10001;
                  byte byte$iv$iv$iv;
                  boolean $i$f$isUtf8Continuation;
                  boolean $i$f$and;
                  boolean $i$f$process4Utf8Bytes;
                  char codePoint$iv;
                  byte b1$iv$iv;
                  short other$iv$iv$iv$iv;
                  if (b0$iv >> other$iv$iv == -2) {
                     $i$f$process4Utf8Bytes = false;
                     if (endIndex <= index$iv + 1) {
                        codePoint$iv = '�';
                        var16 = false;
                        c = (char)codePoint$iv;
                        var10 = false;
                        var11 = length++;
                        chars[var11] = c;
                        var17 = Unit.INSTANCE;
                        var10000 = index$iv;
                        var10001 = 1;
                     } else {
                        byte$iv$iv$iv = $this$processUtf16Chars$iv[index$iv];
                        b1$iv$iv = $this$processUtf16Chars$iv[index$iv + 1];
                        $i$f$isUtf8Continuation = false;
                        other$iv$iv$iv$iv = 192;
                        $i$f$and = false;
                        if ((b1$iv$iv & other$iv$iv$iv$iv) != 128) {
                           codePoint$iv = '�';
                           var16 = false;
                           c = (char)codePoint$iv;
                           var10 = false;
                           var11 = length++;
                           chars[var11] = c;
                           var17 = Unit.INSTANCE;
                           var10000 = index$iv;
                           var10001 = 1;
                        } else {
                           int codePoint$iv$iv = 3968 ^ b1$iv$iv ^ byte$iv$iv$iv << 6;
                           if (codePoint$iv$iv < 128) {
                              codePoint$iv = '�';
                              var16 = false;
                              c = (char)codePoint$iv;
                              var10 = false;
                              var11 = length++;
                              chars[var11] = c;
                              var17 = Unit.INSTANCE;
                              var10000 = index$iv;
                           } else {
                              var16 = false;
                              c = (char)codePoint$iv$iv;
                              var10 = false;
                              var11 = length++;
                              chars[var11] = c;
                              var17 = Unit.INSTANCE;
                              var10000 = index$iv;
                           }

                           var10001 = 2;
                        }
                     }

                     index$iv = var10000 + var10001;
                  } else {
                     other$iv$iv = 4;
                     $i$f$shr = false;
                     boolean $i$f$isUtf8Continuation;
                     short other$iv$iv$iv$iv;
                     boolean $i$f$and;
                     boolean $i$f$and;
                     byte b2$iv$iv;
                     boolean $i$f$isUtf8Continuation;
                     short other$iv$iv$iv$iv;
                     if (b0$iv >> other$iv$iv == -2) {
                        $i$f$process4Utf8Bytes = false;
                        if (endIndex <= index$iv + 2) {
                           label177: {
                              codePoint$iv = '�';
                              var16 = false;
                              c = (char)codePoint$iv;
                              var10 = false;
                              var11 = length++;
                              chars[var11] = c;
                              var17 = Unit.INSTANCE;
                              var10000 = index$iv;
                              if (endIndex > index$iv + 1) {
                                 byte$iv$iv$iv = $this$processUtf16Chars$iv[index$iv + 1];
                                 $i$f$isUtf8Continuation = false;
                                 other$iv$iv$iv$iv = 192;
                                 $i$f$and = false;
                                 if ((byte$iv$iv$iv & other$iv$iv$iv$iv) == 128) {
                                    var10001 = 2;
                                    break label177;
                                 }
                              }

                              var10001 = 1;
                           }
                        } else {
                           byte$iv$iv$iv = $this$processUtf16Chars$iv[index$iv];
                           b1$iv$iv = $this$processUtf16Chars$iv[index$iv + 1];
                           $i$f$isUtf8Continuation = false;
                           other$iv$iv$iv$iv = 192;
                           $i$f$and = false;
                           if ((b1$iv$iv & other$iv$iv$iv$iv) != 128) {
                              codePoint$iv = '�';
                              var16 = false;
                              c = (char)codePoint$iv;
                              var10 = false;
                              var11 = length++;
                              chars[var11] = c;
                              var17 = Unit.INSTANCE;
                              var10000 = index$iv;
                              var10001 = 1;
                           } else {
                              b2$iv$iv = $this$processUtf16Chars$iv[index$iv + 2];
                              $i$f$isUtf8Continuation = false;
                              other$iv$iv$iv$iv = 192;
                              $i$f$and = false;
                              if ((b2$iv$iv & other$iv$iv$iv$iv) != 128) {
                                 codePoint$iv = '�';
                                 var16 = false;
                                 c = (char)codePoint$iv;
                                 var10 = false;
                                 var11 = length++;
                                 chars[var11] = c;
                                 var17 = Unit.INSTANCE;
                                 var10000 = index$iv;
                                 var10001 = 2;
                              } else {
                                 int codePoint$iv$iv = -123008 ^ b2$iv$iv ^ b1$iv$iv << 6 ^ byte$iv$iv$iv << 12;
                                 if (codePoint$iv$iv < 2048) {
                                    codePoint$iv = '�';
                                    var16 = false;
                                    c = (char)codePoint$iv;
                                    var10 = false;
                                    var11 = length++;
                                    chars[var11] = c;
                                    var17 = Unit.INSTANCE;
                                    var10000 = index$iv;
                                 } else {
                                    label240: {
                                       if (55296 <= codePoint$iv$iv) {
                                          if (57343 >= codePoint$iv$iv) {
                                             codePoint$iv = '�';
                                             var16 = false;
                                             c = (char)codePoint$iv;
                                             var10 = false;
                                             var11 = length++;
                                             chars[var11] = c;
                                             var17 = Unit.INSTANCE;
                                             var10000 = index$iv;
                                             break label240;
                                          }
                                       }

                                       var16 = false;
                                       c = (char)codePoint$iv$iv;
                                       var10 = false;
                                       var11 = length++;
                                       chars[var11] = c;
                                       var17 = Unit.INSTANCE;
                                       var10000 = index$iv;
                                    }
                                 }

                                 var10001 = 3;
                              }
                           }
                        }

                        index$iv = var10000 + var10001;
                     } else {
                        other$iv$iv = 3;
                        $i$f$shr = false;
                        if (b0$iv >> other$iv$iv != -2) {
                           c = '�';
                           var10 = false;
                           var11 = length++;
                           chars[var11] = c;
                           ++index$iv;
                        } else {
                           $i$f$process4Utf8Bytes = false;
                           if (endIndex <= index$iv + 3) {
                              label228: {
                                 codePoint$iv = '�';
                                 var16 = false;
                                 if (codePoint$iv != '�') {
                                    c = (char)((codePoint$iv >>> 10) + 'ퟀ');
                                    var10 = false;
                                    var11 = length++;
                                    chars[var11] = c;
                                    c = (char)((codePoint$iv & 1023) + '\udc00');
                                    var10 = false;
                                    var11 = length++;
                                    chars[var11] = c;
                                 } else {
                                    c = '�';
                                    var10 = false;
                                    var11 = length++;
                                    chars[var11] = c;
                                 }

                                 var17 = Unit.INSTANCE;
                                 var10000 = index$iv;
                                 if (endIndex > index$iv + 1) {
                                    byte$iv$iv$iv = $this$processUtf16Chars$iv[index$iv + 1];
                                    $i$f$isUtf8Continuation = false;
                                    other$iv$iv$iv$iv = 192;
                                    $i$f$and = false;
                                    if ((byte$iv$iv$iv & other$iv$iv$iv$iv) == 128) {
                                       if (endIndex > index$iv + 2) {
                                          byte$iv$iv$iv = $this$processUtf16Chars$iv[index$iv + 2];
                                          $i$f$isUtf8Continuation = false;
                                          other$iv$iv$iv$iv = 192;
                                          $i$f$and = false;
                                          if ((byte$iv$iv$iv & other$iv$iv$iv$iv) == 128) {
                                             var10001 = 3;
                                             break label228;
                                          }
                                       }

                                       var10001 = 2;
                                       break label228;
                                    }
                                 }

                                 var10001 = 1;
                              }
                           } else {
                              byte$iv$iv$iv = $this$processUtf16Chars$iv[index$iv];
                              b1$iv$iv = $this$processUtf16Chars$iv[index$iv + 1];
                              $i$f$isUtf8Continuation = false;
                              other$iv$iv$iv$iv = 192;
                              $i$f$and = false;
                              if ((b1$iv$iv & other$iv$iv$iv$iv) != 128) {
                                 codePoint$iv = '�';
                                 var16 = false;
                                 if (codePoint$iv != '�') {
                                    c = (char)((codePoint$iv >>> 10) + 'ퟀ');
                                    var10 = false;
                                    var11 = length++;
                                    chars[var11] = c;
                                    c = (char)((codePoint$iv & 1023) + '\udc00');
                                    var10 = false;
                                    var11 = length++;
                                    chars[var11] = c;
                                 } else {
                                    c = '�';
                                    var10 = false;
                                    var11 = length++;
                                    chars[var11] = c;
                                 }

                                 var17 = Unit.INSTANCE;
                                 var10000 = index$iv;
                                 var10001 = 1;
                              } else {
                                 b2$iv$iv = $this$processUtf16Chars$iv[index$iv + 2];
                                 $i$f$isUtf8Continuation = false;
                                 other$iv$iv$iv$iv = 192;
                                 $i$f$and = false;
                                 if ((b2$iv$iv & other$iv$iv$iv$iv) != 128) {
                                    codePoint$iv = '�';
                                    var16 = false;
                                    if (codePoint$iv != '�') {
                                       c = (char)((codePoint$iv >>> 10) + 'ퟀ');
                                       var10 = false;
                                       var11 = length++;
                                       chars[var11] = c;
                                       c = (char)((codePoint$iv & 1023) + '\udc00');
                                       var10 = false;
                                       var11 = length++;
                                       chars[var11] = c;
                                    } else {
                                       c = '�';
                                       var10 = false;
                                       var11 = length++;
                                       chars[var11] = c;
                                    }

                                    var17 = Unit.INSTANCE;
                                    var10000 = index$iv;
                                    var10001 = 2;
                                 } else {
                                    byte b3$iv$iv = $this$processUtf16Chars$iv[index$iv + 3];
                                    $i$f$and = false;
                                    int other$iv$iv$iv$iv = 192;
                                    int $i$f$and = false;
                                    if ((b3$iv$iv & other$iv$iv$iv$iv) != 128) {
                                       codePoint$iv = '�';
                                       var16 = false;
                                       if (codePoint$iv != '�') {
                                          c = (char)((codePoint$iv >>> 10) + 'ퟀ');
                                          var10 = false;
                                          var11 = length++;
                                          chars[var11] = c;
                                          c = (char)((codePoint$iv & 1023) + '\udc00');
                                          var10 = false;
                                          var11 = length++;
                                          chars[var11] = c;
                                       } else {
                                          c = '�';
                                          var10 = false;
                                          var11 = length++;
                                          chars[var11] = c;
                                       }

                                       var17 = Unit.INSTANCE;
                                       var10000 = index$iv;
                                       var10001 = 3;
                                    } else {
                                       int codePoint$iv$iv = 3678080 ^ b3$iv$iv ^ b2$iv$iv << 6 ^ b1$iv$iv << 12 ^ byte$iv$iv$iv << 18;
                                       if (codePoint$iv$iv > 1114111) {
                                          codePoint$iv = '�';
                                          var16 = false;
                                          if (codePoint$iv != '�') {
                                             c = (char)((codePoint$iv >>> 10) + 'ퟀ');
                                             var10 = false;
                                             var11 = length++;
                                             chars[var11] = c;
                                             c = (char)((codePoint$iv & 1023) + '\udc00');
                                             var10 = false;
                                             var11 = length++;
                                             chars[var11] = c;
                                          } else {
                                             c = '�';
                                             var10 = false;
                                             var11 = length++;
                                             chars[var11] = c;
                                          }

                                          var17 = Unit.INSTANCE;
                                          var10000 = index$iv;
                                       } else {
                                          label253: {
                                             if (55296 <= codePoint$iv$iv) {
                                                if (57343 >= codePoint$iv$iv) {
                                                   codePoint$iv = '�';
                                                   var16 = false;
                                                   if (codePoint$iv != '�') {
                                                      c = (char)((codePoint$iv >>> 10) + 'ퟀ');
                                                      var10 = false;
                                                      var11 = length++;
                                                      chars[var11] = c;
                                                      c = (char)((codePoint$iv & 1023) + '\udc00');
                                                      var10 = false;
                                                      var11 = length++;
                                                      chars[var11] = c;
                                                   } else {
                                                      c = '�';
                                                      var10 = false;
                                                      var11 = length++;
                                                      chars[var11] = c;
                                                   }

                                                   var17 = Unit.INSTANCE;
                                                   var10000 = index$iv;
                                                   break label253;
                                                }
                                             }

                                             if (codePoint$iv$iv < 65536) {
                                                codePoint$iv = '�';
                                                var16 = false;
                                                if (codePoint$iv != '�') {
                                                   c = (char)((codePoint$iv >>> 10) + 'ퟀ');
                                                   var10 = false;
                                                   var11 = length++;
                                                   chars[var11] = c;
                                                   c = (char)((codePoint$iv & 1023) + '\udc00');
                                                   var10 = false;
                                                   var11 = length++;
                                                   chars[var11] = c;
                                                } else {
                                                   c = '�';
                                                   var10 = false;
                                                   var11 = length++;
                                                   chars[var11] = c;
                                                }

                                                var17 = Unit.INSTANCE;
                                                var10000 = index$iv;
                                             } else {
                                                var16 = false;
                                                if (codePoint$iv$iv != 65533) {
                                                   c = (char)((codePoint$iv$iv >>> 10) + 'ퟀ');
                                                   var10 = false;
                                                   var11 = length++;
                                                   chars[var11] = c;
                                                   c = (char)((codePoint$iv$iv & 1023) + '\udc00');
                                                   var10 = false;
                                                   var11 = length++;
                                                   chars[var11] = c;
                                                } else {
                                                   c = '�';
                                                   var10 = false;
                                                   var11 = length++;
                                                   chars[var11] = c;
                                                }

                                                var17 = Unit.INSTANCE;
                                                var10000 = index$iv;
                                             }
                                          }
                                       }

                                       var10001 = 4;
                                    }
                                 }
                              }
                           }

                           index$iv = var10000 + var10001;
                        }
                     }
                  }
               }
            }

            byte var26 = 0;
            boolean var27 = false;
            return new String(chars, var26, length);
         }
      } else {
         throw (Throwable)(new ArrayIndexOutOfBoundsException("size=" + $this$commonToUtf8String.length + " beginIndex=" + beginIndex + " endIndex=" + endIndex));
      }
   }

   // $FF: synthetic method
   public static String commonToUtf8String$default(byte[] var0, int var1, int var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = 0;
      }

      if ((var3 & 2) != 0) {
         var2 = var0.length;
      }

      return commonToUtf8String(var0, var1, var2);
   }

   @NotNull
   public static final byte[] commonAsUtf8ToByteArray(@NotNull String $this$commonAsUtf8ToByteArray) {
      Intrinsics.checkNotNullParameter($this$commonAsUtf8ToByteArray, "$this$commonAsUtf8ToByteArray");
      byte[] bytes = new byte[4 * $this$commonAsUtf8ToByteArray.length()];
      int index = 0;

      int var3;
      byte[] var10000;
      for(var3 = $this$commonAsUtf8ToByteArray.length(); index < var3; ++index) {
         char b0 = $this$commonAsUtf8ToByteArray.charAt(index);
         if (Intrinsics.compare(b0, 128) >= 0) {
            int size = index;
            String $this$processUtf8Bytes$iv = $this$commonAsUtf8ToByteArray;
            int endIndex$iv = $this$commonAsUtf8ToByteArray.length();
            int $i$f$processUtf8Bytes = false;
            int index$iv = index;

            while(true) {
               while(index$iv < endIndex$iv) {
                  char c$iv = $this$processUtf8Bytes$iv.charAt(index$iv);
                  byte c;
                  boolean var19;
                  int var20;
                  if (Intrinsics.compare(c$iv, 128) < 0) {
                     c = (byte)c$iv;
                     var19 = false;
                     var20 = size++;
                     bytes[var20] = c;
                     ++index$iv;

                     while(index$iv < endIndex$iv && Intrinsics.compare($this$processUtf8Bytes$iv.charAt(index$iv), 128) < 0) {
                        c = (byte)$this$processUtf8Bytes$iv.charAt(index$iv++);
                        var19 = false;
                        var20 = size++;
                        bytes[var20] = c;
                     }
                  } else if (Intrinsics.compare(c$iv, 2048) < 0) {
                     c = (byte)(c$iv >> 6 | 192);
                     var19 = false;
                     var20 = size++;
                     bytes[var20] = c;
                     c = (byte)(c$iv & 63 | 128);
                     var19 = false;
                     var20 = size++;
                     bytes[var20] = c;
                     ++index$iv;
                  } else {
                     byte c;
                     boolean var13;
                     int var14;
                     if ('\ud800' <= c$iv) {
                        if ('\udfff' >= c$iv) {
                           if (Intrinsics.compare(c$iv, 56319) <= 0 && endIndex$iv > index$iv + 1) {
                              char var11 = $this$processUtf8Bytes$iv.charAt(index$iv + 1);
                              if ('\udc00' <= var11) {
                                 if ('\udfff' >= var11) {
                                    int codePoint$iv = (c$iv << 10) + $this$processUtf8Bytes$iv.charAt(index$iv + 1) + -56613888;
                                    c = (byte)(codePoint$iv >> 18 | 240);
                                    var13 = false;
                                    var14 = size++;
                                    bytes[var14] = c;
                                    c = (byte)(codePoint$iv >> 12 & 63 | 128);
                                    var13 = false;
                                    var14 = size++;
                                    bytes[var14] = c;
                                    c = (byte)(codePoint$iv >> 6 & 63 | 128);
                                    var13 = false;
                                    var14 = size++;
                                    bytes[var14] = c;
                                    c = (byte)(codePoint$iv & 63 | 128);
                                    var13 = false;
                                    var14 = size++;
                                    bytes[var14] = c;
                                    index$iv += 2;
                                    continue;
                                 }
                              }
                           }

                           byte c = 63;
                           var13 = false;
                           var14 = size++;
                           bytes[var14] = c;
                           ++index$iv;
                           continue;
                        }
                     }

                     c = (byte)(c$iv >> 12 | 224);
                     var13 = false;
                     var14 = size++;
                     bytes[var14] = c;
                     c = (byte)(c$iv >> 6 & 63 | 128);
                     var13 = false;
                     var14 = size++;
                     bytes[var14] = c;
                     c = (byte)(c$iv & 63 | 128);
                     var13 = false;
                     var14 = size++;
                     bytes[var14] = c;
                     ++index$iv;
                  }
               }

               $i$f$processUtf8Bytes = false;
               var10000 = Arrays.copyOf(bytes, size);
               Intrinsics.checkNotNullExpressionValue(var10000, "java.util.Arrays.copyOf(this, newSize)");
               return var10000;
            }
         }

         bytes[index] = (byte)b0;
      }

      var3 = $this$commonAsUtf8ToByteArray.length();
      boolean var15 = false;
      var10000 = Arrays.copyOf(bytes, var3);
      Intrinsics.checkNotNullExpressionValue(var10000, "java.util.Arrays.copyOf(this, newSize)");
      return var10000;
   }
}
