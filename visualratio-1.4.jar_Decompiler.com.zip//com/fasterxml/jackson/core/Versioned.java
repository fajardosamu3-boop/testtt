package com.fasterxml.jackson.core;

public interface Versioned {
   Version version();
}
