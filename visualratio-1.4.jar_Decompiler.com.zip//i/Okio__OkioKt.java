package i;

import k.Metadata;
import k.jvm.JvmName;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

// $FF: synthetic class
@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 5,
   d1 = {"\u0000\u0018\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u001a\r\u0010\u0000\u001a\u00020\u0001H\u0007¢\u0006\u0002\b\u0002\u001a\n\u0010\u0003\u001a\u00020\u0004*\u00020\u0001\u001a\n\u0010\u0003\u001a\u00020\u0005*\u00020\u0006¨\u0006\u0007"},
   d2 = {"blackholeSink", "Li/Sink;", "blackhole", "buffer", "Li/BufferedSink;", "Li/BufferedSource;", "Li/Source;", "i"},
   xs = "i/Okio"
)
final class Okio__OkioKt {
   @NotNull
   public static final BufferedSource buffer(@NotNull Source $this$buffer) {
      Intrinsics.checkNotNullParameter($this$buffer, "$this$buffer");
      return (BufferedSource)(new RealBufferedSource($this$buffer));
   }

   @NotNull
   public static final BufferedSink buffer(@NotNull Sink $this$buffer) {
      Intrinsics.checkNotNullParameter($this$buffer, "$this$buffer");
      return (BufferedSink)(new RealBufferedSink($this$buffer));
   }

   @JvmName(
      name = "blackhole"
   )
   @NotNull
   public static final Sink blackhole() {
      return (Sink)(new BlackholeSink());
   }
}
