package i;

import java.io.IOException;
import java.io.InputStream;
import k.Metadata;
import k.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 4, 0},
   bv = {1, 0, 3},
   k = 1,
   d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\b\u0010\u0007\u001a\u00020\bH\u0016J\u0018\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\nH\u0016J\b\u0010\u0004\u001a\u00020\u0005H\u0016J\b\u0010\u000e\u001a\u00020\u000fH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0010"},
   d2 = {"Li/InputStreamSource;", "Li/Source;", "input", "Ljava/io/InputStream;", "timeout", "Li/Timeout;", "(Ljava/io/InputStream;Lokio/Timeout;)V", "close", "", "read", "", "sink", "Li/Buffer;", "byteCount", "toString", "", "i"}
)
final class InputStreamSource implements Source {
   private final InputStream input;
   private final Timeout timeout;

   public long read(@NotNull Buffer sink, long byteCount) {
      Intrinsics.checkNotNullParameter(sink, "sink");
      if (byteCount == 0L) {
         return 0L;
      } else {
         boolean var4 = byteCount >= 0L;
         boolean var5 = false;
         boolean var6 = false;
         boolean $i$f$minOf;
         if (!var4) {
            $i$f$minOf = false;
            String var15 = "byteCount < 0: " + byteCount;
            throw (Throwable)(new IllegalArgumentException(var15.toString()));
         } else {
            try {
               this.timeout.throwIfReached();
               Segment tail = sink.writableSegment$okio(1);
               int bytesRead = 8192 - tail.limit;
               $i$f$minOf = false;
               long var8 = (long)bytesRead;
               boolean var10 = false;
               int maxToCopy = (int)Math.min(byteCount, var8);
               bytesRead = this.input.read(tail.data, tail.limit, maxToCopy);
               if (bytesRead == -1) {
                  if (tail.pos == tail.limit) {
                     sink.head = tail.pop();
                     SegmentPool.recycle(tail);
                  }

                  return -1L;
               } else {
                  tail.limit += bytesRead;
                  sink.setSize$okio(sink.size() + (long)bytesRead);
                  return (long)bytesRead;
               }
            } catch (AssertionError var11) {
               if (Okio.isAndroidGetsocknameError(var11)) {
                  throw (Throwable)(new IOException((Throwable)var11));
               } else {
                  throw (Throwable)var11;
               }
            }
         }
      }
   }

   public void close() {
      this.input.close();
   }

   @NotNull
   public Timeout timeout() {
      return this.timeout;
   }

   @NotNull
   public String toString() {
      return "source(" + this.input + ')';
   }

   public InputStreamSource(@NotNull InputStream input, @NotNull Timeout timeout) {
      Intrinsics.checkNotNullParameter(input, "input");
      Intrinsics.checkNotNullParameter(timeout, "timeout");
      super();
      this.input = input;
      this.timeout = timeout;
   }
}
